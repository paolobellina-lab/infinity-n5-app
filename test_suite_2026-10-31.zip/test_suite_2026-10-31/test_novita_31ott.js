// @versione 2026-10-31.1 | test_novita_31ott.js | proprieta`: chat TEST
// ============================================================================
//  Le novita` del 30 ottobre sera / 31 ottobre (MOTORE, collaudo grafico di
//  Paolo): motore 2026-10-30.1, motore_core 30.2, ordine_movimento 30.2,
//  ordine_piazzamento 30.1, calcolatore_math 30.1, catalogo 30.1. Giro 26.
//   Z1 M.mostraAvviso / M.chiediSiNo: il riquadro .dialogo-app dell app (OK,
//      SI`/NO), in coda uno alla volta; con un confirm sostituito (una prova)
//      la risposta arriva subito; senza pagina, window.__alertNativo
//   Z2 l involucro di motore_core sulla pagina: alert.__nativo; con alert e
//      confirm del browser l avviso va nel riquadro
//   Z3 selectAction -> window.instradaAzione: la domanda del Foxhole aspetta
//      la risposta; con la prova al posto del confirm tutto come prima
//   Z4 applicaRicarica(poi): poi dopo la risposta, true/false come prima
//   Z5 M.armiPiazzabili: l arma finita in escluse con scarica, usi,
//      spiegazione; sulla pagina il tasto spento «0/N usi» e la nota nella ⓘ
//   Z6 M.segnalinoSenzaNumero: AD (e RESERVE) con icon_airborne.png e 🪂;
//      M.etichettaMarker solo per HIDDEN
//   Z7 calcolatore_math: lato.dettaglio (successo, dadi, nonApplicati) e
//      lato.tiroSalvezza (righe, dettaglioSuccesso, dettaglioDadi)
//  L harness creaTavolo e` quello di test_novita_29ott.js, con in piu`
//  l opzione nativi (alert e confirm che sembrano del browser).
//  USO:  node test_novita_31ott.js
// ============================================================================
const fs=require("fs"),vm=require("vm");const J=JSON.stringify;
function creaTavolo(DIR, opz) {
  opz = opz || {};
  DIR = DIR.replace(/\/?$/, '/');
  const server = {}, dispositivi = [], problemi = [];
  function recapita(da, chiave, valore) {
    if (valore === null) delete server[chiave]; else server[chiave] = valore;
    dispositivi.forEach(d => { if (d !== da) d.riceve(chiave, valore); });
  }
  function avvia(nome, titolo, pagina, ricerca) {
    const memoria = {}, el = {}, ascolti = {}, storage = [];
    const g = { errori: [], avvisi: [], alert_: [] };
    g.console = { log: () => {}, warn: (...a) => g.avvisi.push(a.map(String).join(' ')), error: (...a) => g.errori.push(a.map(x => (x && x.stack) || String(x)).join(' ')) };
    g.window = g; g.globalThis = g;
    const finto = (id) => { if (!el[id]) el[id] = { id, innerHTML: '', innerText: '', style: {}, value: '', checked: false, disabled: false, options: [],
        appendChild() {}, addEventListener() {}, remove() {}, setAttribute() {}, getAttribute() { return null; }, scrollTop: 0, scrollHeight: 0,
        classList: { add() {}, remove() {}, toggle() {} }, cloneNode() { return this; }, parentNode: { replaceChild() {}, insertBefore() {} },
        querySelector() { return null; }, querySelectorAll() { return []; } }; return el[id]; };
    let t = titolo;
    g.document = { get title() { return t; }, set title(v) { t = v; }, documentElement: { setAttribute() {} }, scripts: [], body: finto('body'),
        getElementById: finto, createElement: () => finto('nuovo_' + Math.random()), querySelector: (s) => finto('q:' + s), querySelectorAll: () => [],
        addEventListener() {}, write() {} };
    g.alert = (m) => g.alert_.push(String(m)); g.confirm = () => true; g.prompt = () => 'motivo di prova'; g.scrollTo = () => {};
    // 31 ottobre (giro 26): con opz.nativi alert e confirm sembrano quelli del
    // browser ([native code]: funzioni legate con bind), come sulla pagina vera.
    // Registrano lo stesso cio` che ricevono (alert_, domande).
    g.domande = [];
    if (opz.nativi) { g.alert = Array.prototype.push.bind(g.alert_); g.confirm = (function (m) { g.domande.push(String(m)); return true; }).bind(null); }
    g._cicli = []; g.setInterval = (fn) => { g._cicli.push(fn); return g._cicli.length; };
    g.setTimeout = (fn) => { try { fn && fn(); } catch (e) { g.errori.push('setTimeout: ' + e.stack); } return 0; };
    g.addEventListener = (tipo, fn) => { if (tipo === 'storage') storage.push(fn); };
    g.Event = function (tipo) { this.type = tipo; };
    g.dispatchEvent = (ev) => storage.forEach(fn => fn(ev));
    g.history = { pushState() {}, replaceState() {}, back() {} }; g.navigator = {};
    g.location = { search: ricerca || '', replace() {}, href: '', reload() {} };
    g.localStorage = { getItem: k => (k in memoria ? memoria[k] : null), setItem: (k, v) => { memoria[k] = String(v); }, removeItem: k => { delete memoria[k]; } };
    const d = { nome, g, memoria, el: finto, elementi: el };
    d.riceve = (k, v) => {
      if (ascolti[k]) ascolti[k]({ val: () => v });
      else { if (v === null) delete memoria[k]; else memoria[k] = v; storage.forEach(fn => fn({ key: k, newValue: v })); }
    };
    g.firebase = { initializeApp: () => ({}), database: () => ({ ref: (k) => ({
        on: (ev, fn) => { ascolti[k] = fn; }, set: (v) => recapita(d, k, String(v)), update() {}, remove: () => recapita(d, k, null),
        once: () => Promise.resolve({ val: () => (k in server ? server[k] : null) }) }) }) };
    const ctx = vm.createContext(g);
    const h = fs.readFileSync(DIR + pagina, 'utf8');
    [...h.matchAll(/<script(?:\s+src="([^"]+)")?\s*>([\s\S]*?)<\/script>/g)].forEach(m => {
      const s = m[1];
      if (s) { if (/^https?:/.test(s)) return; const f = s.split('?')[0]; g.document.scripts.push({ src: f });
        if (!fs.existsSync(DIR + f)) { problemi.push(nome + ': manca ' + f); return; }
        try { vm.runInContext(fs.readFileSync(DIR + f, 'utf8'), ctx, { filename: f }); } catch (e) { problemi.push(nome + ': ' + f + ': ' + e.message); } }
      else { try { vm.runInContext(m[2], ctx, { filename: pagina + ':inline' }); } catch (e) { problemi.push(nome + ': inline: ' + e.message); } }
    });
    d.giro = () => g._cicli.forEach(fn => fn());
    dispositivi.push(d);
    return d;
  }
  const pagina = opz.pagina || 'app.html';
  const nomadi = avvia('NOMADI', 'NOMADS', pagina, '?fazione=nomadi');
  const pano = avvia('PANOCEANIA', 'PANOCEANIA', pagina, '?fazione=panoceania');
  const hub = avvia('HUB', 'HUB', 'calcolatore_hub.html', '');
  hub.g.hubPronto = true;
  const T = { server, nomadi, pano, hub, problemi };
  T.giro = (n) => { for (let i = 0; i < (n || 3); i++) { hub.giro(); nomadi.giro(); pano.giro(); } };
  // Schiera: i roster partono verso l'Hub dal mittente vero.
  T.schiera = (rN, rP, attiva) => {
    nomadi.g.roster = rN; pano.g.roster = rP;
    [nomadi, pano].forEach(d => { d.g.activeStructures = d.g.activeStructures || []; d.g.activeTerrains = d.g.activeTerrains || []; d.g.schieramentoCompletato = true; });
    nomadi.g.inviaSchieramentoAllHub('NOMADI', { roster: rN, strutture: [], terreni: nomadi.g.activeTerrains });
    pano.g.inviaSchieramentoAllHub('PANOCEANIA', { roster: rP, strutture: [], terreni: pano.g.activeTerrains });
    T.giro();
    if ((attiva || 'NOMADI') !== hub.g.gameState.activeFaction) hub.g.toggleTurn();
    else hub.g.localStorage.setItem(hub.g.MotoreN5.CANALI.HUB_TURNO, JSON.stringify({ attivo: hub.g.gameState.activeFaction }));
    T.giro();
  };
  T.profilo = (d, re) => { const tutti = [].concat(d.g.DB_NOMADI, d.g.DB_PANOCEANIA); const p = tutti.find(u => re.test(u.nome)); if (!p) throw new Error('profilo non trovato: ' + re); return JSON.parse(JSON.stringify(p)); };
  // Il giocatore sceglie l'unita` e apre il menu degli Ordini.
  T.apriMenu = (d, indice) => { const g = d.g; g.currentOrder = {}; g.spearheadUnit = g.roster[indice || 0]; g.selectedCoordinatedUnits = []; g.isCoordinated = false; g.procediAlleAzioni(); return d.el('action-list-container').innerHTML; };
  return T;
}



// ---------------------------------------------------------------------------

const DIR = (process.env.CARTELLA || __dirname).replace(/\/?$/, '/');
let passati = 0, falliti = 0;
function ok(c, d, visto) {
    if (c) { passati++; console.log('  ✓ ' + d); }
    else { falliti++; console.log('  ✗ ' + d + (visto !== undefined ? '  [visto: ' + JSON.stringify(visto) + ']' : '')); }
}
function sezione(titolo, fn) {
    console.log('\n=== ' + titolo + ' ===');
    try { fn(); } catch (e) { falliti++; console.log('  ✗ la sezione e` caduta: ' + e.message + ' ' + ((e.stack || '').split('\n')[1] || '').trim()); }
}
const tx = (h) => String(h).replace(/<(?:[^>"']|"[^"]*"|'[^']*')*>/g, ' ').replace(/\s+/g, ' ').trim();
const tr = (p, a) => Object.assign(JSON.parse(J(p)), { states: {}, deployState: 'NORMAL', state: 'ACTIVE', combatGroup: 1 }, a);
const ris = (T) => T.hub.el('step-resolution').style.display === 'block';
const tab = (T) => tx(T.hub.el('clash-container').innerHTML);
// La busta che parte verso l'Hub: azione, Burst, regole e opzioni (aroAtteso).
const spia = (g) => { const s = { n: 0, op: {}, p: null }; const M = g.MotoreN5, o = M.inviaCalcolo;
    M.inviaCalcolo = function (p, op) { s.n++; s.p = p.map(x => ({ az: x.azione, bd: x.burstDisponibile, b: (x.bersagli || []).map(b => b.burst), reg: x.regole })); s.op = op || {}; return o.apply(this, arguments); }; return s; };
const tavolo = (rN, rP, attiva) => { const T = creaTavolo(DIR); T.schiera(rN(T), rP(T), attiva); return T; };
const P_ = (T, re) => T.profilo(T.nomadi, re);


const premi = (d, id) => { const b = d.el(id); return typeof b.onclick === 'function' ? b.onclick() : undefined; };

// ---------------------------------------------------------------------------
const TRIP = /^Triphammer \(Heavy Shotgun, Heavy Rocket Launcher, Panzerfaust/;
const FUS = (T, id, a) => tr(T.profilo(T.pano, /^Fusilier \(Combi/), Object.assign({ id, alias: id === 'p1' ? 'F1' : id }, a || {}));
const bottoni = (h) => (String(h).match(/<button[^>]*class="bottone-arma[\s\S]*?<\/button>/g) || []);
const diArma = (h, re) => bottoni(h).find(b => re.test(b)) || '';
const classe = (b) => (b.match(/class="([^"]*)"/) || [])[1];
const onclickDi = (b) => (b.match(/onclick="([^"]*)"/) || [])[1] || '';
const passo = (T) => Object.keys(T.nomadi.elementi).filter(k => /^step-/.test(k) && T.nomadi.elementi[k].style.display && T.nomadi.elementi[k].style.display !== 'none');

// ---------------------------------------------------------------------------
// Un motore da solo, senza pagina, in un contesto suo (per R3-R5).
const motoreSolo = (conPagina) => {
    const g = { console: { log() {}, warn() {}, error() {} } }; g.window = g; g.globalThis = g;
    g.document = { title: 'NOMADS', addEventListener() {}, querySelectorAll: () => [], getElementById: () => null };
    g.localStorage = { getItem: () => null, setItem() {}, removeItem() {} }; g.setInterval = () => 0; g.setTimeout = () => 0; g.addEventListener = () => {};
    if (conPagina) { g._chiamate = []; g.aggiungiInfo = (...a) => g._chiamate.push(['aggiungi'].concat(a)); g.azzeraInfo = (s) => g._chiamate.push(['azzera', s]); }
    const c = vm.createContext(g);
    ['catalogo_n5.js', 'database_comune.js', 'motore_regole_n5.js'].forEach(f => vm.runInContext(fs.readFileSync(DIR + f, 'utf8'), c, { filename: f }));
    return g;
};
const titoliOrdine = (d) => Object.keys(d.elementi).map(k => String(d.elementi[k].innerHTML || ''))
    .join(' ').match(/<div class="intestazione-ordine"[^>]*>\s*<b[^>]*>[^<]*<\/b>/g) || [];


// ---------------------------------------------------------------------------
// Un DOM minimo per il riquadro: createElement con querySelector('.classe')
// che trova i tasti scritti nell innerHTML, body.appendChild / removeChild.
const installaDialoghi = (g) => {
    const body = g.document.body || (g.document.body = {}), figli = [];
    g.document.createElement = (tag) => ({ tag, className: '', innerHTML: '', style: {}, parentNode: null, attr: {}, _b: {},
        setAttribute(k, v) { this.attr[k] = v; }, getAttribute(k) { return k in this.attr ? this.attr[k] : null; },
        appendChild() {}, addEventListener() {}, remove() {}, cloneNode() { return this; }, classList: { add() {}, remove() {}, toggle() {} },
        querySelectorAll() { return []; },
        querySelector(sel) { const m = /^\.([\w-]+)$/.exec(sel); if (!m) return null;
            if (!new RegExp('class="(?:[^"]*\\s)?' + m[1] + '(?:\\s[^"]*)?"').test(this.innerHTML)) return null;
            return this._b[m[1]] || (this._b[m[1]] = { onclick: null }); } });
    body.appendChild = (x) => { figli.push(x); x.parentNode = body; return x; };
    body.removeChild = (x) => { const i = figli.indexOf(x); if (i >= 0) figli.splice(i, 1); x.parentNode = null; return x; };
    const aperti = () => figli.filter(x => x.className === 'dialogo-app-sfondo');
    const html = () => { const r = aperti()[0]; return r ? String(r.innerHTML) : ''; };
    return {
        aperti, html,
        testo: () => { const m = html().match(/class="dialogo-app-testo"[^>]*>([\s\S]*?)<\/div>/); return m ? m[1] : null; },
        titolo: () => { const m = html().match(/class="dialogo-app-titolo"[^>]*>([\s\S]*?)<\/div>/); return m ? m[1] : null; },
        tasti: () => (html().match(/class="huge-btn (dialogo-app-[a-z]+)"[^>]*>([^<]*)</g) || []).map(t => t.replace(/^class="huge-btn (dialogo-app-[a-z]+)"[^>]*>/, '$1:').replace(/<$/, '')),
        premi: (cls) => { const r = aperti()[0]; const b = r && r.querySelector('.' + cls); if (!b || typeof b.onclick !== 'function') return false; b.onclick(); return true; }
    };
};
// Il motore da solo, con (o senza) il DOM del riquadro.
const motoreDialoghi = (conDom) => {
    const g = { console: { log() {}, warn() {}, error() {} } }; g.window = g; g.globalThis = g;
    g.document = { title: 'NOMADS', addEventListener() {}, querySelectorAll: () => [], getElementById: () => null };
    g.localStorage = { getItem: () => null, setItem() {}, removeItem() {} }; g.setInterval = () => 0; g.setTimeout = () => 0; g.addEventListener = () => {};
    const D = conDom ? installaDialoghi(g) : null;
    const c = vm.createContext(g);
    ['catalogo_n5.js', 'database_comune.js', 'motore_regole_n5.js'].forEach(f => vm.runInContext(fs.readFileSync(DIR + f, 'utf8'), c, { filename: f }));
    return { g, M: g.MotoreN5, D };
};
const confirmNativo = (lista, risposta) => (function (m) { lista.push(String(m)); return risposta; }).bind(null);

sezione('Z1. M.mostraAvviso e M.chiediSiNo: il riquadro dell app, in coda; confirm sostituito = risposta subito', () => {
    // --- senza pagina
    const s = motoreDialoghi(false); const nat = [];
    ok(typeof s.M.mostraAvviso === 'function' && typeof s.M.chiediSiNo === 'function' && typeof s.M.dialogoAperto === 'function' && typeof s.M.eNativa === 'function',
       'il motore ha M.mostraAvviso, M.chiediSiNo, M.dialogoAperto, M.eNativa');
    s.g.__alertNativo = (t) => nat.push(t);
    s.M.mostraAvviso('Senza pagina');
    ok(J(nat) === J(['Senza pagina']) && s.M.dialogoAperto() === false, 'senza pagina (niente document.body) l avviso va a window.__alertNativo', nat);
    let cb0 = 'mai'; const r0 = s.M.chiediSiNo('Domanda?', {}, (r) => { cb0 = r; });
    ok(r0 === false && cb0 === false, 'senza pagina e senza confirm la domanda risponde NO, subito (e lo dice alla funzione)', [r0, cb0]);
    ok(s.M.eNativa(Boolean) === true && s.M.eNativa(confirmNativo([], true)) === true && s.M.eNativa(() => 1) === false,
       'M.eNativa: Boolean e una funzione legata (bind) sono native, una freccia no');

    // --- con la pagina e il confirm del browser
    const p = motoreDialoghi(true); const M = p.M, D = p.D, chieste = [];
    p.g.confirm = confirmNativo(chieste, true);
    let risp = [];
    const r1 = M.chiediSiNo('Si va e` avanti? <subito>', { titolo: 'PRIMA' }, (r) => risp.push(['prima', r]));
    ok(r1 === undefined && chieste.length === 0 && risp.length === 0, 'confirm nativo: chiediSiNo non chiama confirm e non risponde subito (restituisce undefined)', [r1, chieste, risp]);
    ok(D.aperti().length === 1 && M.dialogoAperto() === true, 'un riquadro .dialogo-app-sfondo nel body, M.dialogoAperto() vero', D.aperti().length);
    ok(/class="dialogo-app"/.test(D.html()) && /role="dialog"/.test(D.html()), 'dentro c e` il .dialogo-app (role="dialog")');
    ok(J(D.tasti()) === J(['dialogo-app-si:SÌ', 'dialogo-app-no:NO']), 'una domanda ha i tasti SÌ e NO', D.tasti());
    ok(D.titolo() === 'PRIMA', 'il titolo in .dialogo-app-titolo', D.titolo());
    ok(D.testo() === 'Si va è avanti? &lt;subito>', 'il testo con le lettere accentate (M.accenti) e il < protetto', D.testo());
    M.mostraAvviso('Il secondo e` in coda', { poi: () => risp.push(['avviso', true]) });
    ok(D.aperti().length === 1 && D.titolo() === 'PRIMA', 'un avviso mentre la domanda e` aperta va in coda: a schermo un riquadro solo');
    ok(D.premi('dialogo-app-si') && J(risp) === J([['prima', true]]), 'SÌ: la funzione riceve true', risp);
    ok(D.aperti().length === 1 && J(D.tasti()) === J(['dialogo-app-ok:OK']) && D.testo() === 'Il secondo è in coda' && D.titolo() === null,
       'chiuso il primo, si apre quello in coda: un avviso, col solo tasto OK e senza titolo', [D.tasti(), D.testo()]);
    ok(D.premi('dialogo-app-ok') && J(risp[1]) === J(['avviso', true]) && D.aperti().length === 0 && M.dialogoAperto() === false,
       'OK chiude l avviso e chiama opz.poi; la coda e` vuota, nessun riquadro', risp);
    let r3; M.chiediSiNo('Terza', (r) => { r3 = r; });
    ok(D.premi('dialogo-app-no') && r3 === false && D.aperti().length === 0, 'NO: la funzione riceve false (anche passata al posto di opz)', r3);
    let r4; M.chiediSiNo('Quarta', { si: 'CANCELLO', no: 'RESTO' }, (r) => { r4 = r; });
    ok(J(D.tasti()) === J(['dialogo-app-si:CANCELLO', 'dialogo-app-no:RESTO']), 'opz.si e opz.no cambiano le etichette dei tasti', D.tasti());
    D.premi('dialogo-app-si');
    // --- confirm sostituito da una prova
    const prova = []; p.g.confirm = (m) => { prova.push(String(m)); return true; };
    let r5; const ritorno5 = M.chiediSiNo('Va bene e` cosi`?', { titolo: 'TITOLO' }, (r) => { r5 = r; });
    ok(ritorno5 === true && r5 === true && D.aperti().length === 0, 'confirm sostituito: risponde subito, nessun riquadro, la funzione riceve la risposta', [ritorno5, r5]);
    ok(J(prova) === J(['TITOLO\n\nVa bene è così?']), 'la prova riceve titolo + riga vuota + testo, accentato', prova);
    p.g.confirm = (m) => { prova.push(String(m)); return false; };
    ok(M.chiediSiNo('Senza titolo') === false && prova[1] === 'Senza titolo', 'e senza titolo solo il testo; il NO della prova arriva come false', prova[1]);
    // --- l involucro di motore_core: decide __nativo
    const inv = (m) => true; inv.__conAccenti = true; inv.__nativo = false; p.g.confirm = inv;
    ok(M.chiediSiNo('x') === true && D.aperti().length === 0, 'confirm con __conAccenti e __nativo false (involucro di una prova): risposta subito');
    const inv2 = (m) => true; inv2.__conAccenti = true; inv2.__nativo = true; p.g.confirm = inv2;
    ok(M.chiediSiNo('y') === undefined && D.aperti().length === 1, 'confirm con __conAccenti e __nativo true (involucro del browser): riquadro');
    D.premi('dialogo-app-no');
    // --- un avviso con la pagina non usa __alertNativo
    const nat2 = []; p.g.__alertNativo = (t) => nat2.push(t);
    M.mostraAvviso('Con pagina', { titolo: 'ATTENZIONE' });
    ok(nat2.length === 0 && D.aperti().length === 1 && D.titolo() === 'ATTENZIONE', 'con la pagina l avviso e` un riquadro (opz.titolo), non la finestra del browser', nat2);
    D.premi('dialogo-app-ok');
});

sezione('Z2. L involucro di motore_core sulla pagina: alert.__nativo, l avviso nel riquadro', () => {
    const T = tavolo(T => [tr(P_(T, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' })], T => [FUS(T, 'p1')], 'NOMADI'); const N = T.nomadi.g;
    ok(N.alert.__conAccenti === true && N.alert.__nativo === false && N.confirm.__nativo === false && N.__alertNativo === undefined,
       'col banco (alert e confirm sostituiti): __nativo false, window.__alertNativo non nasce', [N.alert.__nativo, N.confirm.__nativo, typeof N.__alertNativo]);
    const V = creaTavolo(DIR, { nativi: true }); const G = V.nomadi.g;
    ok(V.problemi.length === 0, 'con alert e confirm del browser la pagina si carica senza problemi', V.problemi);
    ok(G.alert.__conAccenti === true && G.alert.__nativo === true && G.confirm.__nativo === true && typeof G.__alertNativo === 'function',
       'con alert e confirm del browser: __nativo true e window.__alertNativo c e`', [G.alert.__nativo, G.confirm.__nativo, typeof G.__alertNativo]);
    const D = installaDialoghi(G); G.alert_.length = 0;
    G.alert('Il pilota e` gia` uscito.');
    ok(D.aperti().length === 1 && D.testo() === 'Il pilota è già uscito.' && J(D.tasti()) === J(['dialogo-app-ok:OK']),
       'alert(...) sulla pagina vera: un riquadro con OK e il testo accentato', [D.testo(), D.tasti()]);
    ok(G.alert_.length === 0, 'e la finestra del browser non si apre', G.alert_);
    G.alert('Secondo avviso');
    ok(D.aperti().length === 1, 'un secondo alert aspetta in coda');
    D.premi('dialogo-app-ok');
    ok(D.aperti().length === 1 && D.testo() === 'Secondo avviso', 'OK: arriva il secondo', D.testo());
    D.premi('dialogo-app-ok');
    ok(D.aperti().length === 0 && G.MotoreN5.dialogoAperto() === false, 'OK: nessun riquadro');
    // senza body: l involucro torna alla finestra
    const corpo = G.document.body; G.document.body = null;
    G.alert('Senza corpo');
    G.document.body = corpo;
    ok(J(G.alert_) === J(['Senza corpo']) && D.aperti().length === 0, 'senza document.body l avviso va alla finestra del browser (com era)', G.alert_);
});

sezione('Z3. Foxhole: selectAction -> window.instradaAzione dopo la risposta', () => {
    const ALG = (T, a) => tr(P_(T, /^Alguacil \(Combi/), Object.assign({ id: 'n1', alias: 'Alg', states: { foxhole: true } }, a || {}));
    const prepara = (nativi, risposta, conFox) => {
        const T = creaTavolo(DIR, nativi ? { nativi: true } : {});
        T.schiera([conFox === false ? ALG(T, { states: {} }) : ALG(T)], [FUS(T, 'p1')], 'NOMADI');
        const N = T.nomadi.g, viste = [], domande = [];
        const D = nativi ? installaDialoghi(N) : null;
        if (!nativi) N.confirm = (m) => { domande.push(String(m)); return risposta; };
        const o = N.instradaAzione; N.instradaAzione = function (a, s) { viste.push([a, s]); return o.apply(this, arguments); };
        T.apriMenu(T.nomadi, 0); N.alert_.length = 0;
        return { T, N, D, viste, domande, fox: () => N.MotoreN5.statoBersaglio(N.roster.find(u => u.id === 'n1')).foxhole };
    };
    const M0 = creaTavolo(DIR).nomadi.g.MotoreN5;
    const F = M0.foxholeAllaDichiarazione({ states: { foxhole: true } }, 'MOVIMENTO', {});
    ok(F.puoCancellare === true && typeof F.domanda === 'string' && typeof F.seNonCancella === 'string', 'il motore: in Foxhole il Movimento puo` cancellare lo stato (domanda, seNonCancella)');
    // la prova risponde SI`
    let c = prepara(false, true);
    c.N.selectAction('MOVIMENTO', false);
    ok(c.domande.length === 1 && c.domande[0] === M0.accenti(F.domanda), 'confirm sostituito: la domanda una volta, il testo del catalogo accentato', c.domande[0] && c.domande[0].slice(0, 80));
    ok(J(c.viste) === J([['MOVIMENTO', false]]) && c.N.currentOrder.foxholeCancellato === true && c.fox() === false,
       'SÌ: foxholeCancellato true, lo stato e` tolto, e l Ordine prosegue subito (instradaAzione una volta)', [c.viste, c.N.currentOrder.foxholeCancellato, c.fox()]);
    // la prova risponde NO
    c = prepara(false, false);
    c.N.selectAction('MOVIMENTO', false);
    ok(J(c.viste) === J([['MOVIMENTO', false]]) && c.N.currentOrder.foxholeCancellato === false && c.fox() === true,
       'NO: foxholeCancellato false, resta in Foxhole, l Ordine prosegue', [c.viste, c.N.currentOrder.foxholeCancellato, c.fox()]);
    ok(c.N.alert_.some(a => a === '⚠️ ' + M0.accenti(F.seNonCancella)), 'NO: l avviso «⚠️ Resta in Foxhole...»', c.N.alert_);
    // senza Foxhole nessuna domanda
    c = prepara(false, true, false);
    c.N.selectAction('MOVIMENTO', false);
    ok(c.domande.length === 0 && J(c.viste) === J([['MOVIMENTO', false]]), 'senza Foxhole nessuna domanda, l Ordine prosegue', [c.domande.length, c.viste]);
    // la pagina vera: la domanda nel riquadro, l Ordine aspetta
    c = prepara(true);
    c.N.selectAction('MOVIMENTO', false);
    ok(c.D.aperti().length === 1 && c.viste.length === 0 && c.N.MotoreN5.dialogoAperto() === true && c.N.domande.length === 0,
       'confirm del browser: la domanda e` un riquadro, l Ordine ASPETTA (instradaAzione non ancora chiamata)', [c.D.aperti().length, c.viste]);
    ok(c.D.testo() === M0.accenti(F.domanda).replace(/&/g, '&amp;').replace(/</g, '&lt;') && J(c.D.tasti()) === J(['dialogo-app-si:SÌ', 'dialogo-app-no:NO']),
       'nel riquadro il testo della domanda, tasti SÌ e NO', c.D.tasti());
    c.D.premi('dialogo-app-si');
    ok(J(c.viste) === J([['MOVIMENTO', false]]) && c.N.currentOrder.foxholeCancellato === true && c.fox() === false,
       'al SÌ: lo stato e` tolto e l Ordine prosegue (instradaAzione una volta)', [c.viste, c.fox()]);
    c = prepara(true);
    c.N.selectAction('MOVIMENTO', false); c.D.premi('dialogo-app-no');
    ok(J(c.viste) === J([['MOVIMENTO', false]]) && c.N.currentOrder.foxholeCancellato === false && c.fox() === true,
       'al NO: resta in Foxhole e l Ordine prosegue', [c.viste, c.fox()]);
    ok(c.D.aperti().length === 1 && /Resta in Foxhole/.test(c.D.testo() || ''), 'e l avviso «Resta in Foxhole» arriva nel riquadro (alert del browser)', c.D.testo());
});

sezione('Z4. applicaRicarica(poi): poi dopo la risposta', () => {
    const rN = (T) => [tr(P_(T, TRIP), { id: 'n30', alias: 'Tri', usiSpesi: { PANZERFAUST: 2 } }), tr(P_(T, /^Salyut \(Deactivator/), { id: 'n43', alias: 'Sal' })];
    const prepara = (nativi, fn) => { const T = creaTavolo(DIR, nativi ? { nativi: true } : {}); T.schiera((fn || rN)(T), [FUS(T, 'p1')], 'NOMADI');
        const N = T.nomadi.g; const D = nativi ? installaDialoghi(N) : null; T.apriMenu(T.nomadi, 0); N.alert_.length = 0; return { T, N, D }; };
    // la prova al posto del confirm
    let c = prepara(false); let poi = 0; const dom = []; c.N.confirm = (m) => { dom.push(String(m)); return true; };
    const r1 = c.N.applicaRicarica(() => poi++);
    ok(r1 === true && poi === 1 && dom.length === 1, 'confirm sostituito: restituisce true e poi() e` chiamata una volta, subito', [r1, poi, dom.length]);
    ok(/^🔄 RELOAD — /.test(dom[0]) && /\n\nÈ nella Zona di Controllo/.test(dom[0]), 'la prova riceve «🔄 RELOAD — <nome>», riga vuota, la domanda', dom[0] && dom[0].slice(0, 60));
    const tri = c.N.roster.find(u => u.id === 'n30');
    ok(!tri.usiSpesi || !tri.usiSpesi.PANZERFAUST, 'SÌ: gli usi tornano (Panzerfaust ricaricato)', tri.usiSpesi);
    c = prepara(false); c.N.confirm = () => true;
    ok(c.N.applicaRicarica() === true, 'senza poi: restituisce true come prima');
    // niente da ricaricare: false e poi mai
    c = prepara(false, (T) => [tr(P_(T, TRIP), { id: 'n30', alias: 'Tri' })]); let poi2 = 0;
    ok(c.N.applicaRicarica(() => poi2++) === false && poi2 === 0 && /^⛔ /.test(c.N.alert_[0] || ''), 'niente da ricaricare: false, poi non chiamata, l avviso ⛔', c.N.alert_);
    // la pagina vera
    c = prepara(true); let poi3 = 0;
    const r3 = c.N.applicaRicarica(() => poi3++);
    ok(r3 === true && poi3 === 0 && c.D.aperti().length === 1, 'confirm del browser: restituisce true, poi ASPETTA, la domanda nel riquadro', [r3, poi3]);
    ok(/^🔄 RELOAD — /.test(c.D.titolo() || '') && /^È nella Zona di Controllo/.test(c.D.testo() || ''), 'titolo «🔄 RELOAD — <nome>», testo della domanda', [c.D.titolo(), (c.D.testo() || '').slice(0, 40)]);
    c.D.premi('dialogo-app-no');
    ok(poi3 === 1 && c.N.currentOrder.ricaricaFallita === true, 'al NO: Requisito fallito (ricaricaFallita) e poi() chiamata', [poi3, c.N.currentOrder.ricaricaFallita]);
    ok(c.D.aperti().length === 1 && /Requisito fallito/.test(c.D.testo() || ''), 'e l avviso del Requisito fallito nel riquadro', c.D.testo());
});

sezione('Z5. M.armiPiazzabili: l arma finita resta un tasto spento, la spiegazione nella ⓘ', () => {
    const T0 = creaTavolo(DIR); const M = T0.nomadi.g.MotoreN5;
    const hc = (usi) => tr(T0.profilo(T0.nomadi, /^Hellcat \(Paramedic\)$/), { id: 'n9', alias: 'Hc', usiSpesi: usi || {} });
    const piena = M.armiPiazzabili(hc());
    ok(piena.armi.length === 1 && piena.armi[0].nome === 'Deployable Repeater' && piena.armi[0].usi.residui === 3 && !piena.escluse.some(x => x.scarica),
       'Hellcat (Paramedic): Deployable Repeater 3/3, nessuna arma scarica', piena);
    const e = M.armiPiazzabili(hc({ 'DEPLOYABLE REPEATER': 3 }));
    const x = e.escluse[0] || {};
    ok(e.armi.length === 0 && e.escluse.length === 1 && x.scarica === true, 'usi finiti: non fra le armi, in escluse con scarica true', e);
    ok(x.usi && x.usi.totali === 3 && x.usi.residui === 0, 'escluse[0].usi: totali 3, residui 0', x.usi);
    ok(/^Deployable Repeater: usi esauriti/.test(x.motivo || '') && /^usi esauriti/.test(x.spiegazione || '') && x.motivo === 'Deployable Repeater: ' + x.spiegazione,
       'motivo col nome davanti (come prima), spiegazione senza', [x.motivo, x.spiegazione]);
    // sulla pagina
    const T = tavolo(T => [hc({ 'DEPLOYABLE REPEATER': 3 })], T => [FUS(T, 'p1')], 'NOMADI'); const N = T.nomadi.g;
    const note = []; const o = N.aggiungiInfo; N.aggiungiInfo = function () { note.push([].slice.call(arguments)); return o.apply(this, arguments); };
    T.apriMenu(T.nomadi, 0); N.coordUnits = [N.roster[0]]; N.coordIndex = 0; N.currentOrder.unit = N.roster[0];
    N.mostraArmiPiazzabili();
    const h = String(T.nomadi.el('weapon-buttons-container').innerHTML);
    const tasto = (h.match(/<button class="huge-btn tasto-scarico"[\s\S]*?<\/button>/) || [''])[0];
    ok(tasto !== '' && /data-nota="scarico-0"/.test(tasto), 'un tasto .tasto-scarico con data-nota="scarico-0"', h.slice(0, 200));
    ok(/📦 Deployable Repeater/.test(tx(tasto)) && /0\/3 usi/.test(tx(tasto)) && !/onclick=/.test(tasto), 'il tasto dice «📦 Deployable Repeater» e «0/3 usi», senza onclick', tx(tasto));
    ok(!/non ha equipaggiamento da piazzare/.test(h), 'niente «non ha equipaggiamento da piazzare»: c e` il tasto spento');
    const n = note.find(a => a[0] === 'step-weapon' && a[1] === 'Deployable Repeater');
    ok(n && /^usi esauriti/.test(n[2]) && n[3] && n[3].tipo === 'nonpuo' && n[3].tasto === 'scarico-0', 'la nota nella ⓘ: step-weapon, il nome, la spiegazione, tipo nonpuo, tasto scarico-0', n);
});

sezione('Z6. M.segnalinoSenzaNumero: AD come HIDDEN; M.etichettaMarker solo per HIDDEN', () => {
    const M = creaTavolo(DIR).nomadi.g.MotoreN5;
    const ad = M.segnalinoSenzaNumero({ deployState: 'AD' });
    ok(ad && ad.tipo === 'AD' && ad.emoji === '🪂' && ad.immagineComune === 'img/icon_airborne.png' && ad.etichetta === 'SCHIERAMENTO AEREO', 'AD: tipo AD, 🪂, img/icon_airborne.png, SCHIERAMENTO AEREO', ad);
    ok(ad.immagine === 'img/nomadi/icon_airborne.png', 'sulla pagina nomade l icona nella cartella dei Nomadi', ad.immagine);
    ok(M.segnalinoSenzaNumero({ deployState: 'AD' }, 'PANOCEANIA').immagine === 'img/panoceania/icon_airborne.png', 'con la fazione PANOCEANIA nella sua cartella');
    ok(J(M.segnalinoSenzaNumero({ deployState: 'RESERVE' })) === J(ad), 'RESERVE come AD');
    const hi = M.segnalinoSenzaNumero({ deployState: 'HIDDEN' });
    ok(hi && hi.tipo === 'HIDDEN' && hi.immagineComune === 'img/icon_hidden.png', 'HIDDEN come prima', hi);
    ok(M.segnalinoSenzaNumero({ deployState: 'NORMAL' }) === null && M.segnalinoSenzaNumero(null) === null, 'NORMAL e null: nessun segnalino');
    ok(M.etichettaMarker({ deployState: 'AD' }) === null && M.etichettaMarker({ deployState: 'HIDDEN' }) === 'HIDDEN', 'M.etichettaMarker: null per AD, «HIDDEN» per HIDDEN');
});

// Il motore e calcolatore_math da soli (come test_adattatore).
const motoreMath = () => {
    const g = { console: { log() {}, warn() {}, error() {} } }; g.window = g; g.globalThis = g;
    g.document = { title: 'HUB', addEventListener() {}, querySelectorAll: () => [], getElementById: () => null };
    g.localStorage = { getItem: () => null, setItem() {}, removeItem() {} }; g.setInterval = () => 0; g.setTimeout = () => 0; g.addEventListener = () => {};
    const c = vm.createContext(g);
    ['catalogo_n5.js', 'database_comune.js', 'motore_regole_n5.js', 'calcolatore_math.js'].forEach(f => vm.runInContext(fs.readFileSync(DIR + f, 'utf8'), c, { filename: f }));
    return g;
};
sezione('Z7. calcolatore_math: lato.dettaglio e lato.tiroSalvezza (i dati, non l HTML)', () => {
    const g = motoreMath(), M = g.MotoreN5;
    const alg = { alias: 'Alguacil', bs: 11, cc: 13, ph: 10, wip: 12, arm: 1, bts: 0, skills: '', states: {}, combatGroup: 1 };
    const fus = { alias: 'Fusilier', bs: 12, cc: 13, ph: 10, wip: 13, arm: 1, bts: 0, skills: '', states: {}, combatGroup: 1 };
    const R = (att, dif, aro) => { g.gameState = { activeFaction: 'NOMADI', nomads: [att], panoceania: [dif] }; g.latestAroData = aro || [];
        return g.generaRisoluzioneDaDati({ attacchi: [{ attaccante: att.alias, azione: M.AZIONI.BS_ATTACK, arma: M.profiloArma('Combi Rifle'),
            bersagli: [{ name: dif.alias, burst: 3, rangeIndex: 2, rangeMod: -3, cover: true, ammo: 'N', terrain: 'NESSUNO' }] }] })[0]; };
    const s = R(alg, fus, [{ nome: 'Fusilier', azione: 'DODGE', hasLoF: true, burst: 1 }]);
    const d = s.attivo.dettaglio || {};
    ok(d.successo && d.successo.attributo === 'BS' && d.successo.base === 11, 'attivo: successo.attributo BS, base 11', d.successo);
    ok(d.successo && J(d.successo.voci.map(v => [v.fonte, v.valore])) === J([['gittata', -3], ['copertura', -3]]) && d.successo.voci.every(v => typeof v.motivo === 'string'),
       'successo.voci: gittata -3, copertura -3, ognuna col motivo (la base non e` fra le voci)', d.successo && d.successo.voci);
    ok(d.successo && J(d.successo.nonApplicati) === '[]', 'successo.nonApplicati vuoto');
    ok(d.dadi && d.dadi.base === 3 && d.dadi.baseMotivo === 'B 3' && J(d.dadi.voci) === '[]', 'dadi: base 3, «B 3»', d.dadi);
    const dr = s.reattivo.dettaglio || {};
    ok(dr.successo && dr.successo.attributo === 'PH' && dr.successo.base === 10 && dr.dadi && dr.dadi.base === 1 && /Turno Reattivo/.test(dr.dadi.baseMotivo),
       'reattivo (Schivata): PH 10, 1 dado «In Turno Reattivo il Burst è 1»', dr);
    ok(s.attivo.tiroSalvezza && s.attivo.tiroSalvezza.nessuno === true && typeof s.attivo.tiroSalvezza.testo === 'string',
       'attivo.tiroSalvezza: nessuno (la Schivata non fa danno) col testo', s.attivo.tiroSalvezza);
    const ts = s.reattivo.tiroSalvezza || {}; const r0 = (ts.righe || [])[0] || {};
    ok(ts.munizione === 'N' && ts.combinato === false && (ts.righe || []).length === 1, 'reattivo.tiroSalvezza: munizione N, una riga', ts);
    ok(r0.attributo === 'ARM' && r0.successo === 11 && r0.dadi === 1 && r0.impossibile === false && /Critico/.test(r0.critico || ''), 'la riga: ARM, Successo al 11, 1 dado, il critico', r0);
    ok(r0.dettaglioSuccesso && r0.dettaglioSuccesso.base === 1 && J(r0.dettaglioSuccesso.voci.map(v => [v.fonte, v.valore])) === J([['copertura', 3], ['ps', 7]]),
       'dettaglioSuccesso: base ARM 1, copertura +3, PS 7', r0.dettaglioSuccesso);
    ok(r0.dettaglioDadi && r0.dettaglioDadi.base === 1 && /munizione N/.test(r0.dettaglioDadi.baseMotivo), 'dettaglioDadi: 1 per colpo (munizione N)', r0.dettaglioDadi);
    ok(J(ts.esito) === '[]' && J(ts.marker) === '[]' && Array.isArray(ts.note) && /Critico aggiunge 1/.test(ts.notaCritico), 'esito e marker vuoti, notaCritico', ts.notaCritico);
    // Marksmanship: la Copertura NON conta, va in nonApplicati col perche`
    const m = R(Object.assign({}, alg, { skills: 'Marksmanship' }), fus, []);
    const dm = m.attivo.dettaglio.successo;
    ok(!dm.voci.some(v => v.fonte === 'copertura') && J(dm.nonApplicati) === J([{ fonte: 'copertura', motivo: 'Copertura Parziale', valore: -3, perche: 'Marksmanship' }]),
       'Marksmanship: la Copertura fra i nonApplicati {motivo «Copertura Parziale», valore -3, perche «Marksmanship»}', dm.nonApplicati);
    ok(m.attivo.mod === s.attivo.mod + 3, 'e il numero sale di 3', [m.attivo.mod, s.attivo.mod]);
    // senza reazione
    ok(J(m.reattivo.dettaglio) === J({ successo: null, dadi: null }), 'chi non reagisce: dettaglio { successo: null, dadi: null }', m.reattivo.dettaglio);
    // i campi di prima restano
    ok(typeof s.attivo.dettagliMod === 'string' && typeof s.reattivo.salvezza === 'string', 'i campi di prima (dettagliMod, salvezza HTML) restano');
});

console.log(`\n──────────────\n${passati} passati, ${falliti} falliti\n`);
// L harness lascia aperto il ciclo delle promesse (firebase finto): si esce qui.
process.exit(falliti ? 1 : 0);
