// @versione 2026-10-31.2 | test_novita_28ott.js | proprieta`: chat TEST
// 2026-10-31.2 (giro 27, ordine_attacco_bs 31.1, app.html 31.2): T1 GIRATA; la scala ha in piu`
//    --fs-titolo-2 (28px), usata una volta (la tendina delle munizioni).
// 2026-10-31.1: (giro 26, motore 30.1 e moduli 30.1/31.1) il FUORI della barra senza scritta, col
//    title «Fuori gittata» (R4 e la barra della scheda); U2 conta 454 (il tasto scarico di
//    Piazzare); T1 DIFETTO APERTO: tre font-size in px in ordine_attacco_bs.
// 2026-10-28.6: i quattro difetti del piano grafico (moduli 28.4, motore 28.7,
//    giro 19): U2 conta 453 var(--mn-...) (+49 --mn-ordine-*); V1 i titoli dei MOD
//    di 12 Ordini da M.intestazioneOrdine (ATTACCO GUIDATO, SCHIVATA, RESET), V2 il
//    Movimento Cauto rosso, V3 le etichette dei bersagli di Guidato e Speculativo
//    nella fascia bassa, V4 la scelta dell alleato del Supporto con la foto.
// 2026-10-28.5: un giallo solo per il SI` «colpo annullato» (motore 28.6, BS 28.5,
//    giro 18): S1 riconosce il tasto acceso da var(--mn-attenzione,...); U2 conta
//    456 var(--mn-...) scritti nei moduli (i 3 del tasto ora da M.stileTavolozza);
//    U6 M.stileTavolozza, e lo stesso stile sulla domanda a Sagoma singola e su
//    quella per lettera.
// 2026-10-28.4: colori raggruppati (MOTORE 28.5, giro 17): S1 riconosce il tasto
//    acceso da var(--mn-acceso,...) (prima #ffdd00); U1 M.TAVOLOZZA e M.colore,
//    U2 M.applicaTavolozza e i 459 var(--mn-...) dei moduli, U3 M.COLORI_ORDINE,
//    M.CATEGORIE_ORDINE e M.coloreOrdine, U4 M.colOrdine (getter, --mn-ordine-*),
//    U5 sulla pagina: intestazioni nel colore della categoria, Soppressione rossa.
// 2026-10-28.3: snellimento dei moduli (MOTORE, 28 ottobre, giro 16): T1 nessun
//    font-size in px nei 17 ordine_*.js e in logica_stati, solo var(--fs-*) della
//    scala di :root di app.html; T2 M.stileColore('si' / 'attenzione') e gli 11
//    punti dei moduli, sulla pagina il tasto della Sagoma Diretta.
// 2026-10-28.2: D07 del collaudo grafico (motore 2026-10-28.3, ordine_attacco_bs
//    2026-10-28.2). Nuove S1-S5: la domanda «alleato sotto la Sagoma» una sola,
//    per lettera (partenza, tocco, A+B, controprove); Fumo ed Eclipse a lettere
//    senza domanda; il Coordinato che azzera la risposta; i colori della barra
//    nel bottone (MOD 0 azzurro) come .seg-1..4; M.rigaAttesaAro; S6, SG-09 del
//    piano (revisione 50) sulla pagina intera.
// ============================================================================
//  LA CONSEGNA DI MOTORE DEL 28 OTTOBRE (motore 2026-10-28.1) — node test_novita_28ott.js
//  ---------------------------------------------------------------------------
//  Prove nuove della chat TEST, ognuna con la sua controprova:
//   R1. Intestazioni degli Ordini senza icone (M.intestazioneOrdine,
//       M.senzaIconaIniziale), sulle pagine intere.
//   R2. Le note (ⓘ) sono dell'Ordine: un Ordine nuovo azzera step-weapon,
//       step-wait-aro e step-modifiers (motore_core, selectAction); la seconda
//       meta` no. E i tipi spenti nelle opzioni delle note le nascondono.
//   R3. Il bottone dell'arma su scala comune di 96": su tutte le armi con
//       bande, celle contigue da 0 come M.gittateRaggruppate, larghezza
//       proporzionale, cella-fuori fino a 96.
//   R4. M.barraGittata: un .range-seg per banda (indice = banda), FUORI in
//       coda, n+1 confini; su tutte le armi con bande.
//   R5. M.nota / M.azzeraNote senza app.html (window.INFO) e con app.html
//       (window.aggiungiInfo).
//   R6. BS-31 del piano (revisione 49), l'Atteso sulla pagina intera.
//   R7. BS-16 e BS-16b (revisione 49): sempre al pieno, la voce Burst nella ⓘ.
//   S1-S5. D07 (28 ottobre, giro 15): la domanda per lettera, Fumo ed Eclipse,
//       il Coordinato, i colori della barra del bottone, M.rigaAttesaAro.
//  L'harness creaTavolo e` quello di test_novita_26ott.js (copiato: ogni banco
//  basta a se stesso).
//  USO:  CARTELLA=/percorso/ node test_novita_28ott.js
// ============================================================================
const fs=require("fs"),vm=require("vm");const J=JSON.stringify;
function creaTavolo(DIR, opz) {
  opz = opz || {};
  DIR = DIR.replace(/\/?$/, '/');
  const server = {}, dispositivi = [], problemi = [];
  function recapita(da, chiave, valore) {
    if (valore === null) delete server[chiave]; else server[chiave] = valore;
    dispositivi.forEach(d => { if (d !== da) d.riceve(chiave, valore); });
  }
  function avvia(nome, titolo, pagina, ricerca) {
    const memoria = {}, el = {}, ascolti = {}, storage = [];
    const g = { errori: [], avvisi: [], alert_: [] };
    g.console = { log: () => {}, warn: (...a) => g.avvisi.push(a.map(String).join(' ')), error: (...a) => g.errori.push(a.map(x => (x && x.stack) || String(x)).join(' ')) };
    g.window = g; g.globalThis = g;
    const finto = (id) => { if (!el[id]) el[id] = { id, innerHTML: '', innerText: '', style: {}, value: '', checked: false, disabled: false, options: [],
        appendChild() {}, addEventListener() {}, remove() {}, setAttribute() {}, getAttribute() { return null; }, scrollTop: 0, scrollHeight: 0,
        classList: { add() {}, remove() {}, toggle() {} }, cloneNode() { return this; }, parentNode: { replaceChild() {}, insertBefore() {} },
        querySelector() { return null; }, querySelectorAll() { return []; } }; return el[id]; };
    let t = titolo;
    g.document = { get title() { return t; }, set title(v) { t = v; }, documentElement: { setAttribute() {} }, scripts: [], body: finto('body'),
        getElementById: finto, createElement: () => finto('nuovo_' + Math.random()), querySelector: (s) => finto('q:' + s), querySelectorAll: () => [],
        addEventListener() {}, write() {} };
    g.alert = (m) => g.alert_.push(String(m)); g.confirm = () => true; g.prompt = () => 'motivo di prova'; g.scrollTo = () => {};
    g._cicli = []; g.setInterval = (fn) => { g._cicli.push(fn); return g._cicli.length; };
    g.setTimeout = (fn) => { try { fn && fn(); } catch (e) { g.errori.push('setTimeout: ' + e.stack); } return 0; };
    g.addEventListener = (tipo, fn) => { if (tipo === 'storage') storage.push(fn); };
    g.Event = function (tipo) { this.type = tipo; };
    g.dispatchEvent = (ev) => storage.forEach(fn => fn(ev));
    g.history = { pushState() {}, replaceState() {}, back() {} }; g.navigator = {};
    g.location = { search: ricerca || '', replace() {}, href: '', reload() {} };
    g.localStorage = { getItem: k => (k in memoria ? memoria[k] : null), setItem: (k, v) => { memoria[k] = String(v); }, removeItem: k => { delete memoria[k]; } };
    const d = { nome, g, memoria, el: finto, elementi: el };
    d.riceve = (k, v) => {
      if (ascolti[k]) ascolti[k]({ val: () => v });
      else { if (v === null) delete memoria[k]; else memoria[k] = v; storage.forEach(fn => fn({ key: k, newValue: v })); }
    };
    g.firebase = { initializeApp: () => ({}), database: () => ({ ref: (k) => ({
        on: (ev, fn) => { ascolti[k] = fn; }, set: (v) => recapita(d, k, String(v)), update() {}, remove: () => recapita(d, k, null),
        once: () => Promise.resolve({ val: () => (k in server ? server[k] : null) }) }) }) };
    const ctx = vm.createContext(g);
    const h = fs.readFileSync(DIR + pagina, 'utf8');
    [...h.matchAll(/<script(?:\s+src="([^"]+)")?\s*>([\s\S]*?)<\/script>/g)].forEach(m => {
      const s = m[1];
      if (s) { if (/^https?:/.test(s)) return; const f = s.split('?')[0]; g.document.scripts.push({ src: f });
        if (!fs.existsSync(DIR + f)) { problemi.push(nome + ': manca ' + f); return; }
        try { vm.runInContext(fs.readFileSync(DIR + f, 'utf8'), ctx, { filename: f }); } catch (e) { problemi.push(nome + ': ' + f + ': ' + e.message); } }
      else { try { vm.runInContext(m[2], ctx, { filename: pagina + ':inline' }); } catch (e) { problemi.push(nome + ': inline: ' + e.message); } }
    });
    d.giro = () => g._cicli.forEach(fn => fn());
    dispositivi.push(d);
    return d;
  }
  const pagina = opz.pagina || 'app.html';
  const nomadi = avvia('NOMADI', 'NOMADS', pagina, '?fazione=nomadi');
  const pano = avvia('PANOCEANIA', 'PANOCEANIA', pagina, '?fazione=panoceania');
  const hub = avvia('HUB', 'HUB', 'calcolatore_hub.html', '');
  hub.g.hubPronto = true;
  const T = { server, nomadi, pano, hub, problemi };
  T.giro = (n) => { for (let i = 0; i < (n || 3); i++) { hub.giro(); nomadi.giro(); pano.giro(); } };
  // Schiera: i roster partono verso l'Hub dal mittente vero.
  T.schiera = (rN, rP, attiva) => {
    nomadi.g.roster = rN; pano.g.roster = rP;
    [nomadi, pano].forEach(d => { d.g.activeStructures = d.g.activeStructures || []; d.g.activeTerrains = d.g.activeTerrains || []; d.g.schieramentoCompletato = true; });
    nomadi.g.inviaSchieramentoAllHub('NOMADI', { roster: rN, strutture: [], terreni: nomadi.g.activeTerrains });
    pano.g.inviaSchieramentoAllHub('PANOCEANIA', { roster: rP, strutture: [], terreni: pano.g.activeTerrains });
    T.giro();
    if ((attiva || 'NOMADI') !== hub.g.gameState.activeFaction) hub.g.toggleTurn();
    else hub.g.localStorage.setItem(hub.g.MotoreN5.CANALI.HUB_TURNO, JSON.stringify({ attivo: hub.g.gameState.activeFaction }));
    T.giro();
  };
  T.profilo = (d, re) => { const tutti = [].concat(d.g.DB_NOMADI, d.g.DB_PANOCEANIA); const p = tutti.find(u => re.test(u.nome)); if (!p) throw new Error('profilo non trovato: ' + re); return JSON.parse(JSON.stringify(p)); };
  // Il giocatore sceglie l'unita` e apre il menu degli Ordini.
  T.apriMenu = (d, indice) => { const g = d.g; g.currentOrder = {}; g.spearheadUnit = g.roster[indice || 0]; g.selectedCoordinatedUnits = []; g.isCoordinated = false; g.procediAlleAzioni(); return d.el('action-list-container').innerHTML; };
  return T;
}



// ---------------------------------------------------------------------------
const DIR = (process.env.CARTELLA || __dirname).replace(/\/?$/, '/');
let passati = 0, falliti = 0;
function ok(c, d, visto) {
    if (c) { passati++; console.log('  ✓ ' + d); }
    else { falliti++; console.log('  ✗ ' + d + (visto !== undefined ? '  [visto: ' + JSON.stringify(visto) + ']' : '')); }
}
function sezione(titolo, fn) {
    console.log('\n=== ' + titolo + ' ===');
    try { fn(); } catch (e) { falliti++; console.log('  ✗ la sezione e` caduta: ' + e.message + ' ' + ((e.stack || '').split('\n')[1] || '').trim()); }
}
const tx = (h) => String(h).replace(/<(?:[^>"']|"[^"]*"|'[^']*')*>/g, ' ').replace(/\s+/g, ' ').trim();
const tr = (p, a) => Object.assign(JSON.parse(J(p)), { states: {}, deployState: 'NORMAL', state: 'ACTIVE', combatGroup: 1 }, a);
const ris = (T) => T.hub.el('step-resolution').style.display === 'block';
const tab = (T) => tx(T.hub.el('clash-container').innerHTML);
// La busta che parte verso l'Hub: azione, Burst, regole e opzioni (aroAtteso).
const spia = (g) => { const s = { n: 0, op: {}, p: null }; const M = g.MotoreN5, o = M.inviaCalcolo;
    M.inviaCalcolo = function (p, op) { s.n++; s.p = p.map(x => ({ az: x.azione, bd: x.burstDisponibile, b: (x.bersagli || []).map(b => b.burst), reg: x.regole })); s.op = op || {}; return o.apply(this, arguments); }; return s; };
const tavolo = (rN, rP, attiva) => { const T = creaTavolo(DIR); T.schiera(rN(T), rP(T), attiva); return T; };
const P_ = (T, re) => T.profilo(T.nomadi, re);


const premi = (d, id) => { const b = d.el(id); return typeof b.onclick === 'function' ? b.onclick() : undefined; };

// ---------------------------------------------------------------------------
const TRIP = /^Triphammer \(Heavy Shotgun, Heavy Rocket Launcher, Panzerfaust/;
const FUS = (T, id, a) => tr(T.profilo(T.pano, /^Fusilier \(Combi/), Object.assign({ id, alias: id === 'p1' ? 'F1' : id }, a || {}));
const bottoni = (h) => (String(h).match(/<button[^>]*class="bottone-arma[\s\S]*?<\/button>/g) || []);
const diArma = (h, re) => bottoni(h).find(b => re.test(b)) || '';
const classe = (b) => (b.match(/class="([^"]*)"/) || [])[1];
const onclickDi = (b) => (b.match(/onclick="([^"]*)"/) || [])[1] || '';
const passo = (T) => Object.keys(T.nomadi.elementi).filter(k => /^step-/.test(k) && T.nomadi.elementi[k].style.display && T.nomadi.elementi[k].style.display !== 'none');

// ---------------------------------------------------------------------------
// Un motore da solo, senza pagina, in un contesto suo (per R3-R5).
const motoreSolo = (conPagina) => {
    const g = { console: { log() {}, warn() {}, error() {} } }; g.window = g; g.globalThis = g;
    g.document = { title: 'NOMADS', addEventListener() {}, querySelectorAll: () => [], getElementById: () => null };
    g.localStorage = { getItem: () => null, setItem() {}, removeItem() {} }; g.setInterval = () => 0; g.setTimeout = () => 0; g.addEventListener = () => {};
    if (conPagina) { g._chiamate = []; g.aggiungiInfo = (...a) => g._chiamate.push(['aggiungi'].concat(a)); g.azzeraInfo = (s) => g._chiamate.push(['azzera', s]); }
    const c = vm.createContext(g);
    ['catalogo_n5.js', 'database_comune.js', 'motore_regole_n5.js'].forEach(f => vm.runInContext(fs.readFileSync(DIR + f, 'utf8'), c, { filename: f }));
    return g;
};
const titoliOrdine = (d) => Object.keys(d.elementi).map(k => String(d.elementi[k].innerHTML || ''))
    .join(' ').match(/<div class="intestazione-ordine"[^>]*>\s*<b[^>]*>[^<]*<\/b>/g) || [];

sezione('R1. Intestazioni degli Ordini senza icone (MOTORE 2026-10-28.1)', () => {
    const T = tavolo(T => [tr(P_(T, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' }), tr(P_(T, /^Zero \(Hacker/), { id: 'n2', alias: 'Zero' }),
                           tr(P_(T, /^Alguacil \(Paramedic/), { id: 'n3', alias: 'Med' }), tr(P_(T, /^Puppet Masters/), { id: 'n4', alias: 'Posa' }),
                           tr(P_(T, /^Alguacil \(Combi/), { id: 'n5', alias: 'Ferito', states: { unconscious: true } })],
                     T => [FUS(T, 'p1'), tr(T.profilo(T.pano, /^Fusilier \(Combi/), { id: 'p2', alias: 'Ombra', deployState: 'CAMO', states: { camo: true } })], 'NOMADI');
    const N = T.nomadi.g, M = N.MotoreN5;
    const visti = [];
    [[0, 'ATTACCO BS'], [1, 'HACKING'], [2, 'MEDICO_INGEGNERE'], [0, 'ATTACCO CC'], [3, 'PIAZZARE EQUIPAGGIAMENTO'], [0, 'SCOPRIRE'], [0, 'SCHIVATA']].forEach(([i, az]) => {
        Object.keys(T.nomadi.elementi).forEach(k => { T.nomadi.elementi[k].innerHTML = ''; });
        T.apriMenu(T.nomadi, i); N.selectAction(az, false);
        titoliOrdine(T.nomadi).forEach(h => visti.push({ az, t: tx(h) }));
        N.tornaAlRadar(); T.giro();
    });
    const testi = [...new Set(visti.map(v => v.t))];
    const conIcona = testi.filter(t => M.senzaIconaIniziale(t) !== t || /^[^A-Za-z0-9À-ÿ]/.test(t));
    ok(testi.length >= 4 && conIcona.length === 0, 'su sette Ordini, nessuna intestazione comincia con un icona (' + testi.length + ' intestazioni)', { testi, conIcona });
    ok(['ATTACCO BS', 'INFOGUERRA', 'SUPPORTO'].every(t => testi.indexOf(t) >= 0), '  e le intestazioni ci sono: ATTACCO BS, INFOGUERRA, SUPPORTO', testi);
    // CONTROPROVA: la regola sta nel motore, anche se un modulo l icona la passa.
    const h = M.intestazioneOrdine({ titolo: '🎯 ATTACCO BS', nota: 'n' });
    ok(tx(h).indexOf('ATTACCO BS') === 0 && !/🎯/.test(h), 'CONTROPROVA: M.intestazioneOrdine({ titolo: «🎯 ATTACCO BS» }) scrive «ATTACCO BS»', tx(h));
    ok(M.senzaIconaIniziale('IDLE ⚠️') === 'IDLE ⚠️' && M.senzaIconaIniziale('⚠️ IDLE') === 'IDLE' && M.senzaIconaIniziale('🩺 SUPPORTO') === 'SUPPORTO',
       '  e toglie solo le icone IN TESTA: «IDLE ⚠️» resta, «⚠️ IDLE» e «🩺 SUPPORTO» si puliscono');
});

sezione('R2. Le note (ⓘ) sono dell Ordine: un Ordine nuovo le azzera, la seconda meta` no', () => {
    const T = tavolo(T => [tr(P_(T, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' }), tr(P_(T, /^Clockmaker \(Engineer\)/), { id: 'n2', alias: 'Clock' })],
                     T => [FUS(T, 'p1')], 'NOMADI');
    const N = T.nomadi.g;
    const gizmo = () => N.vociInfo('step-weapon').filter(v => /^GizmoKit non utilizzabile/.test(v.titolo));
    T.apriMenu(T.nomadi, 1); N.selectAction('ATTACCO BS', false);
    const g1 = gizmo();
    ok(g1.length === 1 && g1[0].tipo === 'nonpuo' && /SUPPORTO/.test(g1[0].testo), 'Ordine 1, Clockmaker in ATTACCO BS: nella ⓘ «GizmoKit non utilizzabile» (nonpuo)', N.vociInfo('step-weapon').map(v => v.titolo));
    // I tipi spenti nelle opzioni delle note (scegli_fazione.html) le nascondono.
    N.localStorage.setItem('opzioni_note', J({ dove: 'info', tipi: { nonpuo: false } }));
    ok(gizmo().length === 0 && (N.INFO['step-weapon'] || []).some(v => /^GizmoKit/.test(v.titolo)), '  con «PERCHÉ NON SI PUÒ» spento la voce non si mostra (ma resta depositata)');
    N.localStorage.setItem('opzioni_note', J({ dove: 'info', tipi: { nonpuo: true } }));
    ok(gizmo().length === 1, '  CONTROPROVA: riacceso, torna');
    // La seconda meta` dello stesso Ordine non azzera.
    N.currentOrder.isSecondHalf = true; N.selectAction('MOVIMENTO', true);
    ok(gizmo().length === 1, 'CONTROPROVA: la seconda meta` (MOVIMENTO) dello stesso Ordine non tocca le note', N.vociInfo('step-weapon').map(v => v.titolo));
    N.tornaAlRadar(); T.giro();
    // Un Ordine nuovo, con un modulo che non ne deposita.
    T.apriMenu(T.nomadi, 0); N.selectAction('MOVIMENTO', false);
    ok(N.vociInfo('step-weapon').length === 0 && (N.INFO['step-weapon'] || []).length === 0 && (N.INFO['step-modifiers'] || []).length === 0 && (N.INFO['step-wait-aro'] || []).length === 0,
       'Ordine 2 (Alguacil, MOVIMENTO): step-weapon, step-modifiers e step-wait-aro sono vuoti, niente note dell Ordine di prima', [N.INFO['step-weapon'], N.INFO['step-modifiers']]);
});

sezione('R3. Il bottone dell arma su scala comune di 96" (tutte le armi con bande)', () => {
    const g = motoreSolo(false), M = g.MotoreN5;
    const nomi = Object.keys(g.RULES_WEAPONS || {}).filter(n => { const p = M.profiloArma(n); return p && !p.nonTrovata && p.bands && p.bands.length && p.bands.every(b => typeof b.a === 'number' && /^\d+-\d+"$/.test(b.label)); });
    const storte = [];
    nomi.forEach(n => {
        const p = M.profiloArma(n), h = M.bottoneArma(p, {});
        const cs = [...h.matchAll(/<div class="cella-gittata" data-da="(\d+)" data-fino="(\d+)" data-mod="(-?\d+)" style="flex:0 0 ([\d.]+)%/g)].map(x => ({ da: +x[1], fino: +x[2], mod: +x[3], w: +x[4] }));
        const fu = h.match(/<div class="cella-gittata cella-fuori" data-da="(\d+)" data-fino="(\d+)"/);
        const gr = M.gittateRaggruppate(p.bands);
        const fine = cs.length ? cs[cs.length - 1].fino : 0;
        const bene = cs.length === gr.length && cs.every((c, i) => c.fino === gr[i].fino && c.mod === gr[i].mod && c.da === (i ? cs[i - 1].fino : 0) && Math.abs(c.w - (c.fino - c.da) / 0.96) < 0.05)
            && (fine < 96 ? (!!fu && +fu[1] === fine && +fu[2] === 96) : !fu) && !/data-mod/.test((h.match(/cella-fuori[^>]*>/) || [''])[0]);
        if (!bene) storte.push({ n, cs, gr, fu: fu && fu.slice(1) });
    });
    ok(nomi.length > 100 && storte.length === 0, 'su ' + nomi.length + ' armi: celle contigue da 0 = M.gittateRaggruppate, larghezza (fino - da) / 96, FUORI fino a 96 senza data-mod', storte.slice(0, 3));
    // Le Sagome Dirette hanno una banda finta («Sagoma LargeTeardrop»): fuori dal giro.
    // CONTROPROVA: senza bande nessuna cella.
    ['Light Flamethrower', 'Monofilament CC Weapon'].forEach(n => ok(!/cella-gittata/.test(M.bottoneArma(M.profiloArma(n), {})), 'CONTROPROVA: ' + n + ', nessuna cella della gittata'));
});

sezione('R4. M.barraGittata: un segmento per banda, FUORI in coda, n+1 confini (tutte le armi)', () => {
    const g = motoreSolo(false), M = g.MotoreN5;
    const nomi = Object.keys(g.RULES_WEAPONS || {}).filter(n => { const p = M.profiloArma(n); return p && !p.nonTrovata && p.bands && p.bands.length && p.bands.every(b => typeof b.a === 'number' && /^\d+-\d+"$/.test(b.label)); });
    const storte = [];
    nomi.forEach(n => {
        const b = M.profiloArma(n).bands, k = b.length - 1;
        const h = M.barraGittata(b, { indice: k, tocco: (i) => `t(${i})`, fuori: 'F()', fuoriAttivo: false });
        // 31 ottobre (motore 30.1): il FUORI non ha piu` scritta, ha il title «Fuori gittata».
        const segs = [...h.matchAll(/<div class="range-seg (seg-[a-z0-9]+) ?(active)?"[^>]*onclick="([^"]*)"(?: title="([^"]*)")?>([^<]*)</g)].map(x => ({ c: x[1], a: !!x[2], on: x[3], ti: x[4] || '', t: x[5] }));
        const conf = [...h.matchAll(/<span class="confine-gittata"[^>]*>([^<]*)<\/span>/g)].map(x => x[1]);
        const bande = segs.slice(0, -1), f = segs[segs.length - 1] || {};
        const bene = bande.length === b.length && bande.every((s, i) => s.on === `t(${i})` && s.a === (i === k) && s.t === (b[i].mod > 0 ? '+' : '') + b[i].mod)
            && f.c === 'seg-fuori' && f.on === 'F()' && !f.a && f.t === '' && f.ti === 'Fuori gittata'
            && J(conf) === J(['0'].concat(b.map(x => String(x.a))));
        if (!bene) storte.push({ n, segs, conf });
    });
    ok(nomi.length > 100 && storte.length === 0, 'su ' + nomi.length + ' armi: un .range-seg per banda col suo tocco e il suo MOD, la banda scelta accesa, il FUORI in coda (vuoto, title «Fuori gittata»), confini 0 e la fine di ogni banda', storte.slice(0, 2));
    const b = M.profiloArma('Combi Rifle').bands;
    const conFuori = M.barraGittata(b, { indice: 0, tocco: (i) => `t(${i})`, fuori: 'F()', fuoriAttivo: true });
    ok(/class="range-seg seg-fuori active"/.test(conFuori) && !/class="range-seg seg-\d active"/.test(conFuori), 'fuoriAttivo: acceso FUORI («range-seg seg-fuori active»), nessuna banda');
    ok(!/seg-fuori/.test(M.barraGittata(b, { indice: 0, tocco: (i) => `t(${i})`, fuori: '' })), 'CONTROPROVA: senza il tocco di FUORI il segmento FUORI non c e`');
    ok(M.barraGittata([], {}) === '' && M.barraGittata(null, {}) === '', 'CONTROPROVA: senza bande, stringa vuota');
});

sezione('R5. M.nota e M.azzeraNote: senza app.html in window.INFO, con app.html a window.aggiungiInfo', () => {
    const g = motoreSolo(false), M = g.MotoreN5;
    M.nota('s', '<b>Tit</b>olo', 'riga<br>due', { tipo: 'boh', tasto: 7 });
    ok(J(g.INFO.s) === J([{ titolo: 'Titolo', testo: 'riga due', tipo: 'regole', tasto: '7' }]), 'senza pagina: la voce in window.INFO[idStep], HTML tolto, un tipo sconosciuto vale regole, tasto come testo', g.INFO.s);
    M.nota('s', 'Copertura', '-3', { tipo: 'mod' }); M.nota('s', '', ''); M.nota('', 'X', 'Y');
    ok(g.INFO.s.length === 2 && g.INFO.s[1].tipo === 'mod' && !('' in g.INFO), '  un tipo noto resta; titolo e testo vuoti, o senza idStep, non depositano niente', g.INFO.s.map(v => v.titolo));
    M.azzeraNote('s');
    ok(J(g.INFO.s) === '[]', '  M.azzeraNote svuota la schermata');
    const p = motoreSolo(true), Mp = p.MotoreN5;
    Mp.nota('step-x', 'A', 'b', { tipo: 'nonpuo', tasto: 'k' }); Mp.azzeraNote('step-x');
    ok(J(p._chiamate) === J([['aggiungi', 'step-x', 'A', 'b', { tipo: 'nonpuo', tasto: 'k' }], ['azzera', 'step-x']]) && !p.INFO, 'con la pagina: passa da window.aggiungiInfo e window.azzeraInfo, e window.INFO non nasce', p._chiamate);
});

sezione('R6. BS-31 del piano (rev 49): l Atteso sulla pagina intera', () => {
    const T = tavolo(T => [tr(P_(T, /^Clockmaker \(Engineer\)/), { id: 'n7', alias: 'Clock' }), tr(P_(T, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' })],
                     T => [FUS(T, 'p1')], 'NOMADI');
    const N = T.nomadi.g;
    T.apriMenu(T.nomadi, 0); N.selectAction('ATTACCO BS', false);
    const w = String(T.nomadi.el('weapon-buttons-container').innerHTML);
    ok(/<div class="intestazione-ordine"[^>]*>\s*<b[^>]*>ATTACCO BS<\/b>/.test(w), 'intestazione «ATTACCO BS», senza icona', (w.match(/intestazione-ordine[\s\S]{0,160}/) || [''])[0]);
    const combi = bottoni(w).find(b => /declareAttackBS\('Combi Rifle'/.test(b)) || '';
    const celle = [...combi.matchAll(/<div class="cella-gittata" data-da="(\d+)" data-fino="(\d+)" data-mod="(-?\d+)" style="flex:0 0 ([\d.]+)%/g)].map(x => [+x[1], +x[2], +x[3], Math.round(+x[4])]);
    ok(J(celle) === J([[0, 16, 3, 17], [16, 32, -3, 17], [32, 48, -6, 17]]) && /cella-fuori" data-da="48" data-fino="96"/.test(combi),
       'il bottone del Combi: 0-16 +3, 16-32 -3, 32-48 -6, un sesto della scala ciascuna, poi fuori fino a 96', celle);
    N.apriInfo();
    const pan = tx(T.nomadi.el('pannello-info').innerHTML);
    ok(/GIZMOKIT NON UTILIZZABILE si usa solo con la sua azione \(SUPPORTO\)/.test(pan) && /DEACTIVATOR NON UTILIZZABILE si usa solo con la sua azione \(DEACTIVATOR\)/.test(pan) && !bottoni(w).some(b => /GizmoKit|Deactivator/.test(b)),
       'GizmoKit e Deactivator non sono fra le armi: nella ⓘ, col motivo', pan.slice(0, 200));
    N.chiudiInfo();
    // ANNULLA ORDINE, e l Ordine nuovo lo dichiara l Alguacil.
    N.tornaAlRadar(); T.giro();
    T.apriMenu(T.nomadi, 1); N.selectAction('ATTACCO BS', false);
    ok(!N.vociInfo('step-weapon').some(v => /GizmoKit|Deactivator/.test(v.titolo)), 'Ordine nuovo con l Alguacil: nella ⓘ delle armi niente del GizmoKit', N.vociInfo('step-weapon').map(v => v.titolo));
    N.declareAttackBS('Combi Rifle'); N.toggleTargetSelection('p1'); N.confirmMultiAro(false); T.giro(); T.pano.g.annullaAro(); T.giro();
    N.goToModifiersBS('IDLE');
    const h = () => String(T.nomadi.el('targets-allocation-container').innerHTML);
    const segs = [...h().matchAll(/class="range-seg (seg-[a-z0-9]+)[^"]*"[^>]*>([^<]*)</g)].map(x => x[2]);
    const conf = [...h().matchAll(/<span class="confine-gittata"[^>]*>([^<]*)<\/span>/g)].map(x => x[1]);
    ok(J(segs) === J(['+3', '+3', '-3', '-3', '-6', '-6', '']) && /class="range-seg seg-fuori[^"]*"[^>]*title="Fuori gittata"><\/div>/.test(h()) && J(conf) === J(['0', '8', '16', '24', '32', '40', '48']),
       'la barra della scheda: sei caselle e il FUORI vuoto (title «Fuori gittata»), confini 0 8 16 24 32 40 48', { segs, conf });
    N.setTargetRangeBS(0, 2); N.eseguiCalcoloBS(); T.giro();
    ok(ris(T) && /Alg Azione: ATTACCO BS Successo al: 8 \(o meno\)/.test(tab(T)), 'terza casella (16-24"): sul tabellone 8 (11 -3)', (tab(T).match(/Alg Azione.{0,60}/) || [])[0]);
});

sezione('R7. BS-16 e BS-16b del piano (rev 49): Total Reaction sempre al pieno, la voce Burst nella ⓘ', () => {
    const giro = (attivaN, reaRe, faz, arma) => {
        const T = creaTavolo(DIR); const N = T.nomadi.g, P = T.pano.g;
        const alg = tr(T.profilo(T.nomadi, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' }), fus = FUS(T, 'p1', { alias: 'Fus' });
        const rea = tr(T.profilo(faz === 'P' ? T.pano : T.nomadi, reaRe), { id: faz === 'P' ? 'p9' : 'n47', alias: 'Rea' });
        if (faz === 'P') T.schiera([alg], [rea], 'NOMADI'); else T.schiera([rea], [fus], 'PANOCEANIA');
        const A = faz === 'P' ? T.nomadi : T.pano, R = faz === 'P' ? T.pano : T.nomadi, Ag = A.g, Rg = R.g;
        T.apriMenu(A, 0); Ag.selectAction('MOVIMENTO', false); T.giro();
        Rg.apriSelezioneAro(); Rg.toggleAroUnit(rea.id); Rg.confermaSelezioneAro(); Rg.selezionaAzioneAro('BS_ATTACK');
        const bt = bottoni(String(R.el('aro-weapon-list').innerHTML)).find(b => b.indexOf("selezionaArmaAro('" + arma) >= 0) || '';
        vm.runInContext(onclickDi(bt).replace(/&quot;/g, '"') || 'void 0', vm.createContext(Rg));
        Rg.selezionaBersaglioAro(faz === 'P' ? 'Alg' : 'Fus');
        const m = String(R.el('aro-modifiers-content').innerHTML);
        const burst = Rg.vociInfo('step-aro-modifiers').filter(v => v.titolo === 'Burst').map(v => v.testo);
        const cfg = JSON.parse(J(Rg.aroCurrentConfig));
        Rg.salvaAroCorrente(); T.giro(); Ag.selectAction('MOVIMENTO', true); T.giro();
        return { m, burst, cfg, t: tab(T), T };
    };
    const a = giro(true, /^Sierra Dronbot \(Heavy Machine Gun\)/, 'P', 'Heavy Machine Gun');
    ok(!/tasto-burst|sceltaBurstAro/.test(a.m) && a.cfg.burst === 4 && a.cfg.burstPieno === true && J(a.burst) === J(['In Turno Reattivo il Burst è 1 · Total Reaction: Burst pieno dell\'arma in ARO (B4)']),
       'BS-16, Sierra Dronbot (HMG): nessun tasto del Burst, B4, nella ⓘ «In Turno Reattivo il Burst è 1 · Total Reaction: Burst pieno dell arma in ARO (B4)»', [a.cfg.burst, a.burst]);
    ok(ris(a.T) && /Rea Azione: ATTACCO BS Successo al: \d+ \(o meno\) Dadi da lanciare: 4/.test(a.t), '  sul tabellone 4 dadi', (a.t.match(/Rea Azione.{0,70}/) || [])[0]);
    const b = giro(true, /^Reaktion Zond \(Thunderbolt\)$/, 'N', 'Thunderbolt');
    ok(!/tasto-burst|sceltaBurstAro/.test(b.m) && b.cfg.burst === 3 && b.burst.length === 1 && /^In Turno Reattivo il Burst è 1 · Total Reaction: Burst pieno dell'arma in ARO \(B2\) · Thunderbolt ?\(\+1B\): \+1 Burst anche in ARO \(Total Reaction, righe 10227-10228\)$/.test(b.burst[0]),
       'BS-16b, Reaktion Zond (Thunderbolt): B3, nella ⓘ le tre voci del Burst in una riga', [b.cfg.burst, b.burst]);
    ok(ris(b.T) && /Rea Azione: ATTACCO BS Successo al: \d+ \(o meno\) Dadi da lanciare: 3/.test(b.t), '  sul tabellone 3 dadi', (b.t.match(/Rea Azione.{0,70}/) || [])[0]);
    // CONTROPROVA: senza Total Reaction una voce sola non va nella ⓘ (serve piu` di una voce).
    const c = giro(true, /^Fusilier \(Combi/, 'P', 'Combi Rifle');
    ok(c.cfg.burst === 1 && c.burst.length === 0 && c.cfg.burstPieno === undefined, 'CONTROPROVA: un Fusilier senza Total Reaction, B1 e nessuna voce Burst nella ⓘ', [c.cfg.burst, c.burst]);
});

// ---------------------------------------------------------------------------
// S: D07 del collaudo grafico (MOTORE 2026-10-28.3, ordine_attacco_bs 28.2).
const CHAIN28 = /^Triphammer \(AP Spitfire, Chain-colt\)$/;
const lettere28 = (re, armaRe, n, opz) => {
    opz = opz || {};
    const ids = ['p1', 'p2', 'p3'].slice(0, n);
    const T = tavolo(T => { const u = tr(P_(T, re), { id: 'n1', alias: 'Tri' }); if (opz.arma) u.weapon = opz.arma; return [u]; },
                     T => ids.map((id, i) => FUS(T, id, Object.assign({ alias: 'F' + (i + 1) }, (i === 0 && opz.mischia) ? { states: { engaged: true } } : {}))), 'NOMADI');
    const N = T.nomadi.g, H = T.hub.g; T.apriMenu(T.nomadi, 0); N.selectAction('ATTACCO BS', false); N.startUnitAllocationLoopBS();
    const arg = (String(T.nomadi.el('weapon-buttons-container').innerHTML).match(new RegExp("declareAttackBS\\('(" + armaRe + "[^']*)'\\)")) || [])[1];
    if (opz.dichiara) opz.dichiara(N); else N.declareAttackBS(arg); ids.forEach(id => N.toggleTargetSelection(id)); N.confirmMultiAro(false); T.giro(); T.pano.g.annullaAro(); T.giro();
    N.goToModifiersBS('IDLE');
    const pag0 = String(T.nomadi.el('targets-allocation-container').innerHTML);
    const partenza = J(N.currentOrder.sagomeConAlleato);
    if (opz.prep) opz.prep(N, T);
    const pag = String(T.nomadi.el('targets-allocation-container').innerHTML);
    const campi = N.combatTargets.map(t => ({ n: t.name, sagome: t.sagome, con: t.sagomeConAlleato, all: t.alleatoNellaSagoma }));
    N.alert_.length = 0; N.eseguiCalcoloBS(); T.giro();
    const sc = H.ultimiScontri || [];
    return { T, N, arg, pag0, pag, partenza, campi, sc, per: (nome) => sc.find(s => s.reattivo && s.reattivo.nome === nome) || {},
             tasti: (h) => [...String(h).matchAll(/class="burst-btn tasto-sagoma-alleato" style="([^"]*)"[^>]*onclick="(window\.toggleSagomaAlleatoBS\('([A-Z])'\))"/g)].map(x => ({ L: x[3], on: /var\(--mn-attenzione,/.test(x[1]), clic: x[2] })) };
};
const salvezze = (s) => { const m = J(s).match(/Restano ([A-Z, ]+): (\d+) Tiro/); return m ? m[1] + ':' + m[2] : null; };

sezione('S1. D07: la domanda «un tuo alleato sotto la Sagoma» per lettera, una sola, in cima', () => {
    // Tre Fusilier, Chain-colt (+1B): F1 sotto A, F2 sotto A e B, F3 sotto A.
    const prepAB = (N) => N.toggleSagomaBS(1, 'A');
    // (a) Partenza: F1 Ingaggiato -> accesa la sua lettera, A.
    const a = lettere28(CHAIN28, 'Chain-colt', 3, { mischia: true, prep: prepAB });
    const tA = a.tasti(a.pag);
    ok((a.pag.match(/class="domanda-sagome-alleato"/g) || []).length === 1 && J(tA.map(x => x.L + (x.on ? '+' : '-'))) === '["A+","B-"]' && a.partenza === '["A"]',
       'una domanda sola, in cima, un tasto per lettera; partenza: accesa la A del bersaglio Ingaggiato (F1)', { tasti: tA, partenza: a.partenza });
    ok(!/prende anche un/.test((a.pag.match(/<div class="target-card[\s\S]*$/) || [''])[0]), '  e nessuna domanda sulle schede dei bersagli');
    ok(J(a.campi.map(c => [c.n, c.con, c.all])) === J([['F1', ['A'], true], ['F2', ['A'], false], ['F3', ['A'], false]]),
       'sui bersagli: sagomeConAlleato = le loro lettere accese; alleatoNellaSagoma solo su F1 (Ingaggiato, tutte le sue lettere accese)', a.campi);
    ok(a.per('F1').tipo === 'NESSUNO' && a.per('F3').tipo === 'NESSUNO' && a.per('F2').tipo === 'NORMALE' && salvezze(a.per('F2')) === 'B:1',
       'alleato sotto la A: F1 e F3 annullati, F2 (A+B) colpito dalla B, 1 Tiro Salvezza', [a.per('F1').tipo, a.per('F2').tipo, a.per('F3').tipo, salvezze(a.per('F2'))]);
    // (b) Lo stesso col tocco vero, senza mischia: tocca A.
    const b = lettere28(CHAIN28, 'Chain-colt', 3, { prep: (N, T) => { prepAB(N); const t = (String(T.nomadi.el('targets-allocation-container').innerHTML).match(/onclick="(window\.toggleSagomaAlleatoBS\('A'\))"/) || [])[1]; vm.runInContext(t || 'void 0', N); } });
    ok(b.partenza === '[]' && J(b.tasti(b.pag).map(x => x.L + (x.on ? '+' : '-'))) === '["A+","B-"]' && b.per('F1').tipo === 'NESSUNO' && b.per('F3').tipo === 'NESSUNO' && b.per('F2').tipo === 'NORMALE' && salvezze(b.per('F2')) === 'B:1',
       'senza mischia la partenza e` spenta; toccata la A: F1 e F3 annullati, F2 colpito dalla B (1 TS)', [b.partenza, b.sc.map(x => x.tipo), salvezze(b.per('F2'))]);
    ok(b.campi.every(c => c.all === false), '  e nessun alleatoNellaSagoma: nessun bersaglio e` Ingaggiato', b.campi.map(c => c.all));
    // (c) A e B accese: tutti annullati, F2 compreso.
    const c = lettere28(CHAIN28, 'Chain-colt', 3, { prep: (N) => { prepAB(N); N.toggleSagomaAlleatoBS('A'); N.toggleSagomaAlleatoBS('B'); } });
    ok(c.sc.length === 3 && c.sc.every(x => x.tipo === 'NESSUNO') && J(c.campi[1].con) === '["A","B"]', 'A e B accese: tutti e tre annullati, F2 compreso', c.sc.map(x => x.tipo));
    // CONTROPROVA: nessuna lettera accesa, nessuno annullato.
    const d = lettere28(CHAIN28, 'Chain-colt', 3, { prep: prepAB });
    ok(d.partenza === '[]' && d.sc.length === 3 && d.sc.every(x => x.tipo === 'NORMALE') && salvezze(d.per('F2')) === null, 'CONTROPROVA: nessuna lettera accesa, nessuno annullato (F2: due Sagome, nessuna nota «Restano»)', d.sc.map(x => x.tipo));
    // Ritoccata, la lettera si spegne.
    const e = lettere28(CHAIN28, 'Chain-colt', 3, { prep: (N) => { prepAB(N); N.toggleSagomaAlleatoBS('A'); N.toggleSagomaAlleatoBS('A'); } });
    ok(e.sc.every(x => x.tipo === 'NORMALE') && J(e.N.currentOrder.sagomeConAlleato || []) === '[]', '  e ritoccata la A si spegne: di nuovo nessuno annullato', e.sc.map(x => x.tipo));
});

sezione('S2. D07: Fumo ed Eclipse a lettere, nessuna domanda e mai annullati', () => {
    // Nessun profilo ha una fumogena (+1B): la si aggiunge al Morlock (come il
    // Panzerfaust di O2). Con due Sagome le lettere ci sono, la domanda no.
    ['Smoke Grenades(+1B)', 'Eclipse Grenades(+1B)'].forEach(arma => {
        const nome = arma.replace('(+1B)', '');
        const a = lettere28(/^Morlock \(Assault/, nome.replace(/[()+]/g, '\\$&'), 2, { mischia: true, arma: 'Chain Rifle, ' + arma });
        const lett = a.N.lettereSagomaBS ? a.N.lettereSagomaBS() : [];
        ok(a.arg && lett.length === 2 && !/domanda-sagome-alleato/.test(a.pag) && !/tasto-sagoma-alleato/.test(a.pag),
           nome + ' (+1B): due Sagome a lettere (' + lett.join(', ') + '), nessuna domanda sugli alleati', { arg: a.arg, lett });
        ok(a.sc.length > 0 && a.sc.every(x => x.tipo !== 'NESSUNO') && a.campi.every(c => !c.all && !(c.con || []).length),
           '  e con F1 in mischia nessuno e` annullato, nessun campo sagomeConAlleato', [a.sc.map(x => x.tipo), a.campi]);
    });
});

sezione('S3. D07: Ordine Coordinato, la risposta si azzera per il partecipante successivo', () => {
    const T = tavolo(T => [tr(P_(T, CHAIN28), { id: 'n1', alias: 'Tri1' }), tr(P_(T, CHAIN28), { id: 'n2', alias: 'Tri2' })],
                     T => ['p1', 'p2', 'p3'].map((id, i) => FUS(T, id, { alias: 'F' + (i + 1) })), 'NOMADI');
    const N = T.nomadi.g;
    N.currentGroup = 1; N.isCoordinated = true; N.selectedCoordinatedUnits = []; N.spearheadUnit = null;
    N.selezionaUnita(0); N.selezionaUnita(1); N.confermaCoordinato(); N.selectAction('ATTACCO BS', false);
    const scegli = () => { N.startUnitAllocationLoopBS(); const arg = (String(T.nomadi.el('weapon-buttons-container').innerHTML).match(/declareAttackBS\('(Chain-colt[^']*)'\)/) || [])[1]; N.declareAttackBS(arg); ['p1', 'p2', 'p3'].forEach(id => N.toggleTargetSelection(id)); return arg; };
    const arg1 = scegli(); N.confirmMultiAro(false); T.giro(); T.pano.g.annullaAro(); T.giro(); N.goToModifiersBS('IDLE');
    // Nel Coordinato la Punta di Lancia ha META` Burst (B2 -> B1) e il gregario
    // B1: con la Chain-colt le lettere non nascono. La risposta si prova
    // direttamente: quella data per il primo non deve arrivare al secondo.
    const lett1 = N.lettereSagomaBS();
    ok(!!arg1 && lett1.length <= 1 && !/tasto-sagoma-alleato/.test(String(T.nomadi.el('targets-allocation-container').innerHTML)),
       'premessa: Punta di Lancia a meta` Burst, una Sagoma sola, nessuna domanda per lettera (' + J(lett1) + ')');
    N.currentOrder.sagomeConAlleato = ['A'];
    const i0 = N.coordIndex; N.eseguiCalcoloBS();
    ok(N.coordIndex === i0 + 1 && N.currentOrder.sagomeConAlleato === undefined, 'passato al secondo partecipante: la risposta del primo (["A"]) e` azzerata', [N.coordIndex, N.currentOrder.sagomeConAlleato]);
    scegli(); N.confirmMultiAro(false); T.giro();
    ok(J(N.currentOrder.sagomeConAlleato || []) === '[]' && N.combatTargets.every(t => !(t.sagomeConAlleato || []).length && !t.alleatoNellaSagoma),
       'il secondo partecipante non eredita niente: nessuna lettera accesa sui suoi bersagli', N.combatTargets.map(t => t.sagomeConAlleato));
});

sezione('S4. D07: la barra nel bottone dell arma coi colori di .seg-1..4, il MOD 0 azzurro', () => {
    const g = motoreSolo(false), M = g.MotoreN5;
    const css = fs.readFileSync(DIR + 'app.html', 'utf8');
    const coloreSeg = (k) => ((css.match(new RegExp('\\.' + k + ' \\{ background: (#[0-9A-Fa-f]{6})')) || [])[1] || '').toUpperCase();
    ok(coloreSeg('seg-2') === '#03A9F4', 'premessa: in app.html .seg-2 (MOD 0) e` #03A9F4');
    const nomi = Object.keys(g.RULES_WEAPONS || {}).filter(n => { const p = M.profiloArma(n); return p && !p.nonTrovata && p.bands && p.bands.length && p.bands.every(b => typeof b.a === 'number'); });
    const storte = [];
    nomi.forEach(n => {
        const h = M.bottoneArma(M.profiloArma(n), {});
        [...h.matchAll(/<div class="cella-gittata" data-da="\d+" data-fino="\d+" data-mod="(-?\d+)" style="[^"]*background:(#[0-9A-Fa-f]{6}); color:(#[0-9A-Fa-f]{3,6});/g)].forEach(x => {
            if (x[2].toUpperCase() !== coloreSeg(M.classeBanda(+x[1])) || x[3] !== '#000') storte.push({ n, mod: x[1], bg: x[2], col: x[3] });
        });
    });
    ok(nomi.length > 100 && storte.length === 0, 'su ' + nomi.length + ' armi ogni cella ha il colore della .seg della sua banda (M.classeBanda) e il numero nero', storte.slice(0, 3));
    const hmg = M.bottoneArma(M.profiloArma('Heavy Machine Gun'), {});
    const zero = (hmg.match(/data-mod="0" style="[^"]*background:(#[0-9A-Fa-f]{6})/) || [])[1];
    ok(zero === '#03A9F4', 'Heavy Machine Gun: la fascia a MOD 0 e` azzurra #03A9F4 (scelta di Paolo)', zero);
    // CONTROPROVA: la barra della scheda (M.barraGittata) usa le stesse classi.
    ok(/class="range-seg seg-2 /.test(M.barraGittata(M.profiloArma('Heavy Machine Gun').bands, { indice: 9, tocco: (i) => 't' + i })), 'CONTROPROVA: nella barra della scheda la banda a MOD 0 e` .seg-2, lo stesso azzurro');
});

sezione('S5. M.rigaAttesaAro: la riga dell attesa dell ARO (MOTORE 2026-10-28.3)', () => {
    const g = motoreSolo(false), M = g.MotoreN5;
    ok(M.rigaAttesaAro([], { weapon: 'Combi Rifle' }) === '' && M.rigaAttesaAro(null, {}) === '', 'senza bersagli: stringa vuota (Movimento e simili)');
    const uno = M.rigaAttesaAro([{ id: 'p1', alias: 'Fus <1>' }], { weapon: 'Combi Rifle' });
    ok(/^<div class="riga-attesa-aro"/.test(uno) && /Bersaglio: <b[^>]*>Fus &lt;1&gt;<\/b>/.test(uno) && /· Combi Rifle/.test(uno), 'un bersaglio: «Bersaglio: <nome>» (scappato) e l arma', uno);
    const due = M.rigaAttesaAro([{ id: 'p1', alias: 'F1' }, { id: 'p2', name: 'F2' }], { weapon: 'Kobra Pistol (BS Mode)' });
    ok(/Bersagli: <b[^>]*>F1, F2<\/b>/.test(due) && /· Kobra Pistol</.test(due) && !/BS Mode/.test(due), 'due bersagli: «Bersagli: F1, F2», l arma senza «(BS Mode)»', due);
    const pt = M.rigaAttesaAro([M.bersaglioPunto()], { weapon: 'Smoke Grenades' });
    ok(/Bersaglio: <b[^>]*>un punto del tavolo<\/b> \(nessuna truppa\)/.test(pt) && !/PUNTO SUL TAVOLO/.test(pt), 'il punto del tavolo: «un punto del tavolo (nessuna truppa)»', pt);
    ok(!/· /.test(M.rigaAttesaAro([{ id: 'p1', alias: 'F1' }], {})), 'CONTROPROVA: senza arma nell Ordine, niente «· arma»');
});

sezione('S6. SG-09 del piano (rev 50): due Sagome di Light Flamethrower(+1B), la domanda per lettera', () => {
    const GR = /^Grenzer \(Forward Observer, Sensor, NCO\)/;
    // F1 Ingaggiato, F2 no: partenza A (la lettera di F1) gia` accesa.
    const a = lettere28(GR, 'Light Flamethrower', 2, { mischia: true });
    ok(a.arg === 'Light Flamethrower(+1B)' && /2 SAGOME/.test(tx(a.pag0)) && /Sagoma A<\/b>: F1/.test(a.pag0) && /Sagoma B<\/b>: F2/.test(a.pag0) && a.partenza === '["A"]',
       'in testa «2 SAGOME», A su F1, B su F2; la domanda per lettera parte con la A accesa (F1 Ingaggiato)', { arg: a.arg, partenza: a.partenza });
    ok(a.per('F1').tipo === 'NESSUNO' && a.per('F2').tipo !== 'NESSUNO' && /Sagome B: 1 Tiro\/i Salvezza/.test(J(a.per('F2'))), 'F1 annullato; F2 colpito da B, un Tiro Salvezza «Sagome B: 1 Tiro/i Salvezza.»', [a.per('F1').tipo, a.per('F2').tipo]);
    const b = lettere28(GR, 'Light Flamethrower', 2, { mischia: true, prep: (N) => N.toggleSagomaBS(1, 'A') });
    ok(/Sagome A \(annullata: prende F1 con un tuo alleato\)\. Restano B: 1 Tiro\/i Salvezza/.test(J(b.per('F2'))), 'accesa anche la A su F2: «Sagome A (annullata: prende F1 con un tuo alleato). Restano B: 1 Tiro/i Salvezza.»', (J(b.per('F2')).match(/Sagome A[^"]{0,80}/) || [])[0]);
    const c = lettere28(GR, 'Light Flamethrower', 2, { prep: (N) => N.toggleSagomaBS(1, 'A') });
    ok(c.partenza === '[]' && c.sc.every(x => x.tipo !== 'NESSUNO') && /Sotto le Sagome A, B: 2 Tiro\/i Salvezza/.test(J(c.per('F2'))), 'F1 non Ingaggiato, F2 sotto A e B: partenza spenta, tutti e due colpiti, F2 con due Tiri Salvezza', [c.partenza, c.sc.map(x => x.tipo)]);
    const d = lettere28(GR, 'Light Flamethrower', 2, { prep: (N) => N.toggleSagomaBS(1, 'B') });
    ok(!ris(d.T) && d.N.alert_.some(m => /F2: nessuna Sagoma accesa/.test(m)), 'un bersaglio senza lettere blocca l invio: «F2: nessuna Sagoma accesa»', d.N.alert_.map(m => m.slice(0, 50)));
});

sezione('T1. Snellimento: nei moduli i caratteri dalla scala --fs-* di app.html', () => {
    const fs_ = require('fs');
    const MODULI = fs_.readdirSync('.').filter(f => /^ordine_.*\.js$/.test(f)).concat(['logica_stati.js']).sort();
    const PX = /font-size:\s*\d+px/g, VAR = /font-size:\s*var\(--fs-([a-z0-9-]+)\)/g;
    // L autocontrollo dei due cercatori: senza, una prova vuota passa sempre.
    ok(('a{font-size:13px} b{font-size: 50px}'.match(PX) || []).length === 2 && [...'x{font-size:var(--fs-s)}'.matchAll(VAR)].map(m => m[1])[0] === 's', 'CONTROPROVA dei cercatori: «font-size:13px» e «font-size: 50px» trovati, var(--fs-s) letta');
    const conPx = MODULI.map(f => [f, (fs_.readFileSync(f, 'utf8').match(PX) || []).length]).filter(x => x[1]);
    // 🔴 GIRATA IL 31 OTTOBRE (ordine_attacco_bs 2026-10-31.1). Era DIFETTO APERTO (giro 26):
    // ordine_attacco_bs 30.1 rimetteva tre font-size in px, 22px (Copertura, Linea di Tiro) e
    // 26px (tendina delle munizioni). Ora var(--fs-l) e var(--fs-titolo-2) (28px, su :root).
    ok(MODULI.length === 18 && conPx.length === 0, 'GIRATA: nei 17 ordine_*.js e in logica_stati nessun «font-size:Npx»', conPx);
    const usate = {}; MODULI.forEach(f => [...fs_.readFileSync(f, 'utf8').matchAll(VAR)].forEach(m => { usate[m[1]] = (usate[m[1]] || 0) + 1; }));
    const tot = Object.values(usate).reduce((a, b) => a + b, 0);
    ok(tot >= 250 && Object.keys(usate).every(k => ['xs', 's', 'm', 'l', 'xl', 'xxl', 'titolo-2'].includes(k)), 'tutte le misure usate sono della scala (xs, s, m, l, xl, xxl, titolo-2): ' + tot + ' punti', usate);
    ok(usate['titolo-2'] === 1, 'var(--fs-titolo-2) una volta sola nei moduli (la tendina delle munizioni di ordine_attacco_bs)', usate['titolo-2']);
    const app = fs_.readFileSync('app.html', 'utf8');
    const root = (app.match(/:root\s*\{[^}]*--fs-xs[^}]*\}/) || [''])[0];
    const val = {}; [...root.matchAll(/--fs-([a-z0-9-]+):\s*(\d+)px/g)].forEach(m => { val[m[1]] = +m[2]; });
    ok(J([val.xs, val.s, val.m, val.l, val.xl, val.xxl, val['titolo-2']]) === '[12,14,16,22,32,42,28]', 'app.html: --fs-xs..xxl e --fs-titolo-2 su :root, 12 14 16 22 32 42 28', val);
    ok(Object.keys(usate).every(k => val[k] > 0), 'ogni variabile usata dai moduli e` definita su :root (senza, il browser eredita la misura)', Object.keys(usate).filter(k => !val[k]));
    // I px del motore restano (S4): la cella del bottone dell arma ha ancora i suoi.
    const M_ = require('./motore_regole_n5.js');
    ok(typeof M_.barraArma === 'function' && /font-size:\s*\d+px/.test(fs_.readFileSync('motore_regole_n5.js', 'utf8')), '  e i px del motore (barraArma, bottoneArma, barraGittata...) non sono toccati');
});

sezione('T2. Snellimento: verde «SÌ» e giallo «attenzione» da M.stileColore', () => {
    const fs_ = require('fs');
    const M_ = require('./motore_regole_n5.js');
    const SI = 'background:#004400; border-color:#00ff00; color:#00ff00;', ATT = 'background:#554400; border-color:#ffcc00; color:#ffcc00;';
    ok(M_.stileColore('si') === SI && M_.stileColore('attenzione') === ATT, 'M.stileColore: le due stringhe di prima, byte per byte', [M_.stileColore('si'), M_.stileColore('attenzione')]);
    ok(M_.stileColore('si') !== M_.stileColore('attenzione') && M_.stileColore('nessuno') === M_.stileColore('spento'), 'CONTROPROVA: le due sono diverse; un nome che non c e` da` lo «spento»');
    const SETTE = ['ordine_attacco_bs.js', 'ordine_attacco_intuitivo.js', 'ordine_movimento.js', 'ordine_osservazione.js', 'ordine_piazzamento.js', 'ordine_scenografia.js', 'ordine_supporto.js'];
    const conti = SETTE.map(f => { const t = fs_.readFileSync(f, 'utf8'); return [f, (t.match(/stileColore\(/g) || []).length, (t.split(SI).length - 1) + (t.split(ATT).length - 1)]; });
    ok(conti.reduce((a, c) => a + c[1], 0) === 11 && conti.every(c => c[1] > 0 && c[2] === 0), 'gli 11 punti (BS 2, Intuitivo 1, Movimento 1, Osservazione 2, Piazzamento 2, Scenografia 1, Supporto 2) usano M.stileColore, nessuno scritto a mano', conti);
    // Sulla pagina: il tasto della Sagoma Diretta (Light Flamethrower) verde, poi giallo col FUORI.
    const GR = /^Grenzer \(Forward Observer, Sensor, NCO\)/;
    const a = lettere28(GR, 'Light Flamethrower', 1);
    const b = lettere28(GR, 'Light Flamethrower', 1, { prep: (N) => N.toggleFuoriGittataBS(0) });
    const tasto = (h) => (String(h).match(/<button class="huge-btn" style="([^"]*)" onclick="window\.toggleFuoriGittataBS\(0\)"/) || [])[1] || '';
    ok(tasto(a.pag).includes(SI) && tasto(b.pag).includes(ATT) && !tasto(b.pag).includes(SI), 'sulla pagina: il tasto della Sagoma Diretta verde «SÌ», col FUORI giallo «attenzione»', [tasto(a.pag).slice(-70), tasto(b.pag).slice(-70)]);
});

// Un motore da solo in un contesto con un documento minimo (head, :root con
// setProperty): le pagine di creaTavolo non hanno head, li` la tavolozza non si scrive.
const motoreTav = (conHead) => {
    const nodi = {}, prop = {}, err = [];
    const head = { figli: [], appendChild(n) { this.figli.push(n); if (n.id) nodi[n.id] = n; } };
    const doc = { createElement: (t) => ({ tag: t, id: '', textContent: '' }), getElementById: (id) => nodi[id] || null,
                  documentElement: { style: { setProperty: (k, v) => { prop[k] = v; } } } };
    if (conHead) doc.head = head;
    const g = { console: { log() {}, warn() {}, error: (...a) => err.push(a.join(' ')) }, document: doc };
    g.window = g; g.globalThis = g;
    const c = vm.createContext(g); ['catalogo_n5.js', 'database_comune.js', 'motore_regole_n5.js'].forEach(f => vm.runInContext(fs.readFileSync(DIR + f, 'utf8'), c, { filename: f }));
    // l id lo assegna il motore dopo createElement: lo rileggo dalla head
    head.figli.forEach(n => { if (n.id) nodi[n.id] = n; });
    return { g, M: g.MotoreN5, head, nodi, prop, err };
};
const NOMI_TAV = ['testo', 'testo-2', 'debole', 'spento', 'scuro', 'nota-testo', 'nota-tenue', 'nota-fondo', 'nota-bordo', 'attenzione', 'attenzione-fondo', 'acceso',
                  'errore', 'errore-testo', 'errore-fondo', 'errore-bordo', 'si', 'si-testo', 'si-fondo', 'si-bordo', 'fondo-tasto', 'fondo-riquadro', 'bordo-spento'];

sezione('U1. Colori raggruppati: M.TAVOLOZZA (23 nomi) e M.colore', () => {
    const { M, err } = motoreTav(true);
    ok(J(Object.keys(M.TAVOLOZZA)) === J(NOMI_TAV), 'M.TAVOLOZZA: i 23 nomi della consegna, in quest ordine', Object.keys(M.TAVOLOZZA));
    ok(Object.values(M.TAVOLOZZA).every(v => /^#[0-9a-f]{6}$/.test(v)), '  ogni valore e` un #rrggbb', M.TAVOLOZZA);
    ok(NOMI_TAV.every(k => M.colore(k) === 'var(--mn-' + k + ',' + M.TAVOLOZZA[k] + ')') && M.colore('acceso') === 'var(--mn-acceso,#ffaa33)',
       'M.colore(nome) = «var(--mn-<nome>,<colore>)» per tutti i 23 (acceso: var(--mn-acceso,#ffaa33))', M.colore('acceso'));
    ok(M.colore('verdino') === '#ff00ff' && err.some(e => /M\.colore: "verdino" non e` nella tavolozza/.test(e)), 'CONTROPROVA: un nome che non c e` da` #ff00ff e un errore in console', err);
    ok(M.stileColore('si') === 'background:#004400; border-color:#00ff00; color:#00ff00;', '  e M.stileColore non cambia (T2 resta valida)');
});

sezione('U2. M.applicaTavolozza: <style id="tavolozza-motore"> su :root, e i moduli che la usano', () => {
    const fs_ = fs;
    const a = motoreTav(true);
    const st = a.nodi['tavolozza-motore'];
    const vars = st ? [...String(st.textContent).matchAll(/--mn-([a-z0-9-]+):(#[0-9a-f]{6});/g)].map(m => [m[1], m[2]]) : [];
    ok(!!st && st.tag === 'style' && a.head.figli.length === 1 && /^:root\{/.test(st.textContent), 'al caricamento del motore: un <style id="tavolozza-motore"> nella head, «:root{...}»', st && st.textContent.slice(0, 60));
    ok(J(vars) === J(NOMI_TAV.map(k => [k, a.M.TAVOLOZZA[k]])), '  con le 23 variabili --mn-* ai valori della tavolozza');
    a.M.TAVOLOZZA.acceso = '#123456'; const r2 = a.M.applicaTavolozza();
    ok(r2 === true && a.head.figli.length === 1 && /--mn-acceso:#123456;/.test(st.textContent), 'richiamata dopo un cambio: lo stesso <style>, riscritto (nessun doppione)', a.head.figli.length);
    const b = motoreTav(false);
    ok(b.M.applicaTavolozza() === false && !b.nodi['tavolozza-motore'], 'CONTROPROVA: senza head (i banchi) non scrive niente e risponde false');
    // I moduli: ogni var(--mn-<nome>,<colore>) ha un nome della tavolozza (o --mn-ordine-*) e il ripiego uguale al valore.
    const MODULI = fs_.readdirSync(DIR).filter(f => /^ordine_.*\.js$/.test(f)).concat(['logica_stati.js']);
    let n = 0, no = 0; const male = [];
    MODULI.forEach(f => [...fs_.readFileSync(DIR + f, 'utf8').matchAll(/var\(--mn-([a-z0-9-]+),\s*([^)]+)\)/g)].forEach(m => {
        if (/^ordine-(bordo|sfondo|riquadro|tenue|testo)$/.test(m[1])) { no++; return; }
        n++; if (b.M.TAVOLOZZA[m[1]] === undefined || m[2].toLowerCase() !== b.M.TAVOLOZZA[m[1]]) male.push(f + ': ' + m[0]);  // b: tavolozza intatta (a e` stata cambiata sopra)
    }));
    ok(n === 454 && no === 49 && male.length === 0, 'nei moduli e in logica_stati 454 var(--mn-<nome>,<colore>), tutti della tavolozza col ripiego uguale al suo valore', { n, male: male.slice(0, 5) });
    ok(no > 0, '  e ' + no + ' var(--mn-ordine-*) per le sfumature dell Ordine');
    ok(!/--mn-[a-z]/.test(fs_.readFileSync(DIR + 'app.html', 'utf8').replace(/var\(--mn-[^)]*\)/g, '')), 'app.html non definisce variabili --mn-* (il nome e` del motore)');
});

sezione('U3. M.COLORI_ORDINE, M.CATEGORIE_ORDINE, M.coloreOrdine', () => {
    const { M } = motoreTav(true);
    const CAT = { movimento: ['#00ffff', '#002244'], breve: ['#00ff00', '#003300'], intero: ['#ff0000', '#440000'] };
    ok(J(Object.keys(M.CATEGORIE_ORDINE)) === J(Object.keys(CAT)) && Object.keys(CAT).every(c => M.CATEGORIE_ORDINE[c].bordo === CAT[c][0] && M.CATEGORIE_ORDINE[c].sfondo === CAT[c][1]
        && ['bordo', 'sfondo', 'riquadro', 'tenue', 'testo'].every(k => /^#[0-9a-f]{6}$/.test(M.CATEGORIE_ORDINE[c][k]))),
       'tre categorie, cinque tinte ciascuna: movimento blu #00ffff/#002244, breve verde #00ff00/#003300, intero rosso #ff0000/#440000', M.CATEGORIE_ORDINE);
    const voci = Object.values(M.AZIONI).concat(['BS_ATTACK', 'DODGE']);
    const senza = voci.filter(v => !M.COLORI_ORDINE[v]);
    ok(senza.length === 0 && Object.values(M.COLORI_ORDINE).every(v => CAT[v.categoria]), 'una voce in M.COLORI_ORDINE per ogni valore di M.AZIONI (' + Object.values(M.AZIONI).length + ') piu` BS_ATTACK e DODGE, ognuna con una categoria vera', senza);
    const cat = (a, casa) => M.coloreOrdine(a, casa).categoria;
    ok(J(['MOVIMENTO', 'ATTACCO BS', 'ATTACCO CC', 'SCOPRIRE', 'HACKING', 'SCHIVATA', 'FUOCO SPECULATIVO', 'ATTACCO GUIDATO', 'ATTACCO INTUITIVO', 'SOPPRESSIONE', 'CAUTO', 'TRINCERARSI'].map(a => cat(a)))
       === J(['movimento', 'breve', 'breve', 'breve', 'breve', 'breve', 'intero', 'intero', 'intero', 'intero', 'intero', 'intero']), 'le categorie del menu: Movimento blu, Abilita` Brevi verdi, Ordini Interi rossi');
    const bs = M.coloreOrdine('ATTACCO BS');
    ok(J(bs) === J(Object.assign({}, (({ bordo, sfondo, riquadro, tenue, testo }) => ({ bordo, sfondo, riquadro, tenue, testo }))(M.CATEGORIE_ORDINE.breve), { categoria: 'breve' })), 'M.coloreOrdine(«ATTACCO BS»): le cinque tinte della breve e la categoria', bs);
    ok(cat(' fuoco speculativo ') === 'intero' && cat('NON ESISTE', 'SOPPRESSIONE') === 'intero' && cat('NON ESISTE') === 'breve' && cat(undefined, 'MOVIMENTO') === 'movimento',
       'maiuscole e spazi non contano; azione sconosciuta: le tinte dell Ordine di casa; senza casa: breve');
    const prima = M.COLORI_ORDINE.HACKING; M.COLORI_ORDINE.HACKING = { categoria: 'breve', bordo: '#123456' };
    const h = M.coloreOrdine('HACKING'); M.COLORI_ORDINE.HACKING = prima;
    ok(h.bordo === '#123456' && h.sfondo === '#003300', 'un Ordine si ricolora dalla sua voce: bordo #123456, il resto dalla categoria', h);
});

sezione('U4. M.colOrdine: il COL dei moduli legge currentOrder.action a ogni uso', () => {
    const { g, M, prop } = motoreTav(true);
    g.currentOrder = { action: 'MOVIMENTO' };
    const col = M.colOrdine('ATTACCO BS');
    const b1 = col.bordo;
    ok(b1 === '#00ffff' && prop['--mn-ordine-bordo'] === '#00ffff' && prop['--mn-ordine-riquadro'] === M.CATEGORIE_ORDINE.movimento.riquadro, 'azione MOVIMENTO: bordo #00ffff, e --mn-ordine-* scritte su :root', prop);
    g.currentOrder.action = 'FUOCO SPECULATIVO';
    ok(col.bordo === '#ff0000' && col.sfondo === '#440000' && prop['--mn-ordine-bordo'] === '#ff0000', 'lo stesso COL, cambiata l azione in FUOCO SPECULATIVO: ora rosso (getter)', [col.bordo, col.sfondo]);
    g.currentOrder = {};
    ok(col.bordo === '#00ff00', 'senza azione: le tinte dell Ordine di casa (ATTACCO BS, verde)', col.bordo);
    ok(J(Object.keys(col)) === J(['bordo', 'sfondo', 'riquadro', 'tenue', 'testo']), '  con le cinque tinte enumerabili', Object.keys(col));
});

sezione('U5. Sulla pagina: le intestazioni nel colore della categoria, la Soppressione rossa', () => {
    const T = tavolo(T => [tr(P_(T, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' }), tr(P_(T, /^Intruder \(HMG\)/), { id: 'n2', alias: 'Intr' }),
                           tr(P_(T, /^Intruder \(Hacker, Killer Hacking Device\)/), { id: 'n3', alias: 'Hk' })],
                     T => [FUS(T, 'p1')], 'NOMADI');
    const N = T.nomadi.g;
    const intest = () => { const h = Object.keys(T.nomadi.elementi).map(k => String(T.nomadi.elementi[k].innerHTML || '')).join(' ');
        const m = h.match(/<div class="intestazione-ordine" style="([^"]*)"/); return m ? m[1] : ''; };
    const visti = {};
    [[0, 'ATTACCO BS'], [0, 'SCOPRIRE'], [0, 'ATTACCO CC'], [2, 'FUOCO SPECULATIVO'], [1, 'SOPPRESSIONE']].forEach(([i, az]) => {
        Object.keys(T.nomadi.elementi).forEach(k => { T.nomadi.elementi[k].innerHTML = ''; });
        T.apriMenu(T.nomadi, i); N.selectAction(az, false);
        const st = intest(); visti[az] = ((st.match(/border:1px solid (#[0-9a-f]{6})/) || [])[1] || '?') + ' ' + ((st.match(/background:(#[0-9a-f]{6})/) || [])[1] || '?');
        N.tornaAlRadar(); T.giro();
    });
    ok(J(visti) === J({ 'ATTACCO BS': '#00ff00 #003300', 'SCOPRIRE': '#00ff00 #003300', 'ATTACCO CC': '#00ff00 #003300', 'FUOCO SPECULATIVO': '#ff0000 #440000', 'SOPPRESSIONE': '#ff0000 #440000' }),
       'intestazioni: Attacco BS, Scoprire, Attacco CC verdi; Fuoco Speculativo e Fuoco di Soppressione (dentro ordine_difesa) rossi', visti);
    ok(!Object.values(visti).some(v => /\?/.test(v)) && new Set(Object.values(visti)).size === 2, 'CONTROPROVA: ogni Ordine ha la sua intestazione, e i colori sono due (verde e rosso), non uno per tutti', visti);
    // (il Movimento non ha intestazione d Ordine: il blu e` provato in U3 e U4)
});

sezione('U6. Un giallo solo per il SÌ «colpo annullato»: M.stileTavolozza', () => {
    const { M, err } = motoreTav(true);
    const ATT = 'background:var(--mn-attenzione-fondo,#554400); border-color:var(--mn-attenzione,#ffcc00); color:var(--mn-attenzione,#ffcc00);';
    ok(M.stileTavolozza('attenzione-fondo', 'attenzione', 'attenzione') === ATT, 'M.stileTavolozza(«attenzione-fondo», «attenzione», «attenzione»): la riga della consegna', M.stileTavolozza('attenzione-fondo', 'attenzione', 'attenzione'));
    ok(M.stileTavolozza('si-fondo', 'si', 'testo') === 'background:' + M.colore('si-fondo') + '; border-color:' + M.colore('si') + '; color:' + M.colore('testo') + ';', '  sfondo, bordo e testo nell ordine, ognuno da M.colore');
    ok(/^background:#ff00ff; /.test(M.stileTavolozza('nessuno', 'si', 'testo')) && err.some(e => /"nessuno"/.test(e)), 'CONTROPROVA: un nome fuori tavolozza da` #ff00ff e l errore');
    // Sagoma singola (motore): Alguacil col Missile Launcher sul Fusilier Ingaggiato, parte da SÌ.
    const a = lettere28(/^Alguacil \(Missile Launcher\)/, 'Missile Launcher', 1, { mischia: true, dichiara: (N) => { const fam = Object.keys(N._modiBS || {}).find(f => /Missile/.test(f)); N.declareAttackBS((N._modiBS[fam] || []).find(x => /Blast/i.test(x)), fam); } });
    const si1 = (a.pag.match(/<button type="button" class="huge-btn" style="([^"]*)"[^>]*>SÌ: colpo annullato/) || [])[1] || '';
    // Per lettera (Attacco BS): Chain-colt, F1 Ingaggiato, la A accesa.
    const b = lettere28(CHAIN28, 'Chain-colt', 3, { mischia: true, prep: (N) => N.toggleSagomaBS(1, 'A') });
    const tA = (b.pag.match(/class="burst-btn tasto-sagoma-alleato" style="([^"]*)"[^>]*onclick="window\.toggleSagomaAlleatoBS\('A'\)"/) || [])[1] || '';
    const tB = (b.pag.match(/class="burst-btn tasto-sagoma-alleato" style="([^"]*)"[^>]*onclick="window\.toggleSagomaAlleatoBS\('B'\)"/) || [])[1] || '';
    ok(si1.includes(ATT) && tA.includes(ATT), 'sulla pagina: il SÌ della Sagoma singola e la lettera A accesa hanno lo stesso stile «attenzione»', [si1.slice(-130), tA.slice(-130)]);
    ok(!tB.includes(ATT) && /--mn-fondo-tasto/.test(tB), 'CONTROPROVA: la lettera B spenta non e` gialla (fondo-tasto)', tB.slice(-120));
    ok(!/#ffdd00|#3a3000|--mn-acceso/.test(si1 + tA), '  e del giallo #ffdd00 / dell arancio «acceso» non resta niente');
});

const intestazioni = (d) => { const h = Object.keys(d.elementi).map(k => String(d.elementi[k].innerHTML || '')).join(' ');
    return [...h.matchAll(/<div class="intestazione-ordine" style="([^"]*)">\s*<b[^>]*>([^<]*)<\/b>/g)].map(m => ({ stile: m[1], titolo: m[2] })); };
const senzaCommenti = (t) => t.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"`\\])\/\/[^\n]*/g, '$1');

sezione('V1. Piano grafico: i titoli dei MOD di 12 Ordini da M.intestazioneOrdine', () => {
    // I titoli della schermata dei MOD, nei moduli, ora sono intestazioni.
    const ATTESI = [['ordine_attacco_guidato.js', 'ATTACCO GUIDATO'], ['ordine_attacco_intuitivo.js', 'ATTACCO INTUITIVO'], ['ordine_fuoco_speculativo.js', 'FUOCO SPECULATIVO'],
                    ['ordine_scoprire.js', 'SCOPRIRE'], ['ordine_supporto.js', '${e.strumento.toUpperCase()}'], ['ordine_piazzamento.js', '${arma.nome}'],
                    ['ordine_scenografia.js', "${eDeactivator(azione) ? 'DEACTIVATOR' : 'INTERAGIRE CON OBIETTIVO'}"], ['ordine_logistica.js', '🪂 INGRESSO IN CAMPO'],
                    ['ordine_logistica.js', '📦 REQUEST SPEEDBALL'], ['ordine_trincerarsi.js', '🕳️ TRINCERARSI']];
    const manca = ATTESI.filter(([f, t]) => fs.readFileSync(DIR + f, 'utf8').indexOf('intestazioneOrdine({ colore: COL, titolo: `' + t + '` })') < 0);
    ok(manca.length === 0, 'nei moduli: le schermate dei MOD aprono con M.intestazioneOrdine({ colore: COL, titolo }) (Guidato, Intuitivo, Speculativo, Scoprire, Supporto, Piazzare, Interagire/Deactivator, Ingresso in campo, Speedball, Trincerarsi)', manca);
    const UNDICI = ['ordine_attacco_guidato.js', 'ordine_attacco_intuitivo.js', 'ordine_difesa.js', 'ordine_fuoco_speculativo.js', 'ordine_logistica.js', 'ordine_movimento.js',
                    'ordine_piazzamento.js', 'ordine_scenografia.js', 'ordine_scoprire.js', 'ordine_supporto.js', 'ordine_trincerarsi.js'];
    const vecchi = UNDICI.map(f => [f, (senzaCommenti(fs.readFileSync(DIR + f, 'utf8')).match(/LANCIO MISSILI GUIDATI|MODIFICATORI/g) || []).length]).filter(x => x[1]);
    ok(vecchi.length === 0, 'negli 11 moduli nessun «LANCIO MISSILI GUIDATI» ne` «MODIFICATORI …» fuori dai commenti', vecchi);
    const h2 = UNDICI.map(f => [f, [...fs.readFileSync(DIR + f, 'utf8').matchAll(/<h2[^>]*>([^<]*)<\/h2>/g)].map(m => m[1])]).filter(x => x[1].length);
    ok(h2.every(([f, t]) => t.every(x => /INVIAT|VIAGGIO|REGISTRATO|DETONATA|PIAZZATO|TRINCERATO|IDLE/.test(x))), '  restano <h2> solo sulle schermate di conferma (INVIATO, IN VIAGGIO, REGISTRATO, PIAZZATO…)', h2);
    // Sulla pagina: Schivata e Reset.
    const T = tavolo(T => [tr(P_(T, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' })], T => [FUS(T, 'p1')], 'NOMADI');
    const N = T.nomadi.g, visti = {};
    ['SCHIVATA', 'RESET'].forEach(az => {
        Object.keys(T.nomadi.elementi).forEach(k => { T.nomadi.elementi[k].innerHTML = ''; });
        // La prima meta` fa scattare l allarme ARO; qui si apre direttamente la
        // schermata dei MOD del modulo (window.preparaModificatoriDifesa).
        T.apriMenu(T.nomadi, 0); N.selectAction(az, false); N.preparaModificatoriDifesa(az);
        visti[az] = intestazioni(T.nomadi).map(x => x.titolo);
        visti[az + ' h2'] = (String(T.nomadi.el('targets-allocation-container').innerHTML).match(/<h2[^>]*>[^<]*/g) || []).length; N.tornaAlRadar(); T.giro();
    });
    ok(J(visti.SCHIVATA) === '["SCHIVATA"]' && J(visti.RESET) === '["RESET"]' && visti['SCHIVATA h2'] === 0 && visti['RESET h2'] === 0, 'sulla pagina: la Schivata si intitola «SCHIVATA», il Reset «RESET» (non piu` «MODIFICATORI …»)', visti);
});

sezione('V2. Piano grafico: il Movimento Cauto nel rosso degli Ordini Interi', () => {
    const T = tavolo(T => [tr(P_(T, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' })], T => [FUS(T, 'p1')], 'NOMADI');
    const N = T.nomadi.g, M = N.MotoreN5;
    T.apriMenu(T.nomadi, 0); N.chiediCauto('prima');
    const h = String(T.nomadi.el('targets-allocation-container').innerHTML);
    const ii = intestazioni(T.nomadi).filter(x => x.titolo === 'MOVIMENTO CAUTO');
    const rosso = M.CATEGORIE_ORDINE.intero;
    ok(ii.length === 1 && ii[0].stile.indexOf('background:' + rosso.sfondo + '; border:1px solid ' + rosso.bordo) === 0, 'l intestazione «MOVIMENTO CAUTO» di M.intestazioneOrdine, rossa (#440000 / #ff0000)', ii);
    ok(h.indexOf('<div style="background:' + rosso.riquadro + '; border:1px solid ' + rosso.tenue + ';') >= 0, '  e il riquadro nelle tinte dell Ordine (riquadro ' + rosso.riquadro + ', tenue ' + rosso.tenue + ')');
    const si = (h.match(/style="([^"]*)"\s*onclick="window\.rispondiCauto\(true/) || [])[1] || '', no = (h.match(/style="([^"]*)"\s*onclick="window\.rispondiCauto\(false/) || [])[1] || '';
    ok(si.indexOf(M.stileColore('si')) >= 0 && no.indexOf('border-color:var(--mn-attenzione,#ffcc00)') >= 0, 'i tasti SÌ (verde di M.stileColore) e NO (giallo) non cambiano', [si.slice(-70), no.slice(-90)]);
    ok(M.coloreOrdine('CAUTO').categoria === 'intero' && M.coloreOrdine('MOVIMENTO').categoria === 'movimento', 'CONTROPROVA: Cauto e` Ordine Intero, il Movimento semplice resta blu');
});

sezione('V3. Piano grafico: le etichette dei bersagli di Guidato e Speculativo nella fascia bassa', () => {
    const chiamate = (f) => { const t = fs.readFileSync(DIR + f, 'utf8'); const out = []; let i = -1;
        while ((i = t.indexOf('window.rigaUnitaConFoto(', i + 1)) >= 0) out.push(t.slice(i, t.indexOf('\n', t.indexOf('\n', i) + 1))); return out; };
    const g = chiamate('ordine_attacco_guidato.js'), s = chiamate('ordine_fuoco_speculativo.js');
    const blocco = (f, marca) => { const t = fs.readFileSync(DIR + f, 'utf8'); const i = t.indexOf(marca); return i < 0 ? '' : t.slice(i, t.indexOf('})', i) + 2); };
    const bg = blocco('ordine_attacco_guidato.js', "window.rigaUnitaConFoto(v.unita, { fazione: 'NEMICA', scelta: isP || isS");
    const bs = blocco('ordine_fuoco_speculativo.js', "window.rigaUnitaConFoto(v.unita, { fazione: 'NEMICA', scelta: k >= 0");
    const sano = (b) => /etichette: etichetta/.test(b) && /dopoNome: ` <span[^`]*\[\$\{v\.unita\.tipo \|\| 'LI'\}\]<\/span>`,/.test(b) && !/dopoNome:[^\n]*\+ etichetta/.test(b);
    ok(g.length >= 1 && sano(bg), 'Attacco Guidato: l etichetta del bersaglio va in opz.etichette (fascia bassa); in dopoNome resta solo il [tipo]', bg);
    ok(s.length >= 2 && sano(bs), 'Fuoco Speculativo: lo stesso per i bersagli', bs);
    // La pagina mette opz.etichette nella fascia bassa (.rup-etichette), dopoNome accanto al nome.
    const T = tavolo(T => [tr(P_(T, /^Alguacil \(Combi/), { id: 'n1' })], T => [FUS(T, 'p1', { alias: 'F1' })], 'NOMADI');
    const N = T.nomadi.g, u = N.roster[0];
    const r = String(N.rigaUnitaConFoto(u, { etichette: '<span>🎯 PRIMARIO</span>' }));
    const d = String(N.rigaUnitaConFoto(u, { dopoNome: '<span>🎯 PRIMARIO</span>' }));
    ok(/<div class="rup-etichette"[^>]*><span>🎯 PRIMARIO<\/span>/.test(r) && !/<div class="rup-etichette"[^>]*><span>🎯 PRIMARIO/.test(d), 'CONTROPROVA sulla pagina: opz.etichette finisce in .rup-etichette, dopoNome no');
});

sezione('V4. Piano grafico: Supporto, la scelta dell alleato con la riga della foto', () => {
    const T = tavolo(T => [tr(P_(T, /^Alguacil \(Paramedic/), { id: 'n1', alias: 'Med' }), tr(P_(T, /^Alguacil \(Combi/), { id: 'n2', alias: 'Ferito', states: { unconscious: true } })],
                     T => [FUS(T, 'p1')], 'NOMADI');
    const N = T.nomadi.g;
    T.apriMenu(T.nomadi, 0); N.selectAction('MEDICO_INGEGNERE', false);
    const ids = [...String(T.nomadi.el('weapon-buttons-container').innerHTML).matchAll(/scegliStrumentoSupporto\('([^']+)'\)/g)].map(m => m[1]);
    N.scegliStrumentoSupporto(ids[0]);
    const h = String(T.nomadi.el('enemy-target-buttons').innerHTML);
    const riga = (h.match(/<button type="button" class="huge-btn riga-unita[^"]*"[^>]*onclick="window\.scegliBersaglioSupporto\('n2'\)"[\s\S]*?<\/button>/) || [''])[0];
    ok(ids.length >= 1 && !!riga, 'l alleato Incosciente e` una riga di window.rigaUnitaConFoto (class riga-unita) col tocco scegliBersaglioSupporto', { ids, inizio: h.slice(0, 160) });
    ok(/<div class="rup-etichette"[^>]*><span style="color:[^"]*;">🩺 Incosciente<\/span>/.test(riga), '  con «🩺 Incosciente» nella fascia bassa', (riga.match(/rup-etichette[\s\S]{0,120}/) || [])[0]);
    ok(!/<button class="huge-btn" style="width:100%; min-height:60px; font-size:var\(--fs-l\)[^>]*scegliBersaglioSupporto/.test(h), 'CONTROPROVA: non c e` piu` il bottone col solo nome');
});

console.log(`\n──────────────\n${passati} passati, ${falliti} falliti\n`);
process.exit(falliti ? 1 : 0);
