// @versione 2026-10-29.1 | test_schieramento.js | proprieta`: chat TEST
// .1 (29 ott, giro 21): sez. 5 Holoecho (motore 2026-10-29.5): l etichetta e`
//    «HOLOECHO» (era «COPIA OLOGRAFICA»), col numero «HOLOECHO n» e il suo
//    segnalino holoecho_<n>.png; senza numero il segnalino comune '0'.
// .1 (26 ott): sez. 5 HoloMask girata (motore 2026-10-26.3): dati veri e p.mostraCome,
//    niente piu` "Sconosciuta".
// Test del filtro anti-spoiler — node test_schieramento.js
global.window = global;
require('./catalogo_n5.js'); require('./database_comune.js');
require('./database_nomad.js'); require('./database_panoceania.js');
const M = require('./motore_regole_n5.js');
require('./fase_schieramento.js');

let passati = 0, falliti = 0;
function ok(c, n, e) { if (c) { passati++; console.log(`  ✅ ${n}`); } else { falliti++; console.log(`  ❌ ${n}${e ? '\n       ' + e : ''}`); } }

const croc = { id: 'n1', nome: 'Croc Man (Sniper Rifle)', alias: 'Croc', tipo: 'LI',
    deployState: 'CAMO_0', cc: 15, bs: 12, ph: 11, wip: 13, arm: 1, bts: 3, w: 1,
    weapon: 'MULTI Sniper Rifle, Pistol', skills: 'Mimetism (-6), Infiltration, Booty',
    equip: 'Multispectral Visor L1', states: {} };
const con = (extra) => Object.assign({}, croc, extra);

console.log('\n=== 1. LA FUGA: di un Marker non deve trapelare nulla ===');
const marker = M.filtraPerAvversario(croc);
['cc', 'bs', 'ph', 'wip', 'arm', 'bts', 'w', 'weapon', 'skills', 'equip'].forEach(function (k) {
    ok(marker[k] === undefined, `${k}: NON spedito (prima arrivava all avversario)`);
});
ok(marker.nome === 'MARKER' && marker.alias === 'SEGNALINO MIMETICO',
   'nemmeno il nome dell Unità: solo l etichetta del segnalino');
ok(marker.id === 'n1' && marker.tipo === 'MARKER', 'restano id e tipo: servono a disegnarlo');

const imp = M.filtraPerAvversario(con({ deployState: 'IMP_1' }));
ok(imp.alias === 'PERSONAGGIO SCONOSCIUTO' && imp.weapon === undefined,
   'Impersonation: stesso trattamento');

console.log('\n=== 2. Il filtro è per ELENCO, non per sottrazione ===');
// un campo nuovo, che il filtro vecchio avrebbe lasciato passare
const conCampoNuovo = M.filtraPerAvversario(con({ segretoDelGiocatore: 'piano di battaglia' }));
ok(conCampoNuovo.segretoDelGiocatore === undefined,
   'un campo aggiunto in futuro non passa: è la differenza fra elenco e sottrazione');

console.log('\n=== 3. Chi non è sul tavolo non esiste ===');
['HIDDEN', 'RESERVE', 'AD'].forEach(function (d) {
    ok(M.filtraPerAvversario(con({ deployState: d })) === null,
       `${d}: non spedito affatto`);
});
ok(M.filtraPerAvversario(con({ deployState: 'NORMAL', states: { hidden: true } })) === null,
   'anche se il nascondimento è negli stati');

console.log('\n=== 4. Chi è a faccia in su si vede tutto ===');
const v = M.filtraPerAvversario(con({ deployState: 'NORMAL' }));
ok(v.nome === 'Croc Man (Sniper Rifle)' && v.weapon && v.skills && v.bs === 12,
   'truppa visibile: profilo completo, com è giusto');

console.log('\n=== 5. Casi particolari ===');
const holo = M.filtraPerAvversario(con({ deployState: 'NORMAL', states: { holoecho: true } }));
// RISCRITTA il 29 ottobre (motore 2026-10-29.5): prima «COPIA OLOGRAFICA».
ok(holo.alias === 'HOLOECHO' && holo.imgVariant === '0' && holo.bs === 12, 'Holoecho: etichettato «HOLOECHO», visibile come modello, senza numero il segnalino comune \'0\'');
const holo2 = M.filtraPerAvversario(con({ deployState: 'NORMAL', states: { holoecho: true }, numeroReplica: 2 }));
ok(holo2.alias === 'HOLOECHO 2' && holo2.imgVariant === 'holoecho_2.png', '  col numero 2: «HOLOECHO 2» e il segnalino holoecho_2.png', holo2.alias + ' ' + holo2.imgVariant);
const decoy = M.filtraPerAvversario(con({ deployState: 'NORMAL', states: { decoy: true } }));
ok(decoy.alias === 'BERSAGLIO DECOY', 'Decoy: idem');

// 🔴 GIRATA IL 26 OTTOBRE (motore 2026-10-26.3). Prima: nome finto e armi
// "Sconosciuta" — cosi` l'avversario capiva che era una maschera, e all'Hub
// l'ARO non trovava la sua arma. Ora i dati restano VERI (decisione di
// Paolo: i dati non si mascherano, si tengono fuori dallo schermo) e il
// motore aggiunge p.mostraCome, quello che schermo e Hub devono mostrare.
const mask = M.filtraPerAvversario(con({ deployState: 'HOLOMASK', fakeName: 'Fusilier' }));
ok(mask.weapon === croc.weapon && !/Sconosciuta/.test(JSON.stringify(mask)),
   'HoloMask: niente piu` "Sconosciuta", le armi restano vere');
ok(mask.mostraCome && mask.mostraCome.nome === 'Fusilier', 'HoloMask: mostraCome col nome da mostrare (' + JSON.stringify(mask.mostraCome) + ')');
const alg = DB_NOMADI.find(u => /^Alguacil \(Combi/.test(u.nome));
const mask2 = M.filtraPerAvversario(con({ deployState: 'NORMAL', states: { holomask: true }, holomaskImita: alg.id }));
const mc = mask2.mostraCome || {};
ok(mc.nome === alg.nome && mc.weapon === alg.weapon && mc.skills === alg.skills && mc.tipo === alg.tipo && mc.bs === alg.bs && mc.arm === alg.arm && mc.imitato === alg.id,
   'HoloMask con holomaskImita: nome, armi, abilita`, tipo e statistiche del Modello imitato (' + mc.nome + ', BS ' + mc.bs + ')');
ok(mask2.bs === croc.bs && mask2.weapon === croc.weapon, '  e i dati della truppa restano i suoi (BS ' + mask2.bs + ')');
ok(v.mostraCome === undefined && holo.mostraCome === undefined, 'CONTROPROVA: senza HoloMask nessun mostraCome');

const seed = M.filtraPerAvversario(con({ deployState: 'SEED' }));
ok(seed.alias === 'SEED-EMBRYO' && seed.weapon === undefined, 'Seed-Embryo: solo il segnalino');

const fox = M.filtraPerAvversario(con({ deployState: 'FOXHOLE' }));
ok(fox.states.foxhole === true && fox.weapon, 'Foxhole: pubblico, profilo visibile');

console.log('\n=== 6. Roster intero ===');
const roster = [croc, con({ id: 'n2', deployState: 'NORMAL' }), con({ id: 'n3', deployState: 'HIDDEN' })];
const pub = M.rosterPubblico(roster);
ok(pub.length === 2, 'il nascosto sparisce dal roster pubblico');
ok(pub.every(u => u.id), 'gli altri due ci sono');

console.log('\n=== 7. Promemoria post-schieramento ===');
// Fonte: REGOLE_N5_v5_1_1.txt, voce INFILTRATION, "INFILTRATION ROLL":
//   "An Infiltration Roll is required to infiltrate into the enemy's half of
//    the table. This is a Normal Roll with PH-3."
//   e sul fallimento: "the user loses the option to deploy in a Marker State
//    or Hidden Deployment State" — quindi il tiro lo fa ANCHE chi si schiera
//    come Marker. La prima versione di questa sezione asseriva il contrario
//    ("nessun promemoria se non è schierato in modo normale"): era il test a
//    sbagliare, e con il motore 2026-09-21.21 e` diventato rosso.
const conInfiltrazione = (stato) => M.promemoriaSchieramento([con({ deployState: stato })])
    .some(p => p.skill === 'INFILTRATION');

const pro = M.promemoriaSchieramento([con({ deployState: 'NORMAL' })]);
ok(pro.some(p => p.skill === 'BOOTY'), 'Booty: promemoria generato');
ok(conInfiltrazione('NORMAL'), 'Infiltration schierato come Modello: promemoria');
ok(conInfiltrazione('CAMO'),   'Infiltration schierato come Marker CAMO: promemoria (anche il Marker tira)');
ok(conInfiltrazione('IMP'),    'Infiltration schierato in Impersonation: promemoria');

// Controprova 1: chi non e` ancora sul tavolo non tira niente.
ok(!conInfiltrazione('RESERVE'), 'in Riserva: nessun promemoria, non e` ancora sul tavolo');

// Controprova 2: senza l'abilita` il promemoria non deve comparire, altrimenti
// i tre "si`" qui sopra non dimostrerebbero nulla.
const fus = Object.assign(JSON.parse(JSON.stringify(
    window.DB_PANOCEANIA.find(u => u.nome === 'Fusilier (Combi Rifle)'))), { deployState: 'NORMAL', states: {} });
ok(!/Infiltration/i.test(fus.skills || ''), 'controprova: il Fusilier non ha Infiltration nel database');
ok(!M.promemoriaSchieramento([fus]).some(p => p.skill === 'INFILTRATION'),
   'controprova: senza Infiltration nessun promemoria di infiltrazione');

// Il testo deve nominare il PH fra parentesi del profilo, oltre al PH-3.
const testoInf = (pro.find(p => p.skill === 'INFILTRATION') || {});
const t = String(testoInf.testo || testoInf.messaggio || '');
ok(/PH-3/.test(t) && /parentesi/i.test(t), 'il testo cita PH-3 e il PH fra parentesi del profilo');

// Il promemoria fa il conto (motore 2026-09-21.27): PH-3 del profilo, o il PH
// fra parentesi se il profilo lo dichiara. Lo Zero si legge dal database; la
// variante fra parentesi non esiste in nessun profilo dei due database, quindi
// si costruisce sullo stesso Zero cambiando solo la notazione.
const zeroDb = window.DB_NOMADI.find(u => u.nome === 'Zero (Combi Rifle)');
const testoInfDi = (u) => { const q = M.promemoriaSchieramento([Object.assign(JSON.parse(JSON.stringify(u)), { deployState: 'NORMAL', states: {} })])
                                     .find(p => p.skill === 'INFILTRATION') || {}; return String(q.testo || q.messaggio || ''); };
ok(zeroDb && zeroDb.ph === 12 && /\bInfiltration\b(?!\s*\()/.test(zeroDb.skills), 'lo Zero nel database: PH 12, Infiltration senza parentesi');
ok(/Tiro a 9\b/.test(testoInfDi(zeroDb)), `Zero: "Tiro a 9" (${testoInfDi(zeroDb).match(/Tiro a[^.]*/) || 'nessun conto'})`);
const zeroPH11 = Object.assign({}, zeroDb, { skills: zeroDb.skills.replace(/\bInfiltration\b/, 'Infiltration (PH=11)') });
ok(/Tiro a 11\b/.test(testoInfDi(zeroPH11)), `Infiltration (PH=11): "Tiro a 11", il valore fra parentesi sostituisce PH-3`);
// Controprova: il numero segue il PH del profilo, non e` scritto fisso.
const zeroPH14 = Object.assign({}, zeroDb, { ph: 14 });
ok(/Tiro a 11\b/.test(testoInfDi(zeroPH14)) && !/Tiro a 9\b/.test(testoInfDi(zeroPH14)),
   'controprova: lo stesso Zero con PH 14 tira a 11, non a 9');

// Hidden Deployment — risolto dalla fonte. REGOLE_N5_v5_1_1.txt riga 13896,
// voce HIDDEN DEPLOYMENT: "Although the Trooper in Hidden Deployment is not
// considered to be on the table, if the Trooper has the Infiltration Special
// Skill and makes an Infiltration Roll, the Roll must be made once their
// position is written down." Il nascosto che si infiltra tira: promemoria si`.
// (La prima versione asseriva il contrario, marcata DA VERIFICARE; il motore
// 2026-09-21.25 ha applicato la riga e il test e` diventato rosso.)
ok(conInfiltrazione('HIDDEN'),
   'HIDDEN: promemoria — il nascosto con Infiltration tira alla scrittura della posizione (riga 13896)');

console.log('\n=== 8. Il modulo usa il motore ===');
const payload = window.faseSchieramento.preparaPayloadHub([croc], [], []);
ok(payload.roster[0].weapon === undefined, 'il payload verso l Hub è filtrato');
ok(window.faseSchieramento.validaSchieramento([con({ deployState: 'NORMAL' })]).length >= 2,
   'i promemoria passano dal motore');

console.log('\n=== 9. La busta non porta il roster privato ===');
// Capovolta il 25 settembre. Prima questa sezione asseriva che il payload
// contenesse anche `rosterPrivato` completo: era la FUGA, non una
// caratteristica. Ogni canale passa da Firebase all'app dell'avversario, che
// ascolta tutti gli 11 canali e se li copia nel proprio localStorage — quei
// dati finivano sul suo telefono. La copia privata resta sul dispositivo.
ok(!('rosterPrivato' in payload), `la busta NON porta rosterPrivato (chiavi: ${Object.keys(payload).join(', ')})`);
ok(JSON.stringify(payload).indexOf('MULTI Sniper Rifle') < 0,
   'e nel testo della busta non compare l arma del Camuffato');

const TUTTI = [...window.DB_NOMADI, ...window.DB_PANOCEANIA];
const prof = (re, extra) => Object.assign(JSON.parse(JSON.stringify(TUTTI.find(u => re.test(u.nome)))), extra);
const camo = prof(/^Croc Man \(MULTI Sniper/, { deployState: 'CAMO', states: { camo: true, wounds: 1 } });
const nascosto = prof(/^Spektr/, { deployState: 'HIDDEN', states: { hidden: true } });
const visibile = prof(/^Fusilier \(Combi/, { states: {} });
const busta = window.faseSchieramento.preparaPayloadHub([camo, nascosto, visibile], [], []);
ok(busta.roster.length === 2, `l unità in Hidden Deployment non è nella busta (${busta.roster.length} su 3)`);
ok(!busta.roster.some(u => /Spektr/.test(JSON.stringify(u))), 'e il suo nome non compare da nessuna parte');
const vistoCamo = busta.roster.find(u => u.states && u.states.camo);
ok(vistoCamo && JSON.stringify(vistoCamo.states) === JSON.stringify({ camo: true, impersonation: false }),
   `del Camuffato arrivano solo camo e impersonation (${JSON.stringify(vistoCamo && vistoCamo.states)})`);
ok(vistoCamo && !vistoCamo.weapon && !(vistoCamo.states || {}).wounds,
   'né l arma né la ferita');
// Controprova: l'unità visibile arriva com'è, altrimenti il filtro starebbe
// solo svuotando tutto.
const vistoFus = busta.roster.find(u => /Fusilier/.test(JSON.stringify(u)));
ok(!!vistoFus && vistoFus.weapon === 'Combi Rifle', `l unità visibile arriva intera (${vistoFus && vistoFus.weapon})`);

console.log(`\n──────────────\n${passati} passati, ${falliti} falliti\n`);
process.exit(falliti ? 1 : 0);
