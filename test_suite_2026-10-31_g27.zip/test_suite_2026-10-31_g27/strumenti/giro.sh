#!/bin/bash
# uso: giro.sh CARTELLA USCITE   — un file = una riga di riepilogo; banco_confronto.js fuori dal conto
cd "$1"; O="$2"; mkdir -p "$O"; : > "$O/riepilogo.tsv"
ls test_*.js | xargs -P 8 -I{} sh -c 'timeout 300 node "{}" > "'$O'/{}.out" 2>&1; echo $? > "'$O'/{}.rc"'
R='^[0-9]+ passati, [0-9]+ falliti'
for f in test_*.js; do
  n=$(grep -cE "$R" "$O/$f.out"); r=$(grep -E "$R" "$O/$f.out" | tail -1)
  p=$(echo "$r" | sed -E 's/^([0-9]+) passati.*/\1/'); x=$(echo "$r" | sed -E 's/^[0-9]+ passati, ([0-9]+) falliti.*/\1/')
  k=$(echo "$r" | sed -nE 's/.*falliti, ([0-9]+) non eseguite.*/\1/p'); q=$(echo "$r" | sed -nE 's/.*\(fonte assente: ([^)]*)\).*/\1/p')
  printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\n" "$f" "${p:--}" "${x:--}" "$n" "$(cat $O/$f.rc)" "${k:-0}" "$q" >> "$O/riepilogo.tsv"
done
awk -F'\t' '{f++; if($2!="-"){p+=$2; x+=$3} k+=$6; if($6>0) w=w"\n    "$1": "$6" ("$7")"; if($4!=1) s=s" "$1"("$4")"; if($5!=0) u=u" "$1"(rc="$5")"} END{print "file: "f" | passati: "p" | falliti: "x" | non eseguite: "k; if(k) print "  non eseguite per fonte assente:"w; print "righe di riepilogo != 1:"(s?s:" nessuno"); print "uscita != 0:"(u?u:" nessuno")}' "$O/riepilogo.tsv"
