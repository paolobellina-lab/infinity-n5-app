// uso (dalla cartella dei file): node cattura_gr.js USCITA.json   — le schermate di GR-E08/E11/E25/E25b/E26/E36
// dall harness dei banchi (testa di test_novita_28ott.js); poi: node misura_info.js CARTELLA USCITA.json DIR_FOTO etichetta
// Cattura dall'harness dei banchi l'HTML delle schermate di GR-E08/E11/E25/E25b/E26/E36.
const fs=require('fs');const src=fs.readFileSync('test_novita_28ott.js','utf8');
const i=src.indexOf("\nsezione(");
eval(src.slice(0,i)+`
const OUT = process.argv[2];
const scatto = (d, nome) => { const g = d.g; const step = g._stepCorrente; const el = {};
  Object.keys(d.elementi).forEach(k => { const e = d.elementi[k]; if (/^(nuovo_|q:)/.test(k)) return; el[k] = { html: String(e.innerHTML || ''), display: (e.style && e.style.display) || '' }; });
  const voci = g.vociInfo(step) || [];
  const tit = (Object.values(el).map(x => x.html).join(' ').match(/<div class="intestazione-ordine"[^>]*>\\s*<b[^>]*>[^<]*/g) || []).map(x => x.replace(/^[\\s\\S]*>/, ''));
  console.log(nome, 'step', step, 'voci', voci.length, 'titoli', JSON.stringify(tit), 'errori', g.errori.length);
  return { nome, step, voci, el, opzioni: g.opzioniNote ? g.opzioniNote() : null };
};
const tutte = [];
const NEM = T => [FUS(T,'p1',{alias:'Fante'}), tr(T.profilo(T.pano, /^Fusilier \\(Missile/), {id:'p2', alias:'Bazooka'}), tr(T.profilo(T.pano, /^Orc/), {id:'p3', alias:'Orc'}),
                  tr(T.profilo(T.pano, /^Croc Man/), {id:'p6', alias:'Croc', deployState:'CAMO', states:{camo:true}})];
const el = (d, id) => String(d.el(id).innerHTML);
// E08
{ const T = tavolo(T => [tr(P_(T, /^Intruder \\(Hacker, Killer Hacking Device\\)/), { id: 'n25', alias: 'Intruder Hacker', deployState:'CAMO', states:{camo:true} })], NEM, 'NOMADI');
  const N = T.nomadi.g; T.apriMenu(T.nomadi, 0); N.selectAction('FUOCO SPECULATIVO', false);
  const a = (el(T.nomadi,'weapon-buttons-container').match(/declareSpeculativoAttack\\('([^']*Grenade[^']*)'/) || [])[1]; N.declareSpeculativoAttack(a); T.giro();
  tutte.push(scatto(T.nomadi, 'GR-E08')); }
// E11
{ const T = tavolo(T => [tr(P_(T, /^Morlock \\(Assault/), { id: 'n13', alias: 'Morlock' })], NEM, 'NOMADI');
  const N = T.nomadi.g; T.apriMenu(T.nomadi, 0); N.selectAction('ATTACCO INTUITIVO', false);
  const a = (el(T.nomadi,'weapon-buttons-container').match(/declareIntuitivoAttack\\('([^']*Chain[^']*)'/) || [])[1]; N.declareIntuitivoAttack(a); T.giro();
  tutte.push(scatto(T.nomadi, 'GR-E11')); }
// E25
{ const T = tavolo(T => [tr(P_(T, /^Puppet Masters/), { id: 'n22', alias: 'Posa' })], NEM, 'NOMADI');
  const N = T.nomadi.g; T.apriMenu(T.nomadi, 0); N.selectAction('PIAZZARE EQUIPAGGIAMENTO', false); T.giro();
  tutte.push(scatto(T.nomadi, 'GR-E25')); }
// E25b / E26
{ const T = tavolo(T => [tr(P_(T, /^Moran/), { id: 'n19', alias: 'Moran', deployState:'CAMO', states:{camo:true}, usiSpesi: { CRAZYKOALAS: 2, 'CRAZYKOALAS': 2, CrazyKoalas: 2 } })], NEM, 'NOMADI');
  const N = T.nomadi.g; T.apriMenu(T.nomadi, 0); N.selectAction('PIAZZARE EQUIPAGGIAMENTO', false); T.giro();
  tutte.push(scatto(T.nomadi, 'GR-E25b')); }
{ const T = tavolo(T => [tr(P_(T, /^Moran/), { id: 'n19', alias: 'Moran', deployState:'CAMO', states:{camo:true} })], NEM, 'NOMADI');
  const N = T.nomadi.g; T.apriMenu(T.nomadi, 0); N.selectAction('PIAZZARE EQUIPAGGIAMENTO', false); N.scegliArmaDaPiazzare('CrazyKoalas'); T.giro();
  tutte.push(scatto(T.nomadi, 'GR-E26')); }
// E36
{ const T = creaTavolo(DIR); const N = T.nomadi.g;
  const rN = [tr(P_(T, /^Grenzer \\(Forward Observer, Sensor, NCO\\)/), { id: 'n12', alias: 'Grenzer' })], rP = NEM(T);
  const cons = (N.DB_STRUTTURE || N.dbStrutture || []).find ? null : null;
  const st = [Object.assign({}, (N.DB_COMUNE && [].concat(N.DB_COMUNE).find(x => x.id === 'obj_console')) || { id: 'obj_console', nome: 'Console di Comando', tipo: 'STRUTTURA', skills: 'Hackable, Objective', arm: 1, bts: 3, str: 1, s: 2, weapon: '-', equip: '-' }, { id: 's1', modelId: 'obj_console', alias: 'Console' })];
  N.roster = rN; T.pano.g.roster = rP;
  [T.nomadi, T.pano].forEach(d => { d.g.activeStructures = d.g === N ? st : []; d.g.activeTerrains = []; d.g.schieramentoCompletato = true; });
  N.inviaSchieramentoAllHub('NOMADI', { roster: rN, strutture: st, terreni: [] });
  T.pano.g.inviaSchieramentoAllHub('PANOCEANIA', { roster: rP, strutture: [], terreni: [] });
  T.giro(); if (T.hub.g.gameState.activeFaction !== 'NOMADI') T.hub.g.toggleTurn(); T.giro();
  console.log('scenografia', JSON.stringify(N.MotoreN5.scenografia().map(x => x.alias || x.nome)));
  T.apriMenu(T.nomadi, 0); N.selectAction('INTERAGIRE OBIETTIVO', false); T.giro();
  const b = (Object.keys(T.nomadi.elementi).map(k=>String(T.nomadi.elementi[k].innerHTML||'')).join(' ').match(/scegliBersaglioScenografia\\(([^)]*)\\)/) || [])[1];
  console.log('E36 bersaglio', b); if (b) { vm.runInContext('window.scegliBersaglioScenografia(' + b + ')', N); T.giro(); }
  tutte.push(scatto(T.nomadi, 'GR-E36')); }
fs.writeFileSync(OUT, JSON.stringify(tutte));
process.exit(0);
`);
