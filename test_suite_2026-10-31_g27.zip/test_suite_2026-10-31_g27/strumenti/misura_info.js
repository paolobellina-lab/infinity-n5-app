// Strumento della chat TEST (giro 20): misura in Chromium a 390 px se il testo dei titoli tocca il tasto ⓘ.
// Misura in Chromium a 390 px: il testo dei titoli tocca il tasto ⓘ?
// uso: node misura.js CARTELLA_APP cattura.json uscita_dir etichetta
const { chromium } = require('playwright'); const fs = require('fs'), path = require('path');
const [DIR, CATT, OUT, TAG] = process.argv.slice(2);
(async () => {
  const sc = JSON.parse(fs.readFileSync(CATT, 'utf8'));
  const b = await chromium.launch(); const res = [];
  for (const s of sc) {
    const p = await b.newPage({ viewport: { width: 390, height: 844 } });
    await p.route(/^https?:/, r => r.abort());
    await p.addInitScript(() => {
      window.firebase = { initializeApp: () => ({}), database: () => ({ ref: () => ({ on() {}, set() {}, update() {}, remove() {}, once: () => Promise.resolve({ val: () => null }) }) }) };
      window.alert = () => {}; window.confirm = () => true;
    });
    await p.goto('file://' + path.resolve(DIR, 'app.html') + '?fazione=nomadi');
    await p.waitForTimeout(300);
    const r = await p.evaluate((s) => {
      // Solo i contenitori disegnati (il body finto dell'harness e` vuoto: scritto, cancellerebbe la pagina).
      Object.keys(s.el).forEach(id => { const e = document.getElementById(id); if (!e || id === 'body' || !s.el[id].html) return; e.innerHTML = s.el[id].html; });
      // Lo step da mostrare: quello che contiene l'ultima intestazione disegnata
      // (nell'harness _stepCorrente e` l'ultimo segnato, non sempre quello a schermo).
      document.querySelectorAll('.step-container').forEach(e => { e.style.display = 'none'; });
      const ii = [].slice.call(document.querySelectorAll('.intestazione-ordine'));
      const ultimo = ii.length ? ii[ii.length - 1].closest('.step-container') : null;
      const st = ultimo || document.getElementById(s.step);
      // Come in partita: niente schieramento, la testata accesa, lo step da goToStep
      // (che segna lo step, accende o spegne la ⓘ e libera lo spazio dei titoli).
      const setup = document.getElementById('setup'); if (setup) setup.style.display = 'none';
      window.vociInfo = () => s.voci;
      window.goToStep(st.id);
      window.aggiornaTastoInfo(); window.liberaSpazioInfo && window.liberaSpazioInfo();
      const t = document.getElementById('tasto-info'); const tr = t.getBoundingClientRect(); const acceso = getComputedStyle(t).display !== 'none';
      const titoli = [].slice.call(st.querySelectorAll('h1, h2, .intestazione-ordine, [id^="aro-header-"]'));
      const bh = document.getElementById('battle-header'); if (bh && bh.offsetParent) titoli.push(bh);
      const out = titoli.filter(e => e.offsetParent !== null).map(e => {
        const rg = document.createRange(); const tn = e.querySelector('b') || e; rg.selectNodeContents(tn);
        const rs = [].slice.call(rg.getClientRects()).filter(q => q.width > 0);
        const tocca = acceso && rs.some(q => q.bottom > tr.top && q.top < tr.bottom && q.right > tr.left && q.left < tr.right);
        const fine = rs.length ? Math.max.apply(null, rs.filter(q => q.top < tr.bottom).map(q => q.right).concat([0])) : 0;
        return { testo: (tn.textContent || '').trim().slice(0, 40), sottoInfo: e.classList.contains('sotto-info'), righe: rs.length, fineTestoInAlto: Math.round(fine), tocca };
      });
      return { step: st && st.id, tasto: acceso ? { left: Math.round(tr.left), top: Math.round(tr.top), bottom: Math.round(tr.bottom) } : null, titoli: out };
    }, s);
    await p.screenshot({ path: path.join(OUT, TAG + '_' + s.nome + '.png'), clip: { x: 0, y: 0, width: 390, height: 260 } });
    res.push(Object.assign({ prova: s.nome }, r)); await p.close();
  }
  await b.close(); console.log(JSON.stringify(res, null, 1));
})().catch(e => { console.error(e); process.exit(1); });
