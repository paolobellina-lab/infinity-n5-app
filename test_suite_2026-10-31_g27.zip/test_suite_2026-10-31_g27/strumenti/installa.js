// prende dal registro principale l ULTIMA lettura di ciascun nome dato
const fs=require('fs'),path=require('path');
const [J,OUT,...nomi]=process.argv.slice(2); const ult={};
function prendi(o){ if(typeof o==='string'){ if(o.startsWith('{"method":"project_read"')){ let r; try{r=JSON.parse(o);}catch(e){return;}
  if(typeof r.content==='string') ult[r.path]=r.content; else if(r.local_file&&fs.existsSync(r.local_file)) ult[r.path]=fs.readFileSync(r.local_file,'utf8'); } return; }
  if(o&&typeof o==='object') for(const k in o) prendi(o[k]); }
for(const riga of fs.readFileSync(J,'utf8').split('\n')){ if(!riga) continue; try{prendi(JSON.parse(riga));}catch(e){} }
for(const n of nomi){ if(!(n in ult)){console.log('MANCA',n);continue;} fs.writeFileSync(path.join(OUT,n),ult[n]); console.log('installato',n,ult[n].length,'caratteri'); }
