// uso: node conteggio.js CARTELLA_SENZA_FONTI USCITE_SENZA USCITE_CON DATA_TESTO FILE_OUT
const fs=require('fs'),path=require('path');const [D,US,UC,DATA,OUT]=process.argv.slice(2);
const lg=console.log;console.log=()=>{};const M=require(path.join(D,'motore_regole_n5.js'));console.log=lg;
const imp=f=>{const s=fs.readFileSync(path.join(D,f),'utf8');return {v:(s.match(/@versione\s+(\S+)/)||[])[1],i:M.impronta(s),p:(s.match(/propriet\S*\s+chat\s+(\S+)/)||[])[1]};};
const leggi=d=>{const o={};fs.readFileSync(path.join(d,'riepilogo.tsv'),'utf8').split('\n').filter(Boolean).forEach(r=>{const a=r.split('\t');o[a[0]]={p:+a[1],x:+a[2],n:+a[3],k:+a[5],q:a[6]||''};});return o;};
const S=leggi(US),C=leggi(UC);
const prod=['motore_regole_n5.js','catalogo_n5.js','motore_core.js','logica_stati.js','logica_aro.js','app.html','calcolatore_math.js','calcolatore_controller.js','roster_manager.js','ordine_attacco_guidato.js','ordine_attacco_bs.js','ordine_coordinato.js','ordine_piazzamento.js','ordine_osservazione.js','ordine_hacking.js','ordine_scoprire.js','ordine_supporto.js','ordine_difesa.js','ordine_attacco_intuitivo.js','ordine_fuoco_speculativo.js','calcolatore_hub.html','database_comune.js','database_nomad.js','database_panoceania.js','banco_confronto.js','PIANO_COLLAUDO_N5.md'];
const t=[];
t.push('CONTEGGIO DELLA SUITE — chat TEST, '+DATA+' (cartella allineata al Project, impronte ricalcolate con M.impronta)','','PRODUZIONE');
prod.forEach(f=>{const e=imp(f);t.push('  '+f.padEnd(28)+String(e.v).padEnd(16)+e.i);});
t.push('','CONVENZIONE: un file = una riga di riepilogo; si somma su TUTTI i file','test_*.js, test_collaudo_suite.js COMPRESO. banco_confronto.js NON','stampa la riga e non entra nel conto. Nessun banco stampa piu di una riga.','',
'FONTI FUORI DAL PROJECT (dal 9 ottobre sera): 501.json, 101.json e','REGOLE_N5_v5_1_1.txt non stanno piu nel Project. Le prove che li leggono','sono NON ESEGUITE: ne rosse ne verdi, contate a parte e nominate. La','colonna "prove" e il numero con le fonti in cartella; "n.e." quante di','quelle non si eseguono quando le fonti mancano. La misura a ogni giro e','    file: N | passati: X | falliti: Y | non eseguite: K','',
'banco                              prove  n.e.  versione        impronta          proprieta','-'.repeat(98));
let tot=0,ne=0,mot=0,inter=0,nI=0,nM=0;const strane=[];
Object.keys(C).sort().forEach(f=>{const e=imp(f),c=C[f],s=S[f];const prove=c.p+c.x;tot+=prove;ne+=s.k;if(c.n!==1||s.n!==1)strane.push(f);
 if(e.p==='INTERFACCIA'){inter+=prove;nI++;}else{mot+=prove;nM++;}
 if(s.p+s.x+s.k!==prove)throw new Error('somma non torna per '+f+': '+JSON.stringify([s,c]));
 t.push(f.padEnd(34)+String(prove).padStart(6)+String(s.k||'').padStart(6)+'  '+String(e.v).padEnd(16)+String(e.i).padEnd(18)+e.p);});
const fc=Object.values(C).reduce((a,c)=>a+c.x,0),fs_=Object.values(S).reduce((a,c)=>a+c.x,0);
t.push('-'.repeat(98),'TOTALE CON LE FONTI                '+String(tot-fc).padStart(5)+'   passati su '+Object.keys(C).length+' file, '+fc+' falliti, 0 non eseguite','TOTALE COME IL PROJECT (senza)     '+String(tot-ne-fs_).padStart(5)+'   passati su '+Object.keys(S).length+' file, '+fs_+' falliti, '+ne+' non eseguite','','NON ESEGUITE PER FONTE ASSENTE');
Object.keys(S).sort().filter(f=>S[f].k).forEach(f=>t.push('  '+f.padEnd(32)+String(S[f].k).padStart(3)+'   '+S[f].q));
t.push('','SPACCATO PER PROPRIETA (con le fonti)','  TEST + MOTORE                    '+String(mot).padStart(5)+'   su '+nM+' file','  INTERFACCIA                      '+String(inter).padStart(5)+'   su '+nI+' file','','banco_confronto.js: uscita 0, "da guardare 0" in tutte e quattro le sezioni.','File senza riga di riepilogo: '+(strane.length?strane.join(', '):'nessuno')+'.','');
fs.writeFileSync(OUT,t.join('\n'));lg(t.slice(-16).join('\n'));
