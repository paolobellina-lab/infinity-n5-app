// preload: stampa su stderr ogni nota depositata (M.nota senza app.html -> window.INFO)
const voci = {};
globalThis.INFO = new Proxy(voci, { set(t, k, v) { t[k] = v; if (Array.isArray(v)) { const p = v.push.bind(v); v.push = (...a) => { a.forEach(x => process.stderr.write('NOTA ' + k + ' | ' + x.titolo + ' | ' + x.testo + ' | ' + x.tipo + '\n')); return p(...a); }; } return true; } });
