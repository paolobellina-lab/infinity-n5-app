// @versione 2026-10-30.2 | test_novita_29ott.js | proprieta`: chat TEST
// ============================================================================
// 2026-10-30.2 (giro 25, motore_core 2026-10-30.1, ordine_movimento 30.1): Y2 GIRATA
//    (il «no» di SCENDI DAL TAG ha gli accenti); nuova Y3: alert e confirm della
//    pagina passano da M.accenti (__conAccenti), il no di RISALI e di RICARICARE.
// 2026-10-30.1 (giro 24, motore 2026-10-29.8, ordine_movimento 29.2, logica_aro 30.1):
//    Y-A la nota del secondo allarme con le lettere accentate (prima «meta`», «e`»);
//    nuova Y2: gli accenti negli avvisi di SCENDI DAL TAG e RICARICARE, e le
//    intestazioni dei Gruppi nell elenco di chi reagisce (contano le righe che
//    compaiono, nessuna con un Gruppo solo; «⏳ era in IDLE»).
// 2026-10-29.3 (giro 23, motore 2026-10-29.7, motore_core 29.3, controller 29.2,
//    logica_aro 29.2): Y, il secondo allarme dopo l IDLE contro un Marker
//    (A-G di MOTORE).
// 2026-10-29.2 (giro 22, motore 2026-10-29.6, catalogo 29.2): i due DIFETTI APERTI
//    chiusi. X1 GIRATA. X2 RISCRITTA: ogni TAG si guarda nella pagina della sua
//    fazione (prima i profili di PanOceania si passavano nudi alla pagina nomade,
//    e senza fazione vale la propria); nuova X2b, M.profiloDiDatabase coi nomi
//    nei due database: campo fazione, roster nemico o proprio, fazione propria.
//  Le novita` del 29 ottobre (MOTORE, allineato con INTERFACCIA): motore
//  2026-10-29.5, motore_core 29.2, ordine_movimento 29.1, catalogo 29.1;
//  app.html, logica_aro, roster_manager, calcolatore_controller 29.1. Giro 21.
//   X1 M.secondaMetaAmmessa (Long = Ordine intero; due Brevi solo con una BASIC;
//      i trasporti BASIC; l ignota Breve) e la seconda meta` sulla pagina (DIS-07)
//   X2 M.pilotaDelTag (Gator, Szalamandra, Gecko, Anaconda; Tikbalang e
//      Triphammer null)
//   X3 il pilota nasce allo smonto (M.scendiDalTag) e la seconda meta` passa a
//      lui sulla pagina (LOG-05)
//   X4 Holoecho: M.fileSegnalinoHoloecho, M.fotoValida, i segnalini delle
//      repliche (Holoecho holoecho_<n>.png, Decoy '0')
//   X5 HoloMask: imgMaschera o '0', mai la foto vera
//   X6 l allarme: statiAttaccante pubblici, il nome del segnalino per un
//      Marker; DEP-07 lo Zulu Cobra in CAMO non fa scattare il CrazyKoala
//   X7 ARO contro un Marker: il tasto IDLE (id RITARDA)
//   X8 M.installaArchivioSquadre: archivio_squadre/<esercito>, la prima volta
//      locale + cloud uniti, poi comanda il cloud; senza db o Storage, niente
//  L harness creaTavolo e` quello di test_elenchi_e_tabellone.js (INTERFACCIA),
//  copiato da test_novita_28ott.js perche` ogni banco basti a se stesso.
//  USO:  node test_novita_29ott.js
// ============================================================================
const fs=require("fs"),vm=require("vm");const J=JSON.stringify;
function creaTavolo(DIR, opz) {
  opz = opz || {};
  DIR = DIR.replace(/\/?$/, '/');
  const server = {}, dispositivi = [], problemi = [];
  function recapita(da, chiave, valore) {
    if (valore === null) delete server[chiave]; else server[chiave] = valore;
    dispositivi.forEach(d => { if (d !== da) d.riceve(chiave, valore); });
  }
  function avvia(nome, titolo, pagina, ricerca) {
    const memoria = {}, el = {}, ascolti = {}, storage = [];
    const g = { errori: [], avvisi: [], alert_: [] };
    g.console = { log: () => {}, warn: (...a) => g.avvisi.push(a.map(String).join(' ')), error: (...a) => g.errori.push(a.map(x => (x && x.stack) || String(x)).join(' ')) };
    g.window = g; g.globalThis = g;
    const finto = (id) => { if (!el[id]) el[id] = { id, innerHTML: '', innerText: '', style: {}, value: '', checked: false, disabled: false, options: [],
        appendChild() {}, addEventListener() {}, remove() {}, setAttribute() {}, getAttribute() { return null; }, scrollTop: 0, scrollHeight: 0,
        classList: { add() {}, remove() {}, toggle() {} }, cloneNode() { return this; }, parentNode: { replaceChild() {}, insertBefore() {} },
        querySelector() { return null; }, querySelectorAll() { return []; } }; return el[id]; };
    let t = titolo;
    g.document = { get title() { return t; }, set title(v) { t = v; }, documentElement: { setAttribute() {} }, scripts: [], body: finto('body'),
        getElementById: finto, createElement: () => finto('nuovo_' + Math.random()), querySelector: (s) => finto('q:' + s), querySelectorAll: () => [],
        addEventListener() {}, write() {} };
    g.alert = (m) => g.alert_.push(String(m)); g.confirm = () => true; g.prompt = () => 'motivo di prova'; g.scrollTo = () => {};
    g._cicli = []; g.setInterval = (fn) => { g._cicli.push(fn); return g._cicli.length; };
    g.setTimeout = (fn) => { try { fn && fn(); } catch (e) { g.errori.push('setTimeout: ' + e.stack); } return 0; };
    g.addEventListener = (tipo, fn) => { if (tipo === 'storage') storage.push(fn); };
    g.Event = function (tipo) { this.type = tipo; };
    g.dispatchEvent = (ev) => storage.forEach(fn => fn(ev));
    g.history = { pushState() {}, replaceState() {}, back() {} }; g.navigator = {};
    g.location = { search: ricerca || '', replace() {}, href: '', reload() {} };
    g.localStorage = { getItem: k => (k in memoria ? memoria[k] : null), setItem: (k, v) => { memoria[k] = String(v); }, removeItem: k => { delete memoria[k]; } };
    const d = { nome, g, memoria, el: finto, elementi: el };
    d.riceve = (k, v) => {
      if (ascolti[k]) ascolti[k]({ val: () => v });
      else { if (v === null) delete memoria[k]; else memoria[k] = v; storage.forEach(fn => fn({ key: k, newValue: v })); }
    };
    g.firebase = { initializeApp: () => ({}), database: () => ({ ref: (k) => ({
        on: (ev, fn) => { ascolti[k] = fn; }, set: (v) => recapita(d, k, String(v)), update() {}, remove: () => recapita(d, k, null),
        once: () => Promise.resolve({ val: () => (k in server ? server[k] : null) }) }) }) };
    const ctx = vm.createContext(g);
    const h = fs.readFileSync(DIR + pagina, 'utf8');
    [...h.matchAll(/<script(?:\s+src="([^"]+)")?\s*>([\s\S]*?)<\/script>/g)].forEach(m => {
      const s = m[1];
      if (s) { if (/^https?:/.test(s)) return; const f = s.split('?')[0]; g.document.scripts.push({ src: f });
        if (!fs.existsSync(DIR + f)) { problemi.push(nome + ': manca ' + f); return; }
        try { vm.runInContext(fs.readFileSync(DIR + f, 'utf8'), ctx, { filename: f }); } catch (e) { problemi.push(nome + ': ' + f + ': ' + e.message); } }
      else { try { vm.runInContext(m[2], ctx, { filename: pagina + ':inline' }); } catch (e) { problemi.push(nome + ': inline: ' + e.message); } }
    });
    d.giro = () => g._cicli.forEach(fn => fn());
    dispositivi.push(d);
    return d;
  }
  const pagina = opz.pagina || 'app.html';
  const nomadi = avvia('NOMADI', 'NOMADS', pagina, '?fazione=nomadi');
  const pano = avvia('PANOCEANIA', 'PANOCEANIA', pagina, '?fazione=panoceania');
  const hub = avvia('HUB', 'HUB', 'calcolatore_hub.html', '');
  hub.g.hubPronto = true;
  const T = { server, nomadi, pano, hub, problemi };
  T.giro = (n) => { for (let i = 0; i < (n || 3); i++) { hub.giro(); nomadi.giro(); pano.giro(); } };
  // Schiera: i roster partono verso l'Hub dal mittente vero.
  T.schiera = (rN, rP, attiva) => {
    nomadi.g.roster = rN; pano.g.roster = rP;
    [nomadi, pano].forEach(d => { d.g.activeStructures = d.g.activeStructures || []; d.g.activeTerrains = d.g.activeTerrains || []; d.g.schieramentoCompletato = true; });
    nomadi.g.inviaSchieramentoAllHub('NOMADI', { roster: rN, strutture: [], terreni: nomadi.g.activeTerrains });
    pano.g.inviaSchieramentoAllHub('PANOCEANIA', { roster: rP, strutture: [], terreni: pano.g.activeTerrains });
    T.giro();
    if ((attiva || 'NOMADI') !== hub.g.gameState.activeFaction) hub.g.toggleTurn();
    else hub.g.localStorage.setItem(hub.g.MotoreN5.CANALI.HUB_TURNO, JSON.stringify({ attivo: hub.g.gameState.activeFaction }));
    T.giro();
  };
  T.profilo = (d, re) => { const tutti = [].concat(d.g.DB_NOMADI, d.g.DB_PANOCEANIA); const p = tutti.find(u => re.test(u.nome)); if (!p) throw new Error('profilo non trovato: ' + re); return JSON.parse(JSON.stringify(p)); };
  // Il giocatore sceglie l'unita` e apre il menu degli Ordini.
  T.apriMenu = (d, indice) => { const g = d.g; g.currentOrder = {}; g.spearheadUnit = g.roster[indice || 0]; g.selectedCoordinatedUnits = []; g.isCoordinated = false; g.procediAlleAzioni(); return d.el('action-list-container').innerHTML; };
  return T;
}



// ---------------------------------------------------------------------------
const DIR = (process.env.CARTELLA || __dirname).replace(/\/?$/, '/');
let passati = 0, falliti = 0;
function ok(c, d, visto) {
    if (c) { passati++; console.log('  ✓ ' + d); }
    else { falliti++; console.log('  ✗ ' + d + (visto !== undefined ? '  [visto: ' + JSON.stringify(visto) + ']' : '')); }
}
function sezione(titolo, fn) {
    console.log('\n=== ' + titolo + ' ===');
    try { fn(); } catch (e) { falliti++; console.log('  ✗ la sezione e` caduta: ' + e.message + ' ' + ((e.stack || '').split('\n')[1] || '').trim()); }
}
const tx = (h) => String(h).replace(/<(?:[^>"']|"[^"]*"|'[^']*')*>/g, ' ').replace(/\s+/g, ' ').trim();
const tr = (p, a) => Object.assign(JSON.parse(J(p)), { states: {}, deployState: 'NORMAL', state: 'ACTIVE', combatGroup: 1 }, a);
const ris = (T) => T.hub.el('step-resolution').style.display === 'block';
const tab = (T) => tx(T.hub.el('clash-container').innerHTML);
// La busta che parte verso l'Hub: azione, Burst, regole e opzioni (aroAtteso).
const spia = (g) => { const s = { n: 0, op: {}, p: null }; const M = g.MotoreN5, o = M.inviaCalcolo;
    M.inviaCalcolo = function (p, op) { s.n++; s.p = p.map(x => ({ az: x.azione, bd: x.burstDisponibile, b: (x.bersagli || []).map(b => b.burst), reg: x.regole })); s.op = op || {}; return o.apply(this, arguments); }; return s; };
const tavolo = (rN, rP, attiva) => { const T = creaTavolo(DIR); T.schiera(rN(T), rP(T), attiva); return T; };
const P_ = (T, re) => T.profilo(T.nomadi, re);


const premi = (d, id) => { const b = d.el(id); return typeof b.onclick === 'function' ? b.onclick() : undefined; };

// ---------------------------------------------------------------------------
const TRIP = /^Triphammer \(Heavy Shotgun, Heavy Rocket Launcher, Panzerfaust/;
const FUS = (T, id, a) => tr(T.profilo(T.pano, /^Fusilier \(Combi/), Object.assign({ id, alias: id === 'p1' ? 'F1' : id }, a || {}));
const bottoni = (h) => (String(h).match(/<button[^>]*class="bottone-arma[\s\S]*?<\/button>/g) || []);
const diArma = (h, re) => bottoni(h).find(b => re.test(b)) || '';
const classe = (b) => (b.match(/class="([^"]*)"/) || [])[1];
const onclickDi = (b) => (b.match(/onclick="([^"]*)"/) || [])[1] || '';
const passo = (T) => Object.keys(T.nomadi.elementi).filter(k => /^step-/.test(k) && T.nomadi.elementi[k].style.display && T.nomadi.elementi[k].style.display !== 'none');

// ---------------------------------------------------------------------------
// Un motore da solo, senza pagina, in un contesto suo (per R3-R5).
const motoreSolo = (conPagina) => {
    const g = { console: { log() {}, warn() {}, error() {} } }; g.window = g; g.globalThis = g;
    g.document = { title: 'NOMADS', addEventListener() {}, querySelectorAll: () => [], getElementById: () => null };
    g.localStorage = { getItem: () => null, setItem() {}, removeItem() {} }; g.setInterval = () => 0; g.setTimeout = () => 0; g.addEventListener = () => {};
    if (conPagina) { g._chiamate = []; g.aggiungiInfo = (...a) => g._chiamate.push(['aggiungi'].concat(a)); g.azzeraInfo = (s) => g._chiamate.push(['azzera', s]); }
    const c = vm.createContext(g);
    ['catalogo_n5.js', 'database_comune.js', 'motore_regole_n5.js'].forEach(f => vm.runInContext(fs.readFileSync(DIR + f, 'utf8'), c, { filename: f }));
    return g;
};
const titoliOrdine = (d) => Object.keys(d.elementi).map(k => String(d.elementi[k].innerHTML || ''))
    .join(' ').match(/<div class="intestazione-ordine"[^>]*>\s*<b[^>]*>[^<]*<\/b>/g) || [];


sezione('X1. M.secondaMetaAmmessa: Long = Ordine intero, due Brevi solo con una BASIC', () => {
    const { M } = { M: motoreSolo(false).MotoreN5 };
    const am = (a, b) => M.secondaMetaAmmessa(a, b);
    const casi = [['RICARICARE', 'ATTACCO BS', false], ['MOVIMENTO', 'ATTACCO BS', true], ['SCENDI DAL TAG', 'MOVIMENTO', true],
                  ['ATTACCO BS', 'SCOPRIRE', true], ['ATTACCO BS', 'IDLE', true], ['ATTACCO BS', 'ATTACCO CC', false],
                  ['RISALI SULLA MOTO', 'ATTACCO BS', true], ['SCENDI DAL TAG', 'ATTACCO BS', true]];
    const male = casi.filter(([a, b, x]) => am(a, b).ammessa !== x);
    ok(male.length === 0, 'i casi di MOTORE: RICARICARE + ATTACCO BS no, MOVIMENTO + ATTACCO BS si`, SCENDI DAL TAG + MOVIMENTO si`; due Brevi (BS + CC) no; con Scoprire, Idle o un trasporto si`', male);
    const r = am('RICARICARE', 'ATTACCO BS');
    ok(r.ammessa === false && /Due Short Skill/.test(r.motivo) && am('MOVIMENTO', 'ATTACCO BS').motivo === null, '  il no ha il suo motivo («Due Short Skill…»), il si` motivo null', r.motivo);
    const l = [am('FUOCO SPECULATIVO', 'MOVIMENTO'), am('MOVIMENTO', 'ATTACCO INTUITIVO'), am('CAUTO', 'SCOPRIRE')];
    ok(l.every(x => x.ammessa === false && /Long Skill/.test(x.motivo)), 'una Long Skill (Speculativo, Intuitivo, Cauto) e` l Ordine intero, da una parte o dall altra', l.map(x => x.motivo));
    // 🔴 GIRATA IL 29 OTTOBRE (motore 29.6, catalogo 29.2: CLASSI_AZIONE li ha LONG).
    // Era DIFETTO APERTO (giro 21): ATTACCO GUIDATO e REQUEST SPEEDBALL,
    // Ordini Interi (M.COLORI_ORDINE, menu delle azioni), non hanno classe in
    // catalogo CLASSI_AZIONE: M.classeAzione da` null, secondaMetaAmmessa li
    // conta Brevi e li ammette con un MOVIMENTO. Sulla pagina oggi non si vede
    // (in seconda meta` si offrono solo Movimenti e Brevi), ma la regola della
    // funzione («Long = Ordine intero») non tiene. Del catalogo: MOTORE.
    const interi = Object.keys(M.COLORI_ORDINE).filter(k => M.COLORI_ORDINE[k].categoria === 'intero');
    const passano = interi.filter(a => am('MOVIMENTO', a).ammessa || am(a, 'MOVIMENTO').ammessa);
    ok(interi.length >= 14 && passano.length === 0, 'ogni Ordine Intero di M.COLORI_ORDINE (' + interi.length + ') e` Long per secondaMetaAmmessa: nessuno sta con un MOVIMENTO', passano);
    ok(am('XYZ', 'ATTACCO BS').ammessa === false && am('XYZ', 'MOVIMENTO').ammessa === true && am('ATTACCO BS', 'XYZ').ammessa === false,
       'un azione che il catalogo non conosce vale Breve: con ATTACCO BS no, con MOVIMENTO si`');
    ok(am('MOVIMENTO', 'MOVIMENTO').ammessa === true && J(M.AZIONI_TRASPORTO) === J(['SCENDI DALLA MOTO', 'RISALI SULLA MOTO', 'SCENDI DAL TAG', 'RISALI SUL TAG']),
       'CONTROPROVA: due BASIC si`; i trasporti sono i quattro della moto e del TAG');
    // Sulla pagina (DIS-07): dopo RICARICARE la seconda meta` non offre l ATTACCO BS.
    const T = tavolo(T => [tr(P_(T, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' })], T => [FUS(T, 'p1')], 'NOMADI');
    const N = T.nomadi.g;
    const offerte = (act1) => { T.apriMenu(T.nomadi, 0); N.currentOrder.action1 = act1; N.currentOrder.action = act1; N.preparaSecondaMeta(act1);
        return [...String(T.nomadi.el('second-half-buttons-container').innerHTML).matchAll(/selectAction\('([^']+)'/g)].map(m => m[1]); };
    const dopoR = offerte('RICARICARE'), dopoM = offerte('MOVIMENTO');
    ok(dopoR.length > 0 && dopoR.indexOf('ATTACCO BS') < 0 && dopoR.indexOf('MOVIMENTO') >= 0 && dopoR.every(a => M.secondaMetaAmmessa('RICARICARE', a).ammessa),
       'sulla pagina, dopo RICARICARE: niente ATTACCO BS in seconda meta`, il MOVIMENTO si`', dopoR);
    ok(dopoM.indexOf('ATTACCO BS') >= 0, 'CONTROPROVA: dopo MOVIMENTO l ATTACCO BS c e`', dopoM);
});

sezione('X2. M.pilotaDelTag: il pilota «<radice> Pilot» della stessa fazione, o quello dell Escape System', () => {
    const T = tavolo(T => [tr(P_(T, /^Alguacil \(Combi/), { id: 'n1' })], T => [FUS(T, 'p1')], 'NOMADI');
    const g = T.nomadi.g, M = g.MotoreN5;
    const pr = (db, re) => db.find(p => re.test(p.nome));
    const pil = (db, re) => { const t = pr(db, re); const x = t ? M.pilotaDelTag(t) : undefined; return x ? x.nome : x; };
    const NOM = g.DB_NOMADI, PAN = g.DB_PANOCEANIA;
    const v = { gator: pil(NOM, /^Gator \(/), szal: pil(NOM, /^Szalamandra \(/), gecko: pil(NOM, /^Gecko \(/), anac: pil(NOM, /^Anaconda \(/), tik: pil(PAN, /^Tikbalang/), trip: pil(NOM, /^Triphammer \(/) };
    ok(/^Gator Pilot\b/.test(v.gator) && /^Szalamandra Pilot\b/.test(v.szal) && /^Gecko Pilot\b/.test(v.gecko), 'Gator, Szalamandra e Gecko: il profilo «<radice> Pilot»', v);
    const anac = pr(NOM, /^Anaconda \(/);
    ok(anac && anac.espelle && M.pilotaDelTag(anac) && M.pilotaDelTag(anac).id === M.profiloDaId(anac.espelle.pilota).id, 'Anaconda: espelle.pilota (' + v.anac + ')');
    ok(v.tik === null && v.trip === null, 'Tikbalang e Triphammer: null', [v.tik, v.trip]);
    const tutti = [].concat(NOM.map(p => ['N', p]), PAN.map(p => ['P', p])).filter(([f, p]) => String(p.tipo).toUpperCase() === 'TAG');
    // per id: M.profiloDaId restituisce una copia del profilo
    const Mp = T.pano.g.MotoreN5;
    const comeDaLista = (p) => { const u = JSON.parse(J(p)); u.id = 'u_7_' + p.id; delete u.profiloDb; delete u.fazione; return u; };
    const fuori = tutti.filter(([f, p]) => { const x = (f === 'N' ? M : Mp).pilotaDelTag(comeDaLista(p)); return x && !(f === 'N' ? NOM : PAN).some(q => q.id === x.id); }).map(([f, p]) => f + ' ' + p.nome);
    // 🔴 GIRATA IL 29 OTTOBRE (motore 29.6: M.profiloDiDatabase sceglie la fazione
    // della truppa). RISCRITTA: ogni TAG nella pagina della SUA fazione, come lo
    // vede chi lo schiera (da una lista non porta profiloDb ne` fazione). Prima la
    // prova passava i profili di PanOceania alla pagina nomade, dove senza altri
    // indizi vale la fazione propria (NOMADI).
    // Era DIFETTO APERTO (giro 21): «Anaconda (AP Spitfire)» c e` nei due
    // database (Nomadi anaconda_ap_spitfire_2 col pilota operator_spitfire,
    // PanOceania anaconda_ap_spitfire col pilota operator). Una truppa della lista
    // non ha profiloDb (roster_manager non lo scrive): M.profiloDiDatabase la cerca
    // per NOME e trova la nomade, e il TAG di PanOceania fa scendere l Operator
    // (Spitfire) dei Nomadi. Del motore (profiloDiDatabase / pilotaDelTag): MOTORE.
    ok(tutti.length >= 10 && fuori.length === 0, 'su tutti i ' + tutti.length + ' TAG dei due database, come arrivano dalla lista (senza profiloDb) nella pagina della loro fazione, il pilota e` della stessa fazione', fuori);
    const panAna = PAN.find(p => p.id === 'anaconda_ap_spitfire');
    const daLista = Object.assign(JSON.parse(J(panAna)), { id: 'u_1_9', alias: 'Ana' });
    const conDb = Object.assign({}, daLista, { profiloDb: 'anaconda_ap_spitfire' });
    ok((M.pilotaDelTag(conDb) || {}).id === 'operator' && (M.scendiDalTag(conDb, [conDb]).nuova || {}).nome === 'Operator',
       'CONTROPROVA: con profiloDb l Anaconda di PanOceania ha il suo Operator (operator), anche allo smonto', [(M.pilotaDelTag(conDb) || {}).id, (M.pilotaDelTag(daLista) || {}).id]);
    ok(M.pilotaDelTag(pr(NOM, /^Alguacil \(Combi/)) === null, 'CONTROPROVA: chi non e` un TAG non ha pilota');
});

sezione('X3. Il pilota del TAG nasce allo smonto, e la seconda meta` passa a lui (LOG-05, LOG-08)', () => {
    const T = tavolo(T => [tr(P_(T, /^Gator \(/), { id: 'n1', alias: 'Gator' })], T => [FUS(T, 'p1')], 'NOMADI');
    const N = T.nomadi.g, M = N.MotoreN5;
    ok(N.roster.length === 1 && !N.roster.some(u => /Pilot/.test(u.nome)), 'in partita c e` solo il Gator: il pilota non si schiera');
    T.apriMenu(T.nomadi, 0);
    ok(/selectAction\('SCENDI DAL TAG'/.test(T.nomadi.el('action-list-container').innerHTML), 'il menu del Gator offre SCENDI DAL TAG (senza pilota di lista a bordo)');
    N.selectAction('SCENDI DAL TAG', false); T.giro();
    const pil = N.roster.find(u => u.id === 'n1_pilota'), tag = N.roster.find(u => u.id === 'n1');
    ok(!!pil && /^Gator Pilot\b/.test(pil.nome) && pil.tagDi === 'n1' && pil.proprietario === 'n1' && pil.deployState === 'NORMAL', 'allo smonto nasce n1_pilota, «Gator Pilot…», tagDi e proprietario il TAG', pil && [pil.nome, pil.tagDi, pil.deployState]);
    ok(tag.states.tagVuoto === true && tag.pilotaUscito === 'n1_pilota' && tag.pilotaScesoAPiedi === true, 'il TAG resta vuoto (tagVuoto, pilotaUscito, pilotaScesoAPiedi)', [tag.states, tag.pilotaUscito]);
    const sec = [...String(T.nomadi.el('second-half-buttons-container').innerHTML).matchAll(/selectAction\('([^']+)'/g)].map(m => m[1]);
    ok(N.currentOrder.unit && N.currentOrder.unit.id === 'n1_pilota' && sec.length > 3 && sec.indexOf('RISALI SUL TAG') >= 0 && sec.indexOf('SCENDI DAL TAG') < 0,
       'la seconda meta` la dichiara il pilota: le sue voci, con RISALI SUL TAG (la schermata non e` piu` vuota)', { unita: N.currentOrder.unit && N.currentOrder.unit.id, sec });
    const e = M.scendiDalTag(tag, N.roster);
    ok(e.possibile === false && /gia` uscito/.test(e.motivo), 'CONTROPROVA: dal TAG vuoto non si scende una seconda volta', e.motivo);
    // LOG-08: la riga del pilota sotto il Gator, nella lista di Army, non diventa una truppa.
    const T2 = creaTavolo(DIR); const N2 = T2.nomadi.g; N2.roster = [];
    T2.nomadi.el('army-import-text').value = ['GROUP 1',
        ' GATOR MULTI Heavy Machine Gun, Chain Rifle(+1B), Mine Dispenser (AP) / ECM (Guided -6), ECM (Hacking -3), E/M CC Weapon(PS=5). (1.5 | 73)',
        '  GATOR PILOT Boarding Shotgun, D-Charges / Kobra Pistol, PARA CC Weapon(-6). (0 | 11)',
        ' ALGUACIL Combi Rifle / Pistol, CC Weapon. (0 | 10)'].join('\n');
    N2.importaDaTesto();
    ok(J(N2.roster.map(u => u.name)) === J(['Gator (TAG)', 'Alguacil (Combi Rifle)']), 'importata la lista: il «GATOR PILOT» rientrato sotto il Gator e` del Gator, non una truppa (Gator e Alguacil)', N2.roster.map(u => u.name));
});

sezione('X4. Holoecho: i segnalini numerati, M.fotoValida, le repliche', () => {
    const M = motoreSolo(false).MotoreN5;
    ok(J([1, 2, 3].map(n => M.fileSegnalinoHoloecho(n))) === J(['holoecho_1.png', 'holoecho_2.png', 'holoecho_3.png']), 'M.fileSegnalinoHoloecho(1..3): holoecho_1.png, _2, _3');
    ok([0, 4, -1, undefined, 'x'].every(n => M.fileSegnalinoHoloecho(n) === null) && M.fileSegnalinoHoloecho('2') === 'holoecho_2.png', 'fuori da 1..3 (0, 4, -1, niente) null; «2» come 2');
    ok(M.fotoValida('holoecho_1.png') && M.fotoValida('a.JPG') && M.fotoValida('b.jpeg') && M.fotoValida('c.webp') && !M.fotoValida('0') && !M.fotoValida('') && !M.fotoValida(null) && !M.fotoValida(3) && !M.fotoValida('png'),
       'M.fotoValida: un nome d immagine (png, jpg, jpeg, webp) si`; «0», vuoto, null, numeri no');
    const T = creaTavolo(DIR); const N = T.nomadi.g;
    const bashi = tr(P_(T, /^Bashi Bazouk \(BS Attack \(AP\)\)/), { id: 'u_1_1', alias: 'Bashi', imgVariant: 'bashi_vero.png' });
    T.schiera([bashi], [FUS(T, 'p1')], 'NOMADI');
    N.creaRepliche(0, 'HOLOECHO');
    const rep = N.roster.filter(u => u.replica);
    ok(rep.length === 2 && rep.every(u => u.imgVariant === 'holoecho_' + u.numeroReplica + '.png' && !u.toccoFoto), 'Holoecho: le due repliche hanno il segnalino holoecho_<n>.png, senza toccoFoto', rep.map(u => [u.numeroReplica, u.imgVariant, u.toccoFoto]));
    N.inviaSchieramentoAllHub('NOMADI', { roster: N.roster, strutture: [], terreni: [] }); T.giro();
    const pub = T.pano.g.MotoreN5.rosterNemico();
    ok(pub.length === 3 && pub.every(u => u.imgVariant === 'holoecho_' + u.numeroReplica + '.png') && !pub.some(u => u.imgVariant === 'bashi_vero.png'), 'all avversario tutte e tre col loro segnalino: la foto vera della vera non parte', pub.map(u => u.imgVariant));
    const T2 = creaTavolo(DIR); const N2 = T2.nomadi.g;
    const b2 = tr(P_(T2, /^Knauf \(Surprise Attack/), { id: 'u_2_1', alias: 'Knauf', imgVariant: 'knauf_vero.png' });
    T2.schiera([b2], [FUS(T2, 'p1')], 'NOMADI');
    N2.creaRepliche(0, 'DECOY');
    const r2 = N2.roster.filter(u => u.replica);
    ok(r2.length >= 1 && r2.every(u => u.imgVariant === '0'), 'Decoy (Knauf, Decoy 1): la replica senza foto, imgVariant «0» (la foto della vera non si copia)', r2.map(u => u.imgVariant));
});

sezione('X5. HoloMask: all avversario la foto della maschera o «0», mai la foto vera', () => {
    const T = creaTavolo(DIR); const N = T.nomadi.g, M = N.MotoreN5;
    const base = tr(P_(T, /^Bashi Bazouk \(BS Attack \(AP\)\)/), { id: 'u_3_1', alias: 'Bashi', imgVariant: 'bashi_vero.png' });
    const imitabile = M.profiliImitabili(base)[0];
    const con = Object.assign({}, base, { holomaskImita: imitabile && imitabile.id, imgMaschera: 'maschera.png', states: { holomask: true } });
    const senza = Object.assign({}, con, { imgMaschera: undefined });
    const fp1 = M.filtraPerAvversario(con), fp2 = M.filtraPerAvversario(senza);
    ok(!!imitabile && fp1.imgVariant === 'maschera.png' && fp2.imgVariant === '0', 'filtraPerAvversario: imgMaschera se c e`, altrimenti «0»', [fp1.imgVariant, fp2.imgVariant]);
    ok(M.mostraComeHolomask(con).imgVariant === 'maschera.png' && M.mostraComeHolomask(senza).imgVariant === '0' && M.mostraComeHolomask(Object.assign({}, con, { imgMaschera: '0' })).imgVariant === '0',
       'M.mostraComeHolomask: la stessa foto (una non valida, «0», resta «0»)');
    ok(fp1.imgVariant !== 'bashi_vero.png' && fp2.imgVariant !== 'bashi_vero.png' && M.filtraPerAvversario(base).imgVariant !== '0',
       'la foto vera (bashi_vero.png) non parte mai in HoloMask; CONTROPROVA: senza HoloMask la vista non e` forzata a «0»', M.filtraPerAvversario(base).imgVariant);
});

sezione('X6. L allarme: gli stati pubblici di chi agisce, il nome del segnalino; DEP-07 il koala non scatta', () => {
    const mk = (attivo) => {
        const T = creaTavolo(DIR); const N = T.nomadi.g, P = T.pano.g, M = N.MotoreN5;
        const zero = tr(P_(T, /^Zero \(E\/M Mine/), { id: 'n9', alias: 'Zero' });
        const koala = M.creaDeployable(zero, M.profiloArma('CrazyKoalas'), { ordineId: 'schieramento_1', viaEsito: false }).token; koala.id = 'koala1';
        T.schiera([zero, koala], [attivo(T)], 'PANOCEANIA');
        T.apriMenu(T.pano, 0); P.selectAction('MOVIMENTO', false); T.giro(); N.apriSelezioneAro();
        return { T, N, cad: N.currentAttackData || {}, inn: (N.deployableInnescabili || []).map(x => x.unita.id), lista: String(T.nomadi.el('aro-selection-list').innerHTML),
                 voci: (N.vociInfo('step-aro-selection') || []).map(v => v.titolo + ' / ' + v.testo) };
    };
    const a = mk(T => tr(T.profilo(T.pano, /^Zulu-Cobra/), { id: 'p10', alias: 'Zulu', deployState: 'CAMO', states: { camo: true } }));
    ok(/^SEGNALINO MIMETICO/.test(a.cad.attaccante) && J(a.cad.attaccanti) === J([a.cad.attaccante]) && !/Zulu/.test(J(a.cad)),
       'Zulu-Cobra in CAMO muove: l allarme dice il segnalino («' + a.cad.attaccante + '»), non il nome vero', [a.cad.attaccante, a.cad.attaccanti]);
    ok(a.cad.statiAttaccante && a.cad.statiAttaccante.camo === true, '  e statiAttaccante porta gli stati pubblici (camo)', a.cad.statiAttaccante);
    ok(a.inn.indexOf('koala1') < 0 && !/aro-dep-koala1/.test(a.lista) && a.voci.some(v => /^CrazyKoala #1 non può reagire \/ Non scatta contro Marker Mimetici/.test(v)),
       'DEP-07 (a): il koala non scatta, e la ⓘ dice «CrazyKoala #1 non può reagire / Non scatta contro Marker Mimetici o Impersonation…»', { inn: a.inn, voci: a.voci });
    const b = mk(T => FUS(T, 'p1', { alias: 'Fante' }));
    ok(b.cad.attaccante === 'Fante' && J(b.cad.statiAttaccante) === '{}' && b.inn.indexOf('koala1') >= 0 && /aro-dep-koala1/.test(b.lista),
       'CONTROPROVA: il Fusilier a faccia in su si chiama col suo nome, stati vuoti, e il koala e` innescabile', [b.cad.attaccante, b.cad.statiAttaccante, b.inn]);
});

sezione('X7. ARO contro un Marker: il tasto IDLE (id RITARDA)', () => {
    const T = creaTavolo(DIR); const N = T.nomadi.g, P = T.pano.g, M = N.MotoreN5;
    const alg = tr(P_(T, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' });
    const zulu = tr(T.profilo(T.pano, /^Zulu-Cobra/), { id: 'p10', alias: 'Zulu', deployState: 'CAMO', states: { camo: true } });
    T.schiera([alg], [zulu], 'PANOCEANIA');
    T.apriMenu(T.pano, 0); P.selectAction('MOVIMENTO', false); T.giro(); N.apriSelezioneAro(); N.toggleAroUnit('n1'); N.confermaSelezioneAro();
    const az = [...String(T.nomadi.el('aro-action-list').innerHTML).matchAll(/<button[^>]*onclick="window\.selezionaAzioneAro\('([^']+)'\)"[^>]*>([\s\S]*?)<\/button>/g)].map(m => [m[1], tx(m[2]).trim()]);
    ok(J(az) === J([['DODGE', 'SCHIVATA'], ['RESET', 'RESET'], ['SCOPRIRE', 'SCOPRIRE'], ['LOOK_OUT', 'LOOK OUT!'], ['RITARDA', 'IDLE']]), 'sulla pagina, contro il Marker: SCHIVATA, RESET, SCOPRIRE, LOOK OUT! e IDLE, che resta selezionaAzioneAro(\'RITARDA\')', az);
    const v = M.azioniAroPossibili(alg, 'MOVIMENTO', { attivo: zulu }).find(x => x.id === 'RITARDA');
    ok(v && v.nome === 'Idle' && v.ammesso && /se resta Marker, l'ARO e` perso/.test(v.note.join(' ')), 'nel motore la voce RITARDA si chiama «Idle», con la nota (se resta Marker l ARO e` perso)', v);
    ok(!M.azioniAroPossibili(alg, 'MOVIMENTO', { attivo: FUS(T, 'p1') }).some(x => x.id === 'RITARDA'), 'CONTROPROVA: contro un Modello IDLE non c e`');
});

sezione('X8. M.installaArchivioSquadre: le squadre salvate su Firebase, archivio_squadre/<esercito>', () => {
    const finto = () => { const ref = {}, scritti = [];
        return { scritti, ref, db: { ref: (k) => ({ on: (ev, fn) => { ref[k] = fn; }, set: (v) => scritti.push([k, v]) }) } }; };
    const pagina = (ls0) => { const g = motoreSolo(false); const mem = Object.assign({}, ls0);
        g.localStorage = { getItem: k => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: k => { delete mem[k]; } };
        return { g, M: g.MotoreN5, mem }; };
    const p = pagina({ infinityRosters_Nomads: J({ Locale: [1], Uguale: ['loc'] }) });
    const f = finto();
    const r = p.M.installaArchivioSquadre(f.db);
    ok(J(r.chiavi) === J(['infinityRosters_Nomads', 'infinityRosters_Panoceania']) && J(p.M.ARCHIVIO_SQUADRE) === J({ infinityRosters_Nomads: 'archivio_squadre/nomads', infinityRosters_Panoceania: 'archivio_squadre/panoceania' }),
       'le due chiavi locali, su archivio_squadre/nomads e archivio_squadre/panoceania', r);
    f.ref['archivio_squadre/nomads']({ val: () => J({ Cloud: [2], Uguale: ['cloud'] }) });
    const unite = JSON.parse(p.mem.infinityRosters_Nomads);
    ok(J(Object.keys(unite).sort()) === J(['Cloud', 'Locale', 'Uguale']) && unite.Uguale[0] === 'loc' && p.mem.archivio_unito_infinityRosters_Nomads === '1', 'la prima volta: locale e cloud uniti, a parita` di nome vince la locale', unite);
    ok(f.scritti.length === 1 && f.scritti[0][0] === 'archivio_squadre/nomads' && J(JSON.parse(f.scritti[0][1])) === J(unite), '  e l unione torna sul cloud', f.scritti);
    f.ref['archivio_squadre/nomads']({ val: () => J({ Cloud: [2] }) });
    ok(J(JSON.parse(p.mem.infinityRosters_Nomads)) === J({ Cloud: [2] }), 'poi comanda il cloud: una squadra tolta altrove non torna', p.mem.infinityRosters_Nomads);
    p.g.localStorage.setItem('infinityRosters_Nomads', J({ Nuova: [3] })); p.g.localStorage.setItem('altra_chiave', 'x');
    ok(f.scritti.length === 2 && f.scritti[1][0] === 'archivio_squadre/nomads' && f.scritti[1][1] === J({ Nuova: [3] }), 'salvare una squadra scrive anche sul cloud; un altra chiave no', f.scritti.map(x => x[0]));
    const q = pagina({});
    ok(J(q.M.installaArchivioSquadre(null)) === J({ chiavi: [] }) && typeof Storage === 'undefined', 'CONTROPROVA: senza db niente; in Node (Storage assente) la funzione non cade');
});

sezione('X2b. M.profiloDiDatabase con lo stesso nome nei due database: la fazione della truppa (motore 29.6)', () => {
    const T = tavolo(T => [tr(P_(T, /^Alguacil \(Combi/), { id: 'n1' })], T => [FUS(T, 'p1')], 'NOMADI');
    const MN = T.nomadi.g.MotoreN5, MP = T.pano.g.MotoreN5;
    const PAN = T.pano.g.DB_PANOCEANIA, NOM = T.nomadi.g.DB_NOMADI;
    const pana = PAN.find(p => p.id === 'anaconda_ap_spitfire'), noma = NOM.find(p => p.id === 'anaconda_ap_spitfire_2');
    ok(pana && noma && pana.nome === noma.nome, 'premessa: «' + pana.nome + '» e` nei due database (anaconda_ap_spitfire e anaconda_ap_spitfire_2)');
    const nudo = (p, extra) => Object.assign(JSON.parse(J(p)), { id: 'u_9_1', alias: 'Ana' }, extra || {});
    const chi = (M, u) => [(M.profiloDiDatabase(u) || {}).id, (M.pilotaDelTag(u) || {}).id].join(' / ');
    ok(MN.fazionePropria() === 'NOMADI' && MP.fazionePropria() === 'PANOCEANIA', 'premessa: la pagina nomade e` NOMADI, quella di PanOceania PANOCEANIA');
    // 1) il campo fazione
    ok(chi(MN, nudo(pana, { fazione: 'PANOCEANIA' })) === 'anaconda_ap_spitfire / operator' && chi(MP, nudo(noma, { fazione: 'NOMADI' })) === 'anaconda_ap_spitfire_2 / operator_spitfire',
       '1) il campo fazione vince sulla pagina: PANOCEANIA nella pagina nomade → anaconda_ap_spitfire / operator; NOMADI in quella di PanOceania → anaconda_ap_spitfire_2 / operator_spitfire',
       [chi(MN, nudo(pana, { fazione: 'PANOCEANIA' })), chi(MP, nudo(noma, { fazione: 'NOMADI' }))]);
    // 2) il roster: nemico → fazione avversaria, proprio → propria
    const T2 = tavolo(T => [tr(P_(T, /^Alguacil \(Combi/), { id: 'n1' })], T => [Object.assign(JSON.parse(J(pana)), { id: 'p20', alias: 'Ana', states: {}, deployState: 'NORMAL' })], 'NOMADI');
    const N2 = T2.nomadi.g, P2 = T2.pano.g;
    const nemico = N2.MotoreN5.rosterNemico().find(u => u.id === 'p20');
    const copia = Object.assign({}, nemico);
    ok(!!nemico && chi(N2.MotoreN5, nemico) === 'anaconda_ap_spitfire / operator' && chi(N2.MotoreN5, copia) === 'anaconda_ap_spitfire / operator',
       '2) nel roster nemico della pagina nomade (lo stesso oggetto, o stesso id e nome): la fazione avversaria, operator', [nemico && chi(N2.MotoreN5, nemico), chi(N2.MotoreN5, copia)]);
    const mio = P2.roster.find(u => u.id === 'p20');
    ok(chi(P2.MotoreN5, mio) === 'anaconda_ap_spitfire / operator', '   nel roster proprio della pagina di PanOceania: la propria, operator', chi(P2.MotoreN5, mio));
    // 3) senza indizi: la fazione propria
    ok(chi(MN, nudo(pana)) === 'anaconda_ap_spitfire_2 / operator_spitfire' && chi(MP, nudo(noma)) === 'anaconda_ap_spitfire / operator',
       '3) senza campo e fuori dai roster vale la fazione della pagina: nella nomade la nomade, in quella di PanOceania la sua', [chi(MN, nudo(pana)), chi(MP, nudo(noma))]);
    // CONTROPROVA Nomadi
    ok(chi(MN, nudo(noma)) === 'anaconda_ap_spitfire_2 / operator_spitfire' && chi(MN, nudo(noma, { profiloDb: 'anaconda_ap_spitfire' })) === 'anaconda_ap_spitfire / operator',
       'CONTROPROVA: l Anaconda dei Nomadi nella pagina nomade → anaconda_ap_spitfire_2 / operator_spitfire; profiloDb vince su tutto');
    const e = MN.scendiDalTag(Object.assign(nudo(pana), { fazione: 'PANOCEANIA' }), []);
    ok(e.possibile && e.nuova && e.nuova.nome === 'Operator', 'allo smonto, con la fazione di PanOceania, nasce «Operator» (non «Operator (Spitfire)»)', e.nuova && e.nuova.nome);
});

// Il giro del secondo allarme. L attiva (Nomadi) muove, il reattivo (PanOceania)
// risponde (Rea IDLE, Altro SCHIVATA), poi la seconda meta`. Le spie: gli allarmi
// partiti dall attiva (payload e risposta) e le buste di calcolo (M.creaPayload).
const giroIdle = (o) => {
    o = o || {};
    const T = creaTavolo(DIR); const N = T.nomadi.g, P = T.pano.g, H = T.hub.g;
    const att = tr(P_(T, /^Intruder \(HMG/), Object.assign({ id: 'n1', alias: 'Ombra' }, o.modello ? {} : { deployState: 'CAMO', states: { camo: true } }));
    T.schiera([att], [FUS(T, 'p1', { alias: 'Rea' }), FUS(T, 'p2', Object.assign({ alias: 'Altro' }, o.gruppi ? { combatGroup: 2 } : {}))], 'NOMADI');
    const allarmi = [], buste = [];
    const veroAll = N.inviaAllarmeAro;
    N.inviaAllarmeAro = (pl) => { const r = veroAll(pl); allarmi.push({ p: JSON.parse(J(pl || {})), r: r }); return r; };
    const veroCP = N.MotoreN5.creaPayload;
    N.MotoreN5.creaPayload = function () { const r = veroCP.apply(this, arguments); buste.push(JSON.parse(J((r && r.payload) || r || {}))); return r; };
    T.apriMenu(T.nomadi, 0); N.selectAction('MOVIMENTO', false); T.giro();
    const primo = Object.assign({}, P.currentAttackData || {});
    if (o.gruppi) { P.apriSelezioneAro(); o.listaPrimo = String(T.pano.el('aro-selection-list').innerHTML); }
    // Con IDLE: Rea IDLE, Altro SCHIVATA. Senza: reagisce solo Altro, con la Schivata.
    P.apriSelezioneAro(); if (!o.senzaIdle) P.toggleAroUnit('p1'); P.toggleAroUnit('p2'); P.confermaSelezioneAro();
    if (!o.senzaIdle) P.selezionaAzioneAro('RITARDA');
    P.selezionaAzioneAro('DODGE'); P.salvaAroCorrente(); T.giro();
    const seconda = o.seconda || 'ATTACCO BS';
    let ripeti = null, dopoRipeti = null;
    if (seconda === 'ATTACCO BS') {
        N.selectAction('ATTACCO BS', true);
        // il router richiamato sulla stessa seconda meta`, a Ordine aperto
        if (o.ripeti) { ripeti = (typeof N.inviaSecondoAllarmeDopoIdle === 'function') ? N.inviaSecondoAllarmeDopoIdle('ATTACCO BS') : { invia: null, motivo: 'inviaSecondoAllarmeDopoIdle assente' }; N.selectAction('ATTACCO BS', true); dopoRipeti = allarmi.length; }
        N.declareAttackBS('Heavy Machine Gun'); N.toggleTargetSelection('p1'); N.confirmMultiAro(false);
        N.eseguiCalcoloBS();
    } else N.selectAction(seconda, true);
    // La busta PRIMA del secondo allarme: il secondo e` partito (la busta ha
    // aroSecondaMeta), ma l Hub non l ha ancora letto: lo si toglie dalla sua
    // memoria per un giro e lo si rimette (rilascia).
    const K = N.MotoreN5.CANALI.COMUNICAZIONE; let sospeso;
    if (o.bustaPrima) { sospeso = T.hub.memoria[K]; delete T.hub.memoria[K]; }
    return { T, N, P, H, allarmi, buste, primo, ripeti, dopoRipeti, sospeso, listaPrimo: o.listaPrimo, rilascia: () => { if (sospeso !== undefined) T.hub.memoria[K] = sospeso; } };
};

sezione('Y. Il secondo allarme dopo l IDLE contro un Marker (MOTORE 29.7, A-G)', () => {
    // A — Marker CAMO: MOVIMENTO, poi ATTACCO BS
    const a = giroIdle({ ripeti: true });
    a.T.giro();
    const [a1, a2] = a.allarmi.map(x => x.p);
    ok(a.allarmi.length === 2 && a1.controMarker === true && !a1.secondaMeta && /^SEGNALINO MIMETICO/.test(a1.attaccante) && a1.statiAttaccante.camo === true,
       'A: due allarmi; il primo contro un Marker (controMarker, il nome del segnalino, camo)', a.allarmi.map(x => [x.p.attaccante, x.p.controMarker, x.p.secondaMeta]));
    ok(a2 && a2.secondaMeta === true && a2.soloIdle === true && a2.ordineId === a1.ordineId && a2.controMarker === false && !(a2.statiAttaccante || {}).camo && a2.attaccante === 'Ombra' && a2.azioneSecondaMeta === 'ATTACCO BS' && /il Marker si è rivelato/.test(a2.nota) && a2.nota.indexOf('`') < 0,
       'A: il secondo con secondaMeta e soloIdle, lo stesso ordineId, controMarker false, senza camo, col nome vero («Ombra»), azioneSecondaMeta e la nota con gli accenti («Seconda metà… si è rivelato», nessun apice)', a2 && { sm: a2.secondaMeta, si: a2.soloIdle, cm: a2.controMarker, st: a2.statiAttaccante, att: a2.attaccante });
    const bA = a.buste[a.buste.length - 1] || {};
    ok(bA.aroAtteso === true && bA.aroSecondaMeta === true, 'A: la busta di calcolo ha aroAtteso e aroSecondaMeta', [bA.aroAtteso, bA.aroSecondaMeta]);
    ok(a.dopoRipeti === 2 && a.allarmi.length === 2 && a.ripeti.invia === false && /gia` partito/.test(a.ripeti.motivo), 'A: il router richiamato sulla stessa seconda meta` non lo ripete («' + a.ripeti.motivo + '»)', [a.dopoRipeti, a.allarmi.length]);
    // G (con IDLE): al reattivo solo la truppa in IDLE
    a.P.apriSelezioneAro();
    const listaA = String(a.T.pano.el('aro-selection-list').innerHTML);
    ok(J(a.P.idleDellOrdine(a2.ordineId).map(u => u.id)) === '["p1"]' && listaA.indexOf('id="aro-btn-p1"') >= 0 && listaA.indexOf('id="aro-btn-p2"') < 0 && /IL MARKER SI È RIVELATO/.test(a.T.pano.el('aro-alert-text').innerHTML),
       'G: al secondo allarme «IL MARKER SI È RIVELATO», e in elenco solo Rea (in IDLE)', a.P.idleDellOrdine(a2.ordineId).map(u => u.id));
    // F (in ordine): l Hub aspetta, poi unisce
    ok(!ris(a.T) && a.H.attesaSecondaMeta === String(a2.ordineId) && J((a.H.reazioniPrimaMeta || []).map(r => r.id)) === '["p2"]', 'F: l Hub non calcola, tiene la prima risposta (Altro) e aspetta la seconda');
    a.P.toggleAroUnit('p1'); a.P.confermaSelezioneAro(); a.P.selezionaAzioneAro('DODGE'); a.P.salvaAroCorrente(); a.T.giro();
    ok(ris(a.T) && J((a.H.latestAroData || []).map(r => r.id + ':' + r.azione)) === J(['p2:DODGE', 'p1:DODGE']) && a.H.attesaSecondaMeta === null && a.H.reazioniPrimaMeta === null,
       'F: arrivata la seconda risposta l Hub calcola con le due, prima quella della prima risposta', (a.H.latestAroData || []).map(r => r.id));
    // F (la busta prima del secondo allarme)
    const f = giroIdle({ bustaPrima: true });
    f.T.giro(); f.T.giro();
    const bF = f.buste[f.buste.length - 1] || {};
    ok(f.sospeso !== undefined && /"secondaMeta":true/.test(String(f.sospeso)) && bF.aroSecondaMeta === true && !ris(f.T) && f.H.secondoAllarmeVisto !== String(f.primo.ordineId),
       'F: con la busta (aroSecondaMeta) arrivata PRIMA del secondo allarme l Hub non calcola', { aroSecondaMeta: bF.aroSecondaMeta, ris: ris(f.T) });
    f.rilascia(); f.T.giro();
    ok(!ris(f.T) && f.H.attesaSecondaMeta != null, '  arrivato il secondo allarme, aspetta ancora la seconda risposta');
    f.P.apriSelezioneAro(); f.P.toggleAroUnit('p1'); f.P.confermaSelezioneAro(); f.P.selezionaAzioneAro('DODGE'); f.P.salvaAroCorrente(); f.T.giro();
    ok(ris(f.T) && J((f.H.latestAroData || []).map(r => r.id)) === J(['p2', 'p1']), '  e con la seconda risposta calcola con tutte e due', (f.H.latestAroData || []).map(r => r.id));
    // G (senza IDLE): risposta vuota subito
    const g = giroIdle({ senzaIdle: true }); g.T.giro(); g.T.giro();
    // (dopo il calcolo l Hub azzera le reazioni: le si legge sul tabellone)
    ok(ris(g.T) && g.T.pano.el('aro-alert-banner').style.display !== 'block' && (g.P.currentAttackData || {}).secondaMeta === true && /Altro Azione: (SCHIVATA|DODGE)/.test(tab(g.T)) && g.H.attesaSecondaMeta === null,
       'G: senza truppe in IDLE il reattivo risponde [] da solo, senza avviso, e l Hub calcola con la reazione della prima risposta (la Schivata di Altro sul tabellone)', tab(g.T).slice(0, 200));
    // B — Marker CAMO: MOVIMENTO, poi MOVIMENTO
    const b = giroIdle({ seconda: 'MOVIMENTO' }); b.T.giro();
    const bB = b.buste[b.buste.length - 1] || {};
    ok(b.allarmi.length === 1 && b.buste.length >= 1 && bB.aroAtteso === true && !bB.aroSecondaMeta, 'B: MOVIMENTO poi MOVIMENTO (resta Marker): un allarme, busta senza aroSecondaMeta', [b.allarmi.length, bB.aroAtteso, bB.aroSecondaMeta]);
    // C — Modello: MOVIMENTO, poi ATTACCO BS
    const c = giroIdle({ modello: true, senzaIdle: true }); c.T.giro();
    ok(c.allarmi.length === 1 && c.allarmi[0].p.controMarker === false && c.allarmi[0].p.attaccante === 'Ombra' && !(c.buste[c.buste.length - 1] || {}).aroSecondaMeta,
       'C: un Modello: un allarme, controMarker false, nessun aroSecondaMeta', c.allarmi.map(x => [x.p.attaccante, x.p.controMarker]));
    // D — inviaAllarmeAro con secondaMeta senza primo contro un Marker
    const T = creaTavolo(DIR); const N = T.nomadi.g;
    const d = N.inviaAllarmeAro({ ordineId: 'ord_x', secondaMeta: true, attaccante: 'X' });
    ok(d && d.inviato === false && d.ripetuto === false, 'D: inviaAllarmeAro({ ordineId, secondaMeta: true }) senza primo allarme contro un Marker: inviato false', d);
    // E — i quattro no di M.secondoAllarmeDopoIdle
    const M = N.MotoreN5;
    const marker = tr(P_(T, /^Intruder \(HMG/), { id: 'n1', alias: 'Ombra', deployState: 'CAMO', states: { camo: true } });
    const modello = tr(P_(T, /^Intruder \(HMG/), { id: 'n1', alias: 'Ombra' });
    const base = { ordineId: 'o1', allarmeControMarker: 'o1', secondoGiaInviato: null, isSecondHalf: true, unita: modello, azionePrima: 'MOVIMENTO', azioneSeconda: 'ATTACCO BS' };
    const e = (x) => M.secondoAllarmeDopoIdle(Object.assign({}, base, x));
    if (typeof M.secondoAllarmeDopoIdle !== 'function') throw new Error('M.secondoAllarmeDopoIdle assente');
    const no = [e({ isSecondHalf: false }), e({ allarmeControMarker: 'o0' }), e({ secondoGiaInviato: 'o1' }), e({ unita: marker })];
    ok(no.every(x => x.invia === false && x.payload === null) && /Non e` la seconda meta`/.test(no[0].motivo) && /non era contro un Marker/.test(no[1].motivo) && /gia` partito/.test(no[2].motivo) && /non ha rivelato il Marker/.test(no[3].motivo),
       'E: i quattro no col loro motivo (non seconda meta`, primo non contro Marker, gia` inviato, resta Marker)', no.map(x => x.motivo));
    const si = e({});
    ok(si.invia === true && si.payload.secondaMeta && si.payload.soloIdle && si.payload.ordineId === 'o1' && si.payload.azioneSecondaMeta === 'ATTACCO BS', 'E, CONTROPROVA: col Marker rivelato invia, col payload della consegna', si.motivo);
});

// «GRUPPO n» col numero in uno <span>: si legge sul testo della pagina.
const intestazioniGruppo = (h) => [...tx(String(h)).replace(/\s+/g, ' ').matchAll(/GRUPPO (\d+) \((\d+)\)/g)].map(m => m[0]);

sezione('Y2. Gli accenti negli avvisi, le intestazioni dei Gruppi in ARO (MOTORE 29.8, logica_aro 30.1)', () => {
    // Gli avvisi di SCENDI DAL TAG e RICARICARE
    const T = tavolo(T => [tr(P_(T, /^Gator \(/), { id: 'n1', alias: 'Gator' })], T => [FUS(T, 'p1')], 'NOMADI'); const N = T.nomadi.g;
    T.apriMenu(T.nomadi, 0); N.selectAction('SCENDI DAL TAG', false); T.giro();
    const scendi = N.alert_.join(' ');
    ok(/metà Ordine di Movimento/.test(scendi) && /né ARO finché/.test(scendi) && scendi.indexOf('`') < 0, 'SCENDI DAL TAG: l avviso con gli accenti («metà», «né», «finché»), nessun apice', scendi.slice(0, 160));
    const T2 = tavolo(T => [tr(P_(T, TRIP), { id: 'n30', alias: 'Tri', usiSpesi: { PANZERFAUST: 2 } }), tr(P_(T, /^Salyut \(Deactivator/), { id: 'n43', alias: 'Sal' })], T => [FUS(T, 'p1')], 'NOMADI'); const N2 = T2.nomadi.g;
    T2.apriMenu(T2.nomadi, 0); N2.confirm = () => true; N2.applicaRicarica();
    const ric = N2.alert_.join(' ');
    ok(/^✅ Tri ricarica: Panzerfaust \(\+2\)/.test(ric) && /già piazzati/.test(ric) && ric.indexOf('`') < 0, 'RICARICARE: «✅ Tri ricarica: Panzerfaust (+2)» e «già piazzati», nessun apice', ric.slice(0, 120));
    // 🔴 GIRATA IL 30 OTTOBRE (ordine_movimento 30.1 e motore_core 30.1: alert
    // passa da M.accenti). Era DIFETTO APERTO (giro 24): l avviso del no di SCENDI DAL TAG
    // (ordine_movimento riga 94, alert('⛔ ' + e.motivo), e lo stesso a riga 137)
    // non passa da M.accenti: i motivi del motore con l apice arrivano cosi`
    // a schermo («Il pilota e` gia` uscito.», «Il TAG e` distrutto…»). Di MOTORE.
    N.alert_.length = 0; N.currentOrder.unit = N.roster[0]; N.applicaTrasporto('SCENDI DAL TAG');
    const no = N.alert_.join(' ');
    ok(/^⛔ Il pilota è già uscito\.$/.test(no) && no.indexOf('`') < 0, 'SCENDI DAL TAG dal TAG vuoto: l avviso con gli accenti («⛔ Il pilota è già uscito.»), nessun apice', no);
    // Le intestazioni dei Gruppi: due Gruppi al primo allarme, nessuna al secondo
    const a = giroIdle({ gruppi: true }); a.T.giro();
    ok(J(intestazioniGruppo(a.listaPrimo)) === J(['GRUPPO 1 (1)', 'GRUPPO 2 (1)']), 'primo allarme, Rea nel Gruppo 1 e Altro nel 2: «GRUPPO 1 (1)» e «GRUPPO 2 (1)», contano le righe che compaiono', intestazioniGruppo(a.listaPrimo));
    a.P.apriSelezioneAro();
    const l2 = String(a.T.pano.el('aro-selection-list').innerHTML);
    ok(intestazioniGruppo(l2).length === 0 && /id="aro-btn-p1"/.test(l2) && /⏳ era in IDLE/.test(l2) && !/aveva ritardato/.test(l2), 'secondo allarme: solo Rea, nessuna intestazione di Gruppo, e la riga dice «⏳ era in IDLE»', { int: intestazioniGruppo(l2), idle: /era in IDLE/.test(l2) });
    // un Gruppo solo: nessuna intestazione
    const T3 = creaTavolo(DIR); const N3 = T3.nomadi.g, P3 = T3.pano.g;
    T3.schiera([tr(P_(T3, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' })],
               [FUS(T3, 'p1', { alias: 'Uno' }), FUS(T3, 'p2', { alias: 'Due' }), FUS(T3, 'p3', { alias: 'Steso', states: { unconscious: true } }), FUS(T3, 'p4', { alias: 'Quattro', combatGroup: 2 })], 'NOMADI');
    T3.apriMenu(T3.nomadi, 0); N3.selectAction('ATTACCO BS', false); N3.startUnitAllocationLoopBS();
    N3.declareAttackBS((String(T3.nomadi.el('weapon-buttons-container').innerHTML).match(/declareAttackBS\('(Combi Rifle[^']*)'\)/) || [])[1]);
    N3.toggleTargetSelection('p1'); N3.confirmMultiAro(false); T3.giro(); P3.apriSelezioneAro();
    const l3 = String(T3.pano.el('aro-selection-list').innerHTML);
    ok(J(intestazioniGruppo(l3)) === J(['GRUPPO 1 (2)', 'GRUPPO 2 (1)']) && !/id="aro-btn-p3"/.test(l3), 'due Gruppi con un Incosciente nel primo: «GRUPPO 1 (2)» (lo Steso fuori dal conto) e «GRUPPO 2 (1)»', intestazioniGruppo(l3));
    const T4 = creaTavolo(DIR); const N4 = T4.nomadi.g, P4 = T4.pano.g;
    T4.schiera([tr(P_(T4, /^Alguacil \(Combi/), { id: 'n1', alias: 'Alg' })], [FUS(T4, 'p1', { alias: 'Uno' }), FUS(T4, 'p2', { alias: 'Due' })], 'NOMADI');
    T4.apriMenu(T4.nomadi, 0); N4.selectAction('ATTACCO BS', false); N4.startUnitAllocationLoopBS();
    N4.declareAttackBS((String(T4.nomadi.el('weapon-buttons-container').innerHTML).match(/declareAttackBS\('(Combi Rifle[^']*)'\)/) || [])[1]);
    N4.toggleTargetSelection('p1'); N4.confirmMultiAro(false); T4.giro(); P4.apriSelezioneAro();
    const l4 = String(T4.pano.el('aro-selection-list').innerHTML);
    ok(intestazioniGruppo(l4).length === 0 && /id="aro-btn-p1"/.test(l4) && /id="aro-btn-p2"/.test(l4), 'CONTROPROVA: le truppe in elenco tutte del Gruppo 1: nessuna intestazione', intestazioniGruppo(l4));
});

sezione('Y3. Tutti gli avvisi della pagina con le lettere accentate (motore_core 30.1)', () => {
    const T = tavolo(T => [tr(P_(T, /^Gator \(/), { id: 'n1', alias: 'Gator' })], T => [FUS(T, 'p1')], 'NOMADI'); const N = T.nomadi.g;
    ok(N.alert.__conAccenti === true && N.confirm.__conAccenti === true, 'sulla pagina window.alert e window.confirm sono l involucro di motore_core (__conAccenti)');
    N.alert_.length = 0; N.alert('Il pilota e` gia` uscito.');
    ok(J(N.alert_) === J(['Il pilota è già uscito.']), 'alert(«Il pilota e` gia` uscito.») → «Il pilota è già uscito.»', N.alert_);
    // Un modulo che passa e.motivo del motore senza M.accenti: l involucro basta.
    N.alert_.length = 0; N.alert('⛔ ' + N.MotoreN5.scendiDalTag(Object.assign({}, N.roster[0], { states: { tagVuoto: true } }), []).motivo);
    ok(N.alert_.length === 1 && N.alert_[0].indexOf('`') < 0 && /già uscito/.test(N.alert_[0]), 'il motivo del motore, scritto con l apice, arriva a schermo accentato', N.alert_);
    // RISALI SUL TAG col TAG distrutto
    T.apriMenu(T.nomadi, 0); N.selectAction('SCENDI DAL TAG', false); T.giro();
    const tag = N.roster.find(u => u.id === 'n1'), pil = N.roster.find(u => u.id === 'n1_pilota');
    tag.state = 'DEAD'; tag.states = Object.assign({}, tag.states, { dead: true });
    N.alert_.length = 0; N.currentOrder = { unit: pil }; N.applicaTrasporto('RISALI SUL TAG');
    ok(N.alert_.length === 1 && /^⛔ /.test(N.alert_[0]) && N.alert_[0].indexOf('`') < 0, 'RISALI SUL TAG sul TAG distrutto: il no senza apici («' + (N.alert_[0] || '') + '»)', N.alert_);
    // RICARICARE: la domanda (confirm) e il no
    const T2 = tavolo(T => [tr(P_(T, TRIP), { id: 'n30', alias: 'Tri', usiSpesi: { PANZERFAUST: 2 } }), tr(P_(T, /^Salyut \(Deactivator/), { id: 'n43', alias: 'Sal' })], T => [FUS(T, 'p1')], 'NOMADI'); const N2 = T2.nomadi.g;
    const chieste = []; const vero = N2.confirm; N2.confirm = (m) => { chieste.push(String(m)); return true; };
    T2.apriMenu(T2.nomadi, 0); N2.applicaRicarica(); N2.confirm = vero;
    ok(chieste.length === 1 && /È nella Zona di Controllo/.test(chieste[0]) && chieste[0].indexOf('`') < 0, 'RICARICARE: la domanda della RELOAD senza apici (il modulo la passa da M.accenti anche se il confirm non e` l involucro)', chieste[0] && chieste[0].slice(0, 90));
    const T3 = tavolo(T => [tr(P_(T, TRIP), { id: 'n30', alias: 'Tri' })], T => [FUS(T, 'p1')], 'NOMADI'); const N3 = T3.nomadi.g;
    T3.apriMenu(T3.nomadi, 0); N3.applicaRicarica();
    ok(N3.alert_.length === 1 && /^⛔ /.test(N3.alert_[0]) && N3.alert_[0].indexOf('`') < 0, 'RICARICARE senza niente da ricaricare: il no senza apici', N3.alert_);
});

console.log(`\n──────────────\n${passati} passati, ${falliti} falliti\n`);
// L harness lascia aperto il ciclo delle promesse (firebase finto): si esce qui, come in test_novita_28ott.
process.exit(falliti ? 1 : 0);
